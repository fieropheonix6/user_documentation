(ns figshare-api.specs.private-article-search
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def private-article-search-data
  {
   (ds/opt :resource_id) string?
   (ds/opt :resource_doi) string?
   (ds/opt :item_type) int?
   (ds/opt :doi) string?
   (ds/opt :handle) string?
   (ds/opt :project_id) int?
   (ds/opt :order) string?
   (ds/opt :search_for) string?
   (ds/opt :page) int?
   (ds/opt :page_size) int?
   (ds/opt :limit) int?
   (ds/opt :offset) int?
   (ds/opt :order_direction) string?
   (ds/opt :institution) int?
   (ds/opt :published_since) string?
   (ds/opt :modified_since) string?
   (ds/opt :group) int?
   })

(def private-article-search-spec
  (ds/spec
    {:name ::private-article-search
     :spec private-article-search-data}))
