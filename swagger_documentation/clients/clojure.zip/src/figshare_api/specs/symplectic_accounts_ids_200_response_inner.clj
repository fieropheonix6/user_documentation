(ns figshare-api.specs.symplectic-accounts-ids-200-response-inner
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def symplectic-accounts-ids-200-response-inner-data
  {
   (ds/opt :institutionUserId) string?
   (ds/opt :modifiedDate) inst?
   })

(def symplectic-accounts-ids-200-response-inner-spec
  (ds/spec
    {:name ::symplectic-accounts-ids-200-response-inner
     :spec symplectic-accounts-ids-200-response-inner-data}))
