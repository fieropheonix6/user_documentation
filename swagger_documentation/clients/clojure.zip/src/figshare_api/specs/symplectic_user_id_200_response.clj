(ns figshare-api.specs.symplectic-user-id-200-response
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def symplectic-user-id-200-response-data
  {
   (ds/opt :institutionUserId) string?
   })

(def symplectic-user-id-200-response-spec
  (ds/spec
    {:name ::symplectic-user-id-200-response
     :spec symplectic-user-id-200-response-data}))
