(ns figshare-api.specs.altmetric-institution
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def altmetric-institution-data
  {
   (ds/req :id) int?
   (ds/req :name) string?
   (ds/opt :custom_domain) string?
   })

(def altmetric-institution-spec
  (ds/spec
    {:name ::altmetric-institution
     :spec altmetric-institution-data}))
