(ns figshare-api.api.projects
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn private-project-article-delete-with-http-info
  "Delete project article
  Delete project article"
  [project-id article-id ]
  (check-required-params project-id article-id)
  (call-api "/account/projects/{project_id}/articles/{article_id}" :delete
            {:path-params   {"project_id" project-id "article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-article-delete
  "Delete project article
  Delete project article"
  [project-id article-id ]
  (:data (private-project-article-delete-with-http-info project-id article-id)))

(defn private-project-article-details-with-http-info
  "Project article details
  Project article details"
  [project-id article-id ]
  (check-required-params project-id article-id)
  (call-api "/account/projects/{project_id}/articles/{article_id}" :get
            {:path-params   {"project_id" project-id "article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-article-details
  "Project article details
  Project article details"
  [project-id article-id ]
  (:data (private-project-article-details-with-http-info project-id article-id)))

(defn private-project-article-file-with-http-info
  "Project article file details
  Project article file details"
  [project-id article-id file-id ]
  (check-required-params project-id article-id file-id)
  (call-api "/account/projects/{project_id}/articles/{article_id}/files/{file_id}" :get
            {:path-params   {"project_id" project-id "article_id" article-id "file_id" file-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-article-file
  "Project article file details
  Project article file details"
  [project-id article-id file-id ]
  (:data (private-project-article-file-with-http-info project-id article-id file-id)))

(defn private-project-article-files-with-http-info
  "Project article list files
  List article files"
  [project-id article-id ]
  (check-required-params project-id article-id)
  (call-api "/account/projects/{project_id}/articles/{article_id}/files" :get
            {:path-params   {"project_id" project-id "article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-article-files
  "Project article list files
  List article files"
  [project-id article-id ]
  (:data (private-project-article-files-with-http-info project-id article-id)))

(defn private-project-articles-create-with-http-info
  "Create project article
  Create a new Article and associate it with this project"
  [project-id article ]
  (check-required-params project-id article)
  (call-api "/account/projects/{project_id}/articles" :post
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    article
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-articles-create
  "Create project article
  Create a new Article and associate it with this project"
  [project-id article ]
  (:data (private-project-articles-create-with-http-info project-id article)))

(defn private-project-articles-list-with-http-info
  "List project articles
  List project articles"
  [project-id ]
  (check-required-params project-id)
  (call-api "/account/projects/{project_id}/articles" :get
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-articles-list
  "List project articles
  List project articles"
  [project-id ]
  (:data (private-project-articles-list-with-http-info project-id)))

(defn private-project-collaborator-delete-with-http-info
  "Remove project collaborator
  Remove project collaborator"
  [project-id user-id ]
  (check-required-params project-id user-id)
  (call-api "/account/projects/{project_id}/collaborators/{user_id}" :delete
            {:path-params   {"project_id" project-id "user_id" user-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-collaborator-delete
  "Remove project collaborator
  Remove project collaborator"
  [project-id user-id ]
  (:data (private-project-collaborator-delete-with-http-info project-id user-id)))

(defn private-project-collaborators-invite-with-http-info
  "Invite project collaborators
  Invite users to collaborate on project or view the project"
  [project-id collaborator ]
  (check-required-params project-id collaborator)
  (call-api "/account/projects/{project_id}/collaborators" :post
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    collaborator
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-collaborators-invite
  "Invite project collaborators
  Invite users to collaborate on project or view the project"
  [project-id collaborator ]
  (:data (private-project-collaborators-invite-with-http-info project-id collaborator)))

(defn private-project-collaborators-list-with-http-info
  "List project collaborators
  List Project collaborators and invited users"
  [project-id ]
  (check-required-params project-id)
  (call-api "/account/projects/{project_id}/collaborators" :get
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-collaborators-list
  "List project collaborators
  List Project collaborators and invited users"
  [project-id ]
  (:data (private-project-collaborators-list-with-http-info project-id)))

(defn private-project-create-with-http-info
  "Create project
  Create a new project"
  [project ]
  (check-required-params project)
  (call-api "/account/projects" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    project
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-create
  "Create project
  Create a new project"
  [project ]
  (:data (private-project-create-with-http-info project)))

(defn private-project-delete-with-http-info
  "Delete project
  A project can be deleted only if: - it is not public - it does not have public articles.

When an individual project is deleted, all the articles are moved to my data of each owner.

When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project."
  [project-id ]
  (check-required-params project-id)
  (call-api "/account/projects/{project_id}" :delete
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-delete
  "Delete project
  A project can be deleted only if: - it is not public - it does not have public articles.

When an individual project is deleted, all the articles are moved to my data of each owner.

When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project."
  [project-id ]
  (:data (private-project-delete-with-http-info project-id)))

(defn private-project-details-with-http-info
  "View project details
  View a private project"
  [project-id ]
  (check-required-params project-id)
  (call-api "/account/projects/{project_id}" :get
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-details
  "View project details
  View a private project"
  [project-id ]
  (:data (private-project-details-with-http-info project-id)))

(defn private-project-leave-with-http-info
  "Private Project Leave
  Please note: project's owner cannot leave the project."
  [project-id ]
  (check-required-params project-id)
  (call-api "/account/projects/{project_id}/leave" :post
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-leave
  "Private Project Leave
  Please note: project's owner cannot leave the project."
  [project-id ]
  (:data (private-project-leave-with-http-info project-id)))

(defn private-project-note-with-http-info
  "Project note details"
  [project-id note-id ]
  (check-required-params project-id note-id)
  (call-api "/account/projects/{project_id}/notes/{note_id}" :get
            {:path-params   {"project_id" project-id "note_id" note-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-note
  "Project note details"
  [project-id note-id ]
  (:data (private-project-note-with-http-info project-id note-id)))

(defn private-project-note-delete-with-http-info
  "Delete project note"
  [project-id note-id ]
  (check-required-params project-id note-id)
  (call-api "/account/projects/{project_id}/notes/{note_id}" :delete
            {:path-params   {"project_id" project-id "note_id" note-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-note-delete
  "Delete project note"
  [project-id note-id ]
  (:data (private-project-note-delete-with-http-info project-id note-id)))

(defn private-project-note-update-with-http-info
  "Update project note"
  [project-id note-id note ]
  (check-required-params project-id note-id note)
  (call-api "/account/projects/{project_id}/notes/{note_id}" :put
            {:path-params   {"project_id" project-id "note_id" note-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    note
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-note-update
  "Update project note"
  [project-id note-id note ]
  (:data (private-project-note-update-with-http-info project-id note-id note)))

(defn private-project-notes-create-with-http-info
  "Create project note
  Create a new project note"
  [project-id note ]
  (check-required-params project-id note)
  (call-api "/account/projects/{project_id}/notes" :post
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    note
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-notes-create
  "Create project note
  Create a new project note"
  [project-id note ]
  (:data (private-project-notes-create-with-http-info project-id note)))

(defn private-project-notes-list-with-http-info
  "List project notes
  List project notes"
  ([project-id ] (private-project-notes-list-with-http-info project-id nil))
  ([project-id {:keys [page page-size limit offset ]}]
   (check-required-params project-id)
   (call-api "/account/projects/{project_id}/notes" :get
             {:path-params   {"project_id" project-id }
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-project-notes-list
  "List project notes
  List project notes"
  ([project-id ] (private-project-notes-list project-id nil))
  ([project-id optional-params]
   (:data (private-project-notes-list-with-http-info project-id optional-params))))

(defn private-project-publish-with-http-info
  "Private Project Publish
  Publish a project. Possible after all items inside it are public"
  [project-id ]
  (check-required-params project-id)
  (call-api "/account/projects/{project_id}/publish" :post
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-publish
  "Private Project Publish
  Publish a project. Possible after all items inside it are public"
  [project-id ]
  (:data (private-project-publish-with-http-info project-id)))

(defn private-project-update-with-http-info
  "Update project
  Updating an project by passing body parameters; request can also be made with the PATCH method."
  [project-id project ]
  (check-required-params project-id project)
  (call-api "/account/projects/{project_id}" :put
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    project
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-project-update
  "Update project
  Updating an project by passing body parameters; request can also be made with the PATCH method."
  [project-id project ]
  (:data (private-project-update-with-http-info project-id project)))

(defn private-projects-list-with-http-info
  "Private Projects
  List private projects"
  ([] (private-projects-list-with-http-info nil))
  ([{:keys [page page-size limit offset order order-direction storage roles ]}]
   (call-api "/account/projects" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset "order" order "order_direction" order-direction "storage" storage "roles" roles }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-projects-list
  "Private Projects
  List private projects"
  ([] (private-projects-list nil))
  ([optional-params]
   (:data (private-projects-list-with-http-info optional-params))))

(defn private-projects-search-with-http-info
  "Private Projects search
  Search inside the private projects"
  ([] (private-projects-search-with-http-info nil))
  ([{:keys [search ]}]
   (call-api "/account/projects/search" :post
             {:path-params   {}
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn private-projects-search
  "Private Projects search
  Search inside the private projects"
  ([] (private-projects-search nil))
  ([optional-params]
   (:data (private-projects-search-with-http-info optional-params))))

(defn project-articles-with-http-info
  "Public Project Articles
  List articles in project"
  ([project-id ] (project-articles-with-http-info project-id nil))
  ([project-id {:keys [page page-size limit offset ]}]
   (check-required-params project-id)
   (call-api "/projects/{project_id}/articles" :get
             {:path-params   {"project_id" project-id }
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn project-articles
  "Public Project Articles
  List articles in project"
  ([project-id ] (project-articles project-id nil))
  ([project-id optional-params]
   (:data (project-articles-with-http-info project-id optional-params))))

(defn project-details-with-http-info
  "Public Project
  View a project"
  [project-id ]
  (check-required-params project-id)
  (call-api "/projects/{project_id}" :get
            {:path-params   {"project_id" project-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn project-details
  "Public Project
  View a project"
  [project-id ]
  (:data (project-details-with-http-info project-id)))

(defn projects-list-with-http-info
  "Public Projects
  Returns a list of public projects"
  ([] (projects-list-with-http-info nil))
  ([{:keys [x-cursor page page-size limit offset order order-direction institution published-since group ]}]
   (call-api "/projects" :get
             {:path-params   {}
              :header-params {"X-Cursor" x-cursor }
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset "order" order "order_direction" order-direction "institution" institution "published_since" published-since "group" group }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn projects-list
  "Public Projects
  Returns a list of public projects"
  ([] (projects-list nil))
  ([optional-params]
   (:data (projects-list-with-http-info optional-params))))

(defn projects-search-with-http-info
  "Public Projects Search
  Returns a list of public articles"
  ([] (projects-search-with-http-info nil))
  ([{:keys [x-cursor search ]}]
   (call-api "/projects/search" :post
             {:path-params   {}
              :header-params {"X-Cursor" x-cursor }
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn projects-search
  "Public Projects Search
  Returns a list of public articles"
  ([] (projects-search nil))
  ([optional-params]
   (:data (projects-search-with-http-info optional-params))))

