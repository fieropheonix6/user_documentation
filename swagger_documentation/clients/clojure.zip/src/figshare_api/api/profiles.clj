(ns figshare-api.api.profiles
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn update-user-profile-with-http-info
  "Update public profile
  Updates the fields of the user's public profile."
  ([userprofiledata ] (update-user-profile-with-http-info userprofiledata nil))
  ([userprofiledata {:keys [user-id institution-user-id ]}]
   (check-required-params userprofiledata)
   (call-api "/account/profile" :put
             {:path-params   {}
              :header-params {}
              :query-params  {"user_id" user-id "institution_user_id" institution-user-id }
              :form-params   {}
              :body-param    userprofiledata
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn update-user-profile
  "Update public profile
  Updates the fields of the user's public profile."
  ([userprofiledata ] (update-user-profile userprofiledata nil))
  ([userprofiledata optional-params]
   (:data (update-user-profile-with-http-info userprofiledata optional-params))))

(defn update-user-profile-picture-with-http-info
  "Update public profile picture
  Updates the profile picture of the user's public profile."
  [user-id ^File profile-picture ]
  (check-required-params user-id profile-picture)
  (call-api "/account/profile/{user_id}/picture" :post
            {:path-params   {"user_id" user-id }
             :header-params {}
             :query-params  {}
             :form-params   {"profile_picture" profile-picture }
             :content-types ["multipart/form-data"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn update-user-profile-picture
  "Update public profile picture
  Updates the profile picture of the user's public profile."
  [user-id ^File profile-picture ]
  (:data (update-user-profile-picture-with-http-info user-id profile-picture)))

