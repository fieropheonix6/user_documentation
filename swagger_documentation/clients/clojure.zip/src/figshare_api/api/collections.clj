(ns figshare-api.api.collections
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn collection-articles-with-http-info
  "Public Collection Articles
  Returns a list of public collection articles"
  ([collection-id ] (collection-articles-with-http-info collection-id nil))
  ([collection-id {:keys [page page-size limit offset ]}]
   (check-required-params collection-id)
   (call-api "/collections/{collection_id}/articles" :get
             {:path-params   {"collection_id" collection-id }
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn collection-articles
  "Public Collection Articles
  Returns a list of public collection articles"
  ([collection-id ] (collection-articles collection-id nil))
  ([collection-id optional-params]
   (:data (collection-articles-with-http-info collection-id optional-params))))

(defn collection-details-with-http-info
  "Collection details
  View a collection"
  [collection-id ]
  (check-required-params collection-id)
  (call-api "/collections/{collection_id}" :get
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn collection-details
  "Collection details
  View a collection"
  [collection-id ]
  (:data (collection-details-with-http-info collection-id)))

(defn collection-version-details-with-http-info
  "Collection Version details
  View details for a certain version of a collection"
  [collection-id version-id ]
  (check-required-params collection-id version-id)
  (call-api "/collections/{collection_id}/versions/{version_id}" :get
            {:path-params   {"collection_id" collection-id "version_id" version-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn collection-version-details
  "Collection Version details
  View details for a certain version of a collection"
  [collection-id version-id ]
  (:data (collection-version-details-with-http-info collection-id version-id)))

(defn collection-versions-with-http-info
  "Collection Versions list
  Returns a list of public collection Versions"
  [collection-id ]
  (check-required-params collection-id)
  (call-api "/collections/{collection_id}/versions" :get
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn collection-versions
  "Collection Versions list
  Returns a list of public collection Versions"
  [collection-id ]
  (:data (collection-versions-with-http-info collection-id)))

(defn collections-list-with-http-info
  "Public Collections
  Returns a list of public collections"
  ([] (collections-list-with-http-info nil))
  ([{:keys [x-cursor page page-size limit offset order order-direction institution published-since modified-since group resource-doi doi handle ]}]
   (call-api "/collections" :get
             {:path-params   {}
              :header-params {"X-Cursor" x-cursor }
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset "order" order "order_direction" order-direction "institution" institution "published_since" published-since "modified_since" modified-since "group" group "resource_doi" resource-doi "doi" doi "handle" handle }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn collections-list
  "Public Collections
  Returns a list of public collections"
  ([] (collections-list nil))
  ([optional-params]
   (:data (collections-list-with-http-info optional-params))))

(defn collections-search-with-http-info
  "Public Collections Search
  Returns a list of public collections"
  ([] (collections-search-with-http-info nil))
  ([{:keys [x-cursor search ]}]
   (call-api "/collections/search" :post
             {:path-params   {}
              :header-params {"X-Cursor" x-cursor }
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn collections-search
  "Public Collections Search
  Returns a list of public collections"
  ([] (collections-search nil))
  ([optional-params]
   (:data (collections-search-with-http-info optional-params))))

(defn private-collection-article-delete-with-http-info
  "Delete collection article
  De-associate article from collection"
  [collection-id article-id ]
  (check-required-params collection-id article-id)
  (call-api "/account/collections/{collection_id}/articles/{article_id}" :delete
            {:path-params   {"collection_id" collection-id "article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-article-delete
  "Delete collection article
  De-associate article from collection"
  [collection-id article-id ]
  (:data (private-collection-article-delete-with-http-info collection-id article-id)))

(defn private-collection-articles-add-with-http-info
  "Add collection articles
  Associate new articles with the collection. This will add new articles to the list of already associated articles"
  [collection-id articles ]
  (check-required-params collection-id articles)
  (call-api "/account/collections/{collection_id}/articles" :post
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    articles
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-articles-add
  "Add collection articles
  Associate new articles with the collection. This will add new articles to the list of already associated articles"
  [collection-id articles ]
  (:data (private-collection-articles-add-with-http-info collection-id articles)))

(defn private-collection-articles-list-with-http-info
  "List collection articles
  List collection articles"
  ([collection-id ] (private-collection-articles-list-with-http-info collection-id nil))
  ([collection-id {:keys [page page-size limit offset ]}]
   (check-required-params collection-id)
   (call-api "/account/collections/{collection_id}/articles" :get
             {:path-params   {"collection_id" collection-id }
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-collection-articles-list
  "List collection articles
  List collection articles"
  ([collection-id ] (private-collection-articles-list collection-id nil))
  ([collection-id optional-params]
   (:data (private-collection-articles-list-with-http-info collection-id optional-params))))

(defn private-collection-articles-replace-with-http-info
  "Replace collection articles
  Associate new articles with the collection. This will remove all already associated articles and add these new ones"
  [collection-id articles ]
  (check-required-params collection-id articles)
  (call-api "/account/collections/{collection_id}/articles" :put
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    articles
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-articles-replace
  "Replace collection articles
  Associate new articles with the collection. This will remove all already associated articles and add these new ones"
  [collection-id articles ]
  (:data (private-collection-articles-replace-with-http-info collection-id articles)))

(defn private-collection-author-delete-with-http-info
  "Delete collection author
  Delete collection author"
  [collection-id author-id ]
  (check-required-params collection-id author-id)
  (call-api "/account/collections/{collection_id}/authors/{author_id}" :delete
            {:path-params   {"collection_id" collection-id "author_id" author-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-author-delete
  "Delete collection author
  Delete collection author"
  [collection-id author-id ]
  (:data (private-collection-author-delete-with-http-info collection-id author-id)))

(defn private-collection-authors-add-with-http-info
  "Add collection authors
  Associate new authors with the collection. This will add new authors to the list of already associated authors"
  [collection-id authors ]
  (check-required-params collection-id authors)
  (call-api "/account/collections/{collection_id}/authors" :post
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    authors
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-authors-add
  "Add collection authors
  Associate new authors with the collection. This will add new authors to the list of already associated authors"
  [collection-id authors ]
  (:data (private-collection-authors-add-with-http-info collection-id authors)))

(defn private-collection-authors-list-with-http-info
  "List collection authors
  List collection authors"
  [collection-id ]
  (check-required-params collection-id)
  (call-api "/account/collections/{collection_id}/authors" :get
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-authors-list
  "List collection authors
  List collection authors"
  [collection-id ]
  (:data (private-collection-authors-list-with-http-info collection-id)))

(defn private-collection-authors-replace-with-http-info
  "Replace collection authors
  Associate new authors with the collection. This will remove all already associated authors and add these new ones"
  [collection-id authors ]
  (check-required-params collection-id authors)
  (call-api "/account/collections/{collection_id}/authors" :put
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    authors
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-authors-replace
  "Replace collection authors
  Associate new authors with the collection. This will remove all already associated authors and add these new ones"
  [collection-id authors ]
  (:data (private-collection-authors-replace-with-http-info collection-id authors)))

(defn private-collection-categories-add-with-http-info
  "Add collection categories
  Associate new categories with the collection. This will add new categories to the list of already associated categories"
  [collection-id categories ]
  (check-required-params collection-id categories)
  (call-api "/account/collections/{collection_id}/categories" :post
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    categories
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-categories-add
  "Add collection categories
  Associate new categories with the collection. This will add new categories to the list of already associated categories"
  [collection-id categories ]
  (:data (private-collection-categories-add-with-http-info collection-id categories)))

(defn private-collection-categories-list-with-http-info
  "List collection categories
  List collection categories"
  [collection-id ]
  (check-required-params collection-id)
  (call-api "/account/collections/{collection_id}/categories" :get
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-categories-list
  "List collection categories
  List collection categories"
  [collection-id ]
  (:data (private-collection-categories-list-with-http-info collection-id)))

(defn private-collection-categories-replace-with-http-info
  "Replace collection categories
  Associate new categories with the collection. This will remove all already associated categories and add these new ones"
  [collection-id categories ]
  (check-required-params collection-id categories)
  (call-api "/account/collections/{collection_id}/categories" :put
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    categories
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-categories-replace
  "Replace collection categories
  Associate new categories with the collection. This will remove all already associated categories and add these new ones"
  [collection-id categories ]
  (:data (private-collection-categories-replace-with-http-info collection-id categories)))

(defn private-collection-category-delete-with-http-info
  "Delete collection category
  De-associate category from collection"
  [collection-id category-id ]
  (check-required-params collection-id category-id)
  (call-api "/account/collections/{collection_id}/categories/{category_id}" :delete
            {:path-params   {"collection_id" collection-id "category_id" category-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-category-delete
  "Delete collection category
  De-associate category from collection"
  [collection-id category-id ]
  (:data (private-collection-category-delete-with-http-info collection-id category-id)))

(defn private-collection-create-with-http-info
  "Create collection
  Create a new Collection by sending collection information"
  [collection ]
  (check-required-params collection)
  (call-api "/account/collections" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    collection
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-create
  "Create collection
  Create a new Collection by sending collection information"
  [collection ]
  (:data (private-collection-create-with-http-info collection)))

(defn private-collection-delete-with-http-info
  "Delete collection
  Delete n collection"
  [collection-id ]
  (check-required-params collection-id)
  (call-api "/account/collections/{collection_id}" :delete
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-delete
  "Delete collection
  Delete n collection"
  [collection-id ]
  (:data (private-collection-delete-with-http-info collection-id)))

(defn private-collection-details-with-http-info
  "Collection details
  View a collection"
  [collection-id ]
  (check-required-params collection-id)
  (call-api "/account/collections/{collection_id}" :get
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-details
  "Collection details
  View a collection"
  [collection-id ]
  (:data (private-collection-details-with-http-info collection-id)))

(defn private-collection-private-link-create-with-http-info
  "Create collection private link
  Create new private link"
  ([collection-id ] (private-collection-private-link-create-with-http-info collection-id nil))
  ([collection-id {:keys [private-link ]}]
   (check-required-params collection-id)
   (call-api "/account/collections/{collection_id}/private_links" :post
             {:path-params   {"collection_id" collection-id }
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    private-link
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-collection-private-link-create
  "Create collection private link
  Create new private link"
  ([collection-id ] (private-collection-private-link-create collection-id nil))
  ([collection-id optional-params]
   (:data (private-collection-private-link-create-with-http-info collection-id optional-params))))

(defn private-collection-private-link-delete-with-http-info
  "Disable private link
  Disable/delete private link for this collection"
  [collection-id link-id ]
  (check-required-params collection-id link-id)
  (call-api "/account/collections/{collection_id}/private_links/{link_id}" :delete
            {:path-params   {"collection_id" collection-id "link_id" link-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-private-link-delete
  "Disable private link
  Disable/delete private link for this collection"
  [collection-id link-id ]
  (:data (private-collection-private-link-delete-with-http-info collection-id link-id)))

(defn private-collection-private-link-details-with-http-info
  "View collection private link
  View existing private link for this collection"
  [collection-id link-id ]
  (check-required-params collection-id link-id)
  (call-api "/account/collections/{collection_id}/private_links/{link_id}" :get
            {:path-params   {"collection_id" collection-id "link_id" link-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-private-link-details
  "View collection private link
  View existing private link for this collection"
  [collection-id link-id ]
  (:data (private-collection-private-link-details-with-http-info collection-id link-id)))

(defn private-collection-private-link-update-with-http-info
  "Update collection private link
  Update existing private link for this collection"
  ([collection-id link-id ] (private-collection-private-link-update-with-http-info collection-id link-id nil))
  ([collection-id link-id {:keys [private-link ]}]
   (check-required-params collection-id link-id)
   (call-api "/account/collections/{collection_id}/private_links/{link_id}" :put
             {:path-params   {"collection_id" collection-id "link_id" link-id }
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    private-link
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-collection-private-link-update
  "Update collection private link
  Update existing private link for this collection"
  ([collection-id link-id ] (private-collection-private-link-update collection-id link-id nil))
  ([collection-id link-id optional-params]
   (:data (private-collection-private-link-update-with-http-info collection-id link-id optional-params))))

(defn private-collection-private-links-list-with-http-info
  "List collection private links
  List article private links"
  [collection-id ]
  (check-required-params collection-id)
  (call-api "/account/collections/{collection_id}/private_links" :get
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-private-links-list
  "List collection private links
  List article private links"
  [collection-id ]
  (:data (private-collection-private-links-list-with-http-info collection-id)))

(defn private-collection-publish-with-http-info
  "Private Collection Publish
  When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed."
  [collection-id ]
  (check-required-params collection-id)
  (call-api "/account/collections/{collection_id}/publish" :post
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-publish
  "Private Collection Publish
  When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed."
  [collection-id ]
  (:data (private-collection-publish-with-http-info collection-id)))

(defn private-collection-reserve-doi-with-http-info
  "Private Collection Reserve DOI
  Reserve DOI for collection"
  [collection-id ]
  (check-required-params collection-id)
  (call-api "/account/collections/{collection_id}/reserve_doi" :post
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-reserve-doi
  "Private Collection Reserve DOI
  Reserve DOI for collection"
  [collection-id ]
  (:data (private-collection-reserve-doi-with-http-info collection-id)))

(defn private-collection-reserve-handle-with-http-info
  "Private Collection Reserve Handle
  Reserve Handle for collection"
  [collection-id ]
  (check-required-params collection-id)
  (call-api "/account/collections/{collection_id}/reserve_handle" :post
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-reserve-handle
  "Private Collection Reserve Handle
  Reserve Handle for collection"
  [collection-id ]
  (:data (private-collection-reserve-handle-with-http-info collection-id)))

(defn private-collection-resource-with-http-info
  "Private Collection Resource
  Edit collection resource data."
  [collection-id resource ]
  (check-required-params collection-id resource)
  (call-api "/account/collections/{collection_id}/resource" :post
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    resource
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-resource
  "Private Collection Resource
  Edit collection resource data."
  [collection-id resource ]
  (:data (private-collection-resource-with-http-info collection-id resource)))

(defn private-collection-update-with-http-info
  "Update collection
  Update collection details; request can also be made with the PATCH method."
  [collection-id collection ]
  (check-required-params collection-id collection)
  (call-api "/account/collections/{collection_id}" :put
            {:path-params   {"collection_id" collection-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    collection
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collection-update
  "Update collection
  Update collection details; request can also be made with the PATCH method."
  [collection-id collection ]
  (:data (private-collection-update-with-http-info collection-id collection)))

(defn private-collections-list-with-http-info
  "Private Collections List
  List private collections"
  ([] (private-collections-list-with-http-info nil))
  ([{:keys [page page-size limit offset order order-direction ]}]
   (call-api "/account/collections" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset "order" order "order_direction" order-direction }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-collections-list
  "Private Collections List
  List private collections"
  ([] (private-collections-list nil))
  ([optional-params]
   (:data (private-collections-list-with-http-info optional-params))))

(defn private-collections-search-with-http-info
  "Private Collections Search
  Returns a list of private Collections"
  [search ]
  (check-required-params search)
  (call-api "/account/collections/search" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    search
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-collections-search
  "Private Collections Search
  Returns a list of private Collections"
  [search ]
  (:data (private-collections-search-with-http-info search)))

