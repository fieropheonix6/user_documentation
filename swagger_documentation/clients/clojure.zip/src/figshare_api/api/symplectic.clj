(ns figshare-api.api.symplectic
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format *api-context*]]
            [clojure.spec.alpha :as s]
            [spec-tools.core :as st]
            [orchestra.core :refer [defn-spec]]
            [figshare-api.specs.custom-article-field :refer :all]
            [figshare-api.specs.file-id :refer :all]
            [figshare-api.specs.project-collaborator-invite :refer :all]
            [figshare-api.specs.projects-search :refer :all]
            [figshare-api.specs.funding-search :refer :all]
            [figshare-api.specs.project-collaborator :refer :all]
            [figshare-api.specs.profile-update-data-personal-profiles-inner :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            [figshare-api.specs.author-complete :refer :all]
            [figshare-api.specs.collaborator :refer :all]
            [figshare-api.specs.project-note-private :refer :all]
            [figshare-api.specs.private-link-response :refer :all]
            [figshare-api.specs.item-type :refer :all]
            [figshare-api.specs.location-warnings :refer :all]
            [figshare-api.specs.article-create :refer :all]
            [figshare-api.specs.project-note :refer :all]
            [figshare-api.specs.institution-accounts-search :refer :all]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs.collection-handle :refer :all]
            [figshare-api.specs.symplectic-user-id-200-response :refer :all]
            [figshare-api.specs.authors-creator :refer :all]
            [figshare-api.specs.article-embargo :refer :all]
            [figshare-api.specs.error-message :refer :all]
            [figshare-api.specs.collection-private-link-creator :refer :all]
            [figshare-api.specs.response-message :refer :all]
            [figshare-api.specs.project-create :refer :all]
            [figshare-api.specs.timeline-update :refer :all]
            [figshare-api.specs.project-complete-private :refer :all]
            [figshare-api.specs.role :refer :all]
            [figshare-api.specs.article-project-create :refer :all]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.upload-info :refer :all]
            [figshare-api.specs.custom-article-field-add-value :refer :all]
            [figshare-api.specs.article-doi :refer :all]
            [figshare-api.specs.project-private :refer :all]
            [figshare-api.specs.private-project-article :refer :all]
            [figshare-api.specs.project-complete :refer :all]
            [figshare-api.specs.article-search :refer :all]
            [figshare-api.specs.account-update :refer :all]
            [figshare-api.specs.category-list :refer :all]
            [figshare-api.specs.private-file :refer :all]
            [figshare-api.specs.collection-complete :refer :all]
            [figshare-api.specs.private-authors-search :refer :all]
            [figshare-api.specs.timeline :refer :all]
            [figshare-api.specs.categories-creator :refer :all]
            [figshare-api.specs.account-report :refer :all]
            [figshare-api.specs.article-unpublish-data :refer :all]
            [figshare-api.specs.article-versions :refer :all]
            [figshare-api.specs.collection-create :refer :all]
            [figshare-api.specs.project :refer :all]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs.institution :refer :all]
            [figshare-api.specs.short-account :refer :all]
            [figshare-api.specs.symplectic-accounts-ids-200-response-inner :refer :all]
            [figshare-api.specs.curation-detail :refer :all]
            [figshare-api.specs.article-handle :refer :all]
            [figshare-api.specs.article-complete :refer :all]
            [figshare-api.specs.article-complete-private :refer :all]
            [figshare-api.specs.article-with-project :refer :all]
            [figshare-api.specs.articles-creator :refer :all]
            [figshare-api.specs.group :refer :all]
            [figshare-api.specs.collection-search :refer :all]
            [figshare-api.specs.account-create-response :refer :all]
            [figshare-api.specs.create-project-response :refer :all]
            [figshare-api.specs.resource :refer :all]
            [figshare-api.specs.author :refer :all]
            [figshare-api.specs.collection-complete-private :refer :all]
            [figshare-api.specs.curation-comment :refer :all]
            [figshare-api.specs.collection :refer :all]
            [figshare-api.specs.article :refer :all]
            [figshare-api.specs.file-creator :refer :all]
            [figshare-api.specs.license :refer :all]
            [figshare-api.specs.private-link-creator :refer :all]
            [figshare-api.specs.public-file :refer :all]
            [figshare-api.specs.upload-file-part :refer :all]
            [figshare-api.specs.collection-versions :refer :all]
            [figshare-api.specs.create-o-auth-token :refer :all]
            [figshare-api.specs.confidentiality-creator :refer :all]
            [figshare-api.specs.article-update :refer :all]
            [figshare-api.specs.collection-update :refer :all]
            [figshare-api.specs.profile-update-data :refer :all]
            [figshare-api.specs.private-article-search :refer :all]
            [figshare-api.specs.article-confidentiality :refer :all]
            [figshare-api.specs.curation-comment-create :refer :all]
            [figshare-api.specs.location-warnings-update :refer :all]
            [figshare-api.specs.short-custom-field :refer :all]
            [figshare-api.specs.project-note-create :refer :all]
            [figshare-api.specs.curation :refer :all]
            [figshare-api.specs.group-embargo-options :refer :all]
            [figshare-api.specs.private-collection-search :refer :all]
            [figshare-api.specs.private-link :refer :all]
            [figshare-api.specs.altmetric-institution :refer :all]
            [figshare-api.specs.article-version-update :refer :all]
            [figshare-api.specs.account-create :refer :all]
            [figshare-api.specs.project-article :refer :all]
            [figshare-api.specs.project-update :refer :all]
            [figshare-api.specs.o-auth-token :refer :all]
            [figshare-api.specs.collection-doi :refer :all]
            [figshare-api.specs.location :refer :all]
            [figshare-api.specs.article-embargo-updater :refer :all]
            [figshare-api.specs.category :refer :all]
            [figshare-api.specs.common-search :refer :all]
            [figshare-api.specs.user :refer :all]
            [figshare-api.specs.account :refer :all]
            )
  (:import (java.io File)))


(defn-spec symplectic-account-articles-with-http-info any?
  "Get articles for a specific account
  Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id)."
  ([external_user_id string?, ] (symplectic-account-articles-with-http-info external_user_id nil))
  ([external_user_id string?, {:keys [offset limit status is_embargoed]} (s/map-of keyword? any?)]
   (check-required-params external_user_id)
   (call-api "/symplectic/accounts/{external_user_id}/articles" :get
             {:path-params   {"external_user_id" external_user_id }
              :header-params {}
              :query-params  {"offset" offset "limit" limit "status" status "is_embargoed" is_embargoed }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec symplectic-account-articles (s/coll-of any?)
  "Get articles for a specific account
  Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id)."
  ([external_user_id string?, ] (symplectic-account-articles external_user_id nil))
  ([external_user_id string?, optional-params any?]
   (let [res (:data (symplectic-account-articles-with-http-info external_user_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of any?) res st/string-transformer)
        res))))


(defn-spec symplectic-accounts-ids-with-http-info any?
  "Get changed accounts for Symplectic Elements
  Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration."
  [since string?]
  (check-required-params since)
  (call-api "/symplectic/accounts" :get
            {:path-params   {}
             :header-params {}
             :query-params  {"since" since }
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec symplectic-accounts-ids (s/coll-of symplectic-accounts-ids-200-response-inner-spec)
  "Get changed accounts for Symplectic Elements
  Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration."
  [since string?]
  (let [res (:data (symplectic-accounts-ids-with-http-info since))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of symplectic-accounts-ids-200-response-inner-spec) res st/string-transformer)
       res)))


(defn-spec symplectic-article-with-http-info any?
  "Get article details for Symplectic Elements
  Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information."
  [article_id int?]
  (check-required-params article_id)
  (call-api "/symplectic/articles/{article_id}" :get
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec symplectic-article any?
  "Get article details for Symplectic Elements
  Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information."
  [article_id int?]
  (let [res (:data (symplectic-article-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec symplectic-changed-articles-with-http-info any?
  "Get changed articles for Symplectic Elements
  Returns a list of articles for Symplectic Elements integration to synchronize article data."
  ([since string?, ] (symplectic-changed-articles-with-http-info since nil))
  ([since string?, {:keys [offset limit status is_embargoed]} (s/map-of keyword? any?)]
   (check-required-params since)
   (call-api "/symplectic/articles" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"since" since "offset" offset "limit" limit "status" status "is_embargoed" is_embargoed }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec symplectic-changed-articles (s/coll-of any?)
  "Get changed articles for Symplectic Elements
  Returns a list of articles for Symplectic Elements integration to synchronize article data."
  ([since string?, ] (symplectic-changed-articles since nil))
  ([since string?, optional-params any?]
   (let [res (:data (symplectic-changed-articles-with-http-info since optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of any?) res st/string-transformer)
        res))))


(defn-spec symplectic-user-id-with-http-info any?
  "Get institutional user ID for a user
  Returns the institution user ID for a given user within the authenticated account's institution."
  [user_id int?]
  (check-required-params user_id)
  (call-api "/symplectic/users/{user_id}" :get
            {:path-params   {"user_id" user_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec symplectic-user-id symplectic-user-id-200-response-spec
  "Get institutional user ID for a user
  Returns the institution user ID for a given user within the authenticated account's institution."
  [user_id int?]
  (let [res (:data (symplectic-user-id-with-http-info user_id))]
    (if (:decode-models *api-context*)
       (st/decode symplectic-user-id-200-response-spec res st/string-transformer)
       res)))


