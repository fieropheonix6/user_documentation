

# AltmetricInstitution


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** | Institution id |  |
|**name** | **String** | Institution name |  |
|**customDomain** | **String** | Custom domain for the institution |  [optional] |



