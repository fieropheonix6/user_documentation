

# SymplecticUserId200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**institutionUserId** | **String** |  |  [optional] |



