

# CustomArticleFieldAddValue

Custom metadata value (can be either a string, an array of strings, or empty)

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|



