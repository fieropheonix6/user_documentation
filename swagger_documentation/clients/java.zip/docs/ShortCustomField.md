

# ShortCustomField


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** | Custom field id |  |
|**name** | **String** | Custom field name |  |
|**fieldType** | [**FieldTypeEnum**](#FieldTypeEnum) | Custom field type |  |
|**settings** | **Object** | Settings for the custom field |  [optional] |
|**order** | **Integer** | Order of the field in the group |  [optional] |
|**isMandatory** | **Boolean** | Whether the field is mandatory or not |  [optional] |



## Enum: FieldTypeEnum

| Name | Value |
|---- | -----|
| TEXT | &quot;text&quot; |
| TEXTAREA | &quot;textarea&quot; |
| DROPDOWN | &quot;dropdown&quot; |
| URL | &quot;url&quot; |
| EMAIL | &quot;email&quot; |
| DATE | &quot;date&quot; |
| DROPDOWN_LARGE_LIST | &quot;dropdown_large_list&quot; |



