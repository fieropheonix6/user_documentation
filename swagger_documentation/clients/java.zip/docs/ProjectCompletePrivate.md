

# ProjectCompletePrivate


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**funding** | **String** | Project funding |  |
|**fundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information |  |
|**description** | **String** | Project description |  |
|**collaborators** | [**List&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators |  |
|**quota** | **Integer** | Project quota |  |
|**usedQuota** | **Integer** | Project used quota |  |
|**createdDate** | **String** | Date when project was created |  |
|**modifiedDate** | **String** | Date when project was last modified |  |
|**usedQuotaPrivate** | **Integer** | Project private quota used |  |
|**usedQuotaPublic** | **Integer** | Project public quota used |  |
|**groupId** | **Integer** | Group of project if any |  |
|**accountId** | **Integer** | ID of the account owning the project |  |
|**customFields** | [**List&lt;ShortCustomField&gt;**](ShortCustomField.md) | Collection custom fields |  |
|**role** | [**RoleEnum**](#RoleEnum) | Role inside this project |  |
|**storage** | [**StorageEnum**](#StorageEnum) | Project storage type |  |
|**url** | **String** | Api endpoint |  |
|**id** | **Integer** | Project id |  |
|**title** | **String** | Project title |  |



## Enum: RoleEnum

| Name | Value |
|---- | -----|
| OWNER | &quot;Owner&quot; |
| COLLABORATOR | &quot;Collaborator&quot; |
| VIEWER | &quot;Viewer&quot; |



## Enum: StorageEnum

| Name | Value |
|---- | -----|
| INDIVIDUAL | &quot;individual&quot; |
| GROUP | &quot;group&quot; |



