
# ArticleDOI

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**doi** | **String** | Reserved DOI | 



