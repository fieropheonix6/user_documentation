
# ProjectPrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | Api endpoint | 
**id** | **Long** | Project id | 
**title** | **String** | Project title | 
**createdDate** | **String** | Date when project was created | 
**modifiedDate** | **String** | Date when project was last modified | 
**role** | [**RoleEnum**](#RoleEnum) | Role inside this project | 
**storage** | [**StorageEnum**](#StorageEnum) | Project storage type | 


<a name="RoleEnum"></a>
## Enum: RoleEnum
Name | Value
---- | -----
OWNER | &quot;Owner&quot;
COLLABORATOR | &quot;Collaborator&quot;
VIEWER | &quot;Viewer&quot;


<a name="StorageEnum"></a>
## Enum: StorageEnum
Name | Value
---- | -----
INDIVIDUAL | &quot;individual&quot;
GROUP | &quot;group&quot;



