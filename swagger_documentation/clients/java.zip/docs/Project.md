
# Project

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | Api endpoint | 
**id** | **Long** | Project id | 
**title** | **String** | Project title | 



