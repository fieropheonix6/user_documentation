

# FileId


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**fileId** | **Integer** | File ID |  [optional] |



