
# FileId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fileId** | **Long** | File ID |  [optional]



