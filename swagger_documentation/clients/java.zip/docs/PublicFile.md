

# PublicFile


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** | File id |  |
|**name** | **String** | File name |  |
|**size** | **Integer** | File size |  |
|**isLinkOnly** | **Boolean** | True if file is hosted somewhere else |  |
|**downloadUrl** | **String** | Url for file download |  |
|**suppliedMd5** | **String** | File supplied md5 |  |
|**computedMd5** | **String** | File computed md5 |  |
|**mimetype** | **String** | MIME Type of the file, it defaults to an empty string |  [optional] |



