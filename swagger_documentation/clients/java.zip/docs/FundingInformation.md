
# FundingInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Funding id | 
**title** | **String** | The funding name | 
**grantCode** | **String** | The grant code | 
**funderName** | **String** | Funder&#39;s name | 
**isUserDefined** | **Long** | Return 1 whether the grant has been introduced manually, 0 otherwise | 
**url** | **String** | The grant url | 



