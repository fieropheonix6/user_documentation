

# LocationWarnings


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**entityId** | **Integer** | Figshare ID of the entity |  |
|**location** | **String** | Url for entity |  |
|**warnings** | **List&lt;String&gt;** | Issues encountered during the operation |  |



