
# ProfileUpdateDataPersonalProfiles

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **String** | Label for the personal profile link |  [optional]
**url** | **String** | URL for the personal profile link |  [optional]



