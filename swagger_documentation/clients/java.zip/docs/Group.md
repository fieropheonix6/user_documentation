

# Group


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** | Group id |  |
|**name** | **String** | Group name |  |
|**resourceId** | **String** | Group resource id |  |
|**parentId** | **Integer** | Parent group if any |  |
|**associationCriteria** | **String** | HR code associated with group, if code exists |  |



