

# ProjectComplete


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**funding** | **String** | Project funding |  |
|**fundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information |  |
|**description** | **String** | Project description |  |
|**collaborators** | [**List&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators |  |
|**customFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | Project custom fields |  |
|**modifiedDate** | **String** | Date when project was last modified |  |
|**createdDate** | **String** | Date when project was created |  |
|**url** | **String** | Api endpoint |  |
|**id** | **Integer** | Project id |  |
|**title** | **String** | Project title |  |



