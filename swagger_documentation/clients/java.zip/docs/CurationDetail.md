

# CurationDetail


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**item** | [**ArticleComplete**](ArticleComplete.md) |  |  |
|**id** | **Integer** | The review id |  |
|**groupId** | **Integer** | The group in which the article is present. |  |
|**accountId** | **Integer** | The ID of the account of the owner of the article of this review. |  |
|**assignedTo** | **Integer** | The ID of the account to which this review is assigned. |  |
|**articleId** | **Integer** | The ID of the article of this review. |  |
|**version** | **Integer** | The Version number of the article in review. |  |
|**commentsCount** | **Integer** | The number of comments in the review. |  |
|**status** | [**StatusEnum**](#StatusEnum) | The status of the review. |  |
|**createdDate** | **String** | The creation date of the review. |  |
|**modifiedDate** | **String** | The date the review has been modified. |  |
|**requestNumber** | **Integer** | The request number of the review. |  |
|**resolutionComment** | **String** | The resolution comment of the review. |  |



## Enum: StatusEnum

| Name | Value |
|---- | -----|
| PENDING | &quot;pending&quot; |
| APPROVED | &quot;approved&quot; |
| REJECTED | &quot;rejected&quot; |
| CLOSED | &quot;closed&quot; |



