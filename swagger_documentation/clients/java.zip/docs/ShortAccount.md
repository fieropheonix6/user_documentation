

# ShortAccount


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** | Account id |  |
|**firstName** | **String** | First Name |  |
|**lastName** | **String** | Last Name |  |
|**institutionId** | **Integer** | Account institution |  |
|**email** | **String** | User email |  |
|**active** | **Integer** | Account activity status |  |
|**institutionUserId** | **String** | Account institution user id |  |
|**quota** | **Integer** | Total storage available to account, in bytes |  |
|**usedQuota** | **Integer** | Storage used by the account, in bytes |  |
|**userId** | **Integer** | User id associated with account, useful for example for adding the account as an author to an item |  |
|**orcidId** | **String** | ORCID iD associated to account |  |
|**symplecticUserId** | **String** | Symplectic ID associated to account |  |



