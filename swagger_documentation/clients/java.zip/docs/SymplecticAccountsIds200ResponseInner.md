

# SymplecticAccountsIds200ResponseInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**institutionUserId** | **String** |  |  [optional] |
|**modifiedDate** | **OffsetDateTime** |  |  [optional] |



