

# ArticleComplete


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**figshareUrl** | **String** | Article public url |  |
|**downloadDisabled** | **Boolean** | If true, downloading of files for this article is disabled |  |
|**files** | [**List&lt;PublicFile&gt;**](PublicFile.md) | List of up to 10 article files. |  |
|**folderStructure** | **Object** | Mapping of file ids to folder paths, if folders are used |  |
|**authors** | [**List&lt;Author&gt;**](Author.md) | List of article authors |  |
|**customFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | List of custom fields values |  |
|**embargoOptions** | [**List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md) | List of embargo options |  |
|**citation** | **String** | Article citation |  |
|**confidentialReason** | **String** | Confidentiality reason |  |
|**isConfidential** | **Boolean** | Article Confidentiality |  |
|**size** | **Integer** | Article size |  |
|**funding** | **String** | Article funding |  |
|**fundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Article funding information |  |
|**tags** | **List&lt;String&gt;** | List of article tags. Keywords can be used instead |  |
|**keywords** | **List&lt;String&gt;** | List of article keywords. Tags can be used instead |  |
|**version** | **Integer** | Article version |  |
|**isMetadataRecord** | **Boolean** | True if article has no files |  |
|**metadataReason** | **String** | Article metadata reason |  |
|**status** | **String** | Article status |  |
|**description** | **String** | Article description |  |
|**isEmbargoed** | **Boolean** | True if article is embargoed |  |
|**isPublic** | **Boolean** | True if article is published |  |
|**createdDate** | **String** | Date when article was created |  |
|**hasLinkedFile** | **Boolean** | True if any files are linked to the article |  |
|**categories** | [**List&lt;Category&gt;**](Category.md) | List of categories selected for the article |  |
|**license** | [**License**](License.md) |  |  |
|**embargoTitle** | **String** | Title for embargo |  |
|**embargoReason** | **String** | Reason for embargo |  |
|**references** | **List&lt;String&gt;** | List of references |  |
|**relatedMaterials** | [**List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. |  [optional] |
|**id** | **Integer** | Unique identifier for article |  |
|**title** | **String** | Title of article |  |
|**doi** | **String** | DOI |  |
|**handle** | **String** | Handle |  |
|**url** | **String** | Api endpoint for article |  |
|**urlPublicHtml** | **String** | Public site endpoint for article |  |
|**urlPublicApi** | **String** | Public Api endpoint for article |  |
|**urlPrivateHtml** | **String** | Private site endpoint for article |  |
|**urlPrivateApi** | **String** | Private Api endpoint for article |  |
|**timeline** | [**Timeline**](Timeline.md) |  |  |
|**thumb** | **String** | Thumbnail image |  |
|**definedType** | **Integer** | Type of article identifier |  |
|**definedTypeName** | **String** | Name of the article type identifier |  |
|**resourceDoi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. |  |
|**resourceTitle** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. |  |



