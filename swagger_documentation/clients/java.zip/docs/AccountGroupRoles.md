
# AccountGroupRoles

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



