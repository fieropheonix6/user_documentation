
# CollectionComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Collection id | 
**title** | **String** | Collection title | 
**doi** | **String** | Collection DOI | 
**handle** | **String** | Collection Handle | 
**url** | **String** | Api endpoint | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**funding** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information | 
**resourceId** | **String** | Collection resource id | 
**resourceDoi** | **String** | Collection resource doi | 
**resourceTitle** | **String** | Collection resource title | 
**resourceLink** | **String** | Collection resource link | 
**resourceVersion** | **Long** | Collection resource version | 
**version** | **Long** | Collection version | 
**description** | **String** | Collection description | 
**categories** | [**List&lt;Category&gt;**](Category.md) | List of collection categories | 
**references** | **List&lt;String&gt;** | List of collection references | 
**relatedMaterials** | [**List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. |  [optional]
**tags** | **List&lt;String&gt;** | List of collection tags | 
**authors** | [**List&lt;Author&gt;**](Author.md) | List of collection authors | 
**institutionId** | **Long** | Collection institution | 
**groupId** | **Long** | Collection group | 
**articlesCount** | **Long** | Number of articles in collection | 
**_public** | **Boolean** | True if collection is published | 
**citation** | **String** | Collection citation | 
**customFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | Collection custom fields | 
**modifiedDate** | **String** | Date when collection was last modified | 
**createdDate** | **String** | Date when collection was created | 



