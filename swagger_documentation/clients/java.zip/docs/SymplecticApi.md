# SymplecticApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**symplecticAccountArticles**](SymplecticApi.md#symplecticAccountArticles) | **GET** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account |
| [**symplecticAccountsIds**](SymplecticApi.md#symplecticAccountsIds) | **GET** /symplectic/accounts | Get changed accounts for Symplectic Elements |
| [**symplecticArticle**](SymplecticApi.md#symplecticArticle) | **GET** /symplectic/articles/{article_id} | Get article details for Symplectic Elements |
| [**symplecticChangedArticles**](SymplecticApi.md#symplecticChangedArticles) | **GET** /symplectic/articles | Get changed articles for Symplectic Elements |
| [**symplecticUserId**](SymplecticApi.md#symplecticUserId) | **GET** /symplectic/users/{user_id} | Get institutional user ID for a user |


<a id="symplecticAccountArticles"></a>
# **symplecticAccountArticles**
> List&lt;Object&gt; symplecticAccountArticles(externalUserId, offset, limit, status, isEmbargoed)

Get articles for a specific account

Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.auth.*;
import org.openapitools.client.models.*;
import org.openapitools.client.api.SymplecticApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: OAuth2
    OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
    OAuth2.setAccessToken("YOUR ACCESS TOKEN");

    SymplecticApi apiInstance = new SymplecticApi(defaultClient);
    String externalUserId = "externalUserId_example"; // String | External user ID (symplectic_user_id or institution_user_id)
    Integer offset = 0; // Integer | Number of results to skip for pagination
    Integer limit = 10; // Integer | Maximum number of results to return
    String status = "public"; // String | Filter by article status
    String isEmbargoed = "true"; // String | Filter by embargo status
    try {
      List<Object> result = apiInstance.symplecticAccountArticles(externalUserId, offset, limit, status, isEmbargoed);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling SymplecticApi#symplecticAccountArticles");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **externalUserId** | **String**| External user ID (symplectic_user_id or institution_user_id) | |
| **offset** | **Integer**| Number of results to skip for pagination | [optional] [default to 0] |
| **limit** | **Integer**| Maximum number of results to return | [optional] [default to 10] |
| **status** | **String**| Filter by article status | [optional] [enum: public, private, draft] |
| **isEmbargoed** | **String**| Filter by embargo status | [optional] [enum: true, false] |

### Return type

**List&lt;Object&gt;**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Returns a list of articles for the specified account |  * ETag - Hash of the returned accounts for caching purposes <br>  |
| **401** | Unauthorized - Missing or invalid OAuth token |  -  |
| **403** | Forbidden - Insufficient permissions |  -  |
| **404** | Not Found - Account not found |  -  |

<a id="symplecticAccountsIds"></a>
# **symplecticAccountsIds**
> List&lt;SymplecticAccountsIds200ResponseInner&gt; symplecticAccountsIds(since)

Get changed accounts for Symplectic Elements

Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.auth.*;
import org.openapitools.client.models.*;
import org.openapitools.client.api.SymplecticApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: OAuth2
    OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
    OAuth2.setAccessToken("YOUR ACCESS TOKEN");

    SymplecticApi apiInstance = new SymplecticApi(defaultClient);
    String since = "2015-01-01 00:00:00"; // String | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
    try {
      List<SymplecticAccountsIds200ResponseInner> result = apiInstance.symplecticAccountsIds(since);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling SymplecticApi#symplecticAccountsIds");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **since** | **String**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | |

### Return type

[**List&lt;SymplecticAccountsIds200ResponseInner&gt;**](SymplecticAccountsIds200ResponseInner.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Returns a list of modified accounts |  * ETag - Hash of the returned accounts for caching purposes <br>  |
| **400** | Bad Request - Missing or invalid parameters |  -  |
| **401** | Unauthorized - Missing or invalid OAuth token |  -  |
| **403** | Forbidden - Insufficient permissions |  -  |

<a id="symplecticArticle"></a>
# **symplecticArticle**
> Object symplecticArticle(articleId)

Get article details for Symplectic Elements

Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.auth.*;
import org.openapitools.client.models.*;
import org.openapitools.client.api.SymplecticApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: OAuth2
    OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
    OAuth2.setAccessToken("YOUR ACCESS TOKEN");

    SymplecticApi apiInstance = new SymplecticApi(defaultClient);
    Integer articleId = 56; // Integer | Article ID
    try {
      Object result = apiInstance.symplecticArticle(articleId);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling SymplecticApi#symplecticArticle");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **articleId** | **Integer**| Article ID | |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Returns the article details with full metadata |  * ETag - Hash of the returned accounts for caching purposes <br>  |
| **401** | Unauthorized - Missing or invalid OAuth token |  -  |
| **403** | Forbidden - Insufficient permissions |  -  |
| **404** | Not Found - Article not found |  -  |

<a id="symplecticChangedArticles"></a>
# **symplecticChangedArticles**
> List&lt;Object&gt; symplecticChangedArticles(since, offset, limit, status, isEmbargoed)

Get changed articles for Symplectic Elements

Returns a list of articles for Symplectic Elements integration to synchronize article data.

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.auth.*;
import org.openapitools.client.models.*;
import org.openapitools.client.api.SymplecticApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: OAuth2
    OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
    OAuth2.setAccessToken("YOUR ACCESS TOKEN");

    SymplecticApi apiInstance = new SymplecticApi(defaultClient);
    String since = "2015-01-01 00:00:00"; // String | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
    Integer offset = 0; // Integer | Number of results to skip for pagination
    Integer limit = 10; // Integer | Maximum number of results to return
    String status = "public"; // String | Filter by article status
    String isEmbargoed = "true"; // String | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type
    try {
      List<Object> result = apiInstance.symplecticChangedArticles(since, offset, limit, status, isEmbargoed);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling SymplecticApi#symplecticChangedArticles");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **since** | **String**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | |
| **offset** | **Integer**| Number of results to skip for pagination | [optional] [default to 0] |
| **limit** | **Integer**| Maximum number of results to return | [optional] [default to 10] |
| **status** | **String**| Filter by article status | [optional] [enum: public, private, draft] |
| **isEmbargoed** | **String**| Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type | [optional] [enum: true, false] |

### Return type

**List&lt;Object&gt;**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Returns a list of symplectic articles |  * ETag - Hash of the returned accounts for caching purposes <br>  |
| **400** | Bad Request - Missing or invalid parameters |  -  |
| **401** | Unauthorized - Missing or invalid OAuth token |  -  |
| **403** | Forbidden - Insufficient permissions |  -  |

<a id="symplecticUserId"></a>
# **symplecticUserId**
> SymplecticUserId200Response symplecticUserId(userId)

Get institutional user ID for a user

Returns the institution user ID for a given user within the authenticated account&#39;s institution.

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.auth.*;
import org.openapitools.client.models.*;
import org.openapitools.client.api.SymplecticApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: OAuth2
    OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
    OAuth2.setAccessToken("YOUR ACCESS TOKEN");

    SymplecticApi apiInstance = new SymplecticApi(defaultClient);
    Integer userId = 56; // Integer | User ID
    try {
      SymplecticUserId200Response result = apiInstance.symplecticUserId(userId);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling SymplecticApi#symplecticUserId");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **userId** | **Integer**| User ID | |

### Return type

[**SymplecticUserId200Response**](SymplecticUserId200Response.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Returns the institutional user ID |  -  |
| **401** | Unauthorized - Missing or invalid OAuth token |  -  |
| **403** | Forbidden - Insufficient permissions |  -  |
| **404** | Not Found - User not found or user has no account in this institution |  -  |

