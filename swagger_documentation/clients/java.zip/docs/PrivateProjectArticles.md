
# PrivateProjectArticles

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**urlPublicHtml** | **String** | Public site endpoint for article | 
**urlPublicApi** | **String** | Public Api endpoint for article | 
**urlPrivateHtml** | **String** | Private site endpoint for article | 
**urlPrivateApi** | **String** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**thumb** | **String** | Thumbnail image | 
**definedType** | **Long** | Type of article identifier | 
**definedTypeName** | **String** | Name of the article type identifier | 
**resourceDoi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | 
**resourceTitle** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | 
**createdDate** | **String** | Date when article was created | 
**files** | [**List&lt;PublicFile&gt;**](PublicFile.md) | List of up to 10 article files. | 
**embargoOptions** | [**List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md) | List of embargo options | 
**customFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | List of custom fields values | 
**accountId** | **Long** | ID of the account owning the article | 
**downloadDisabled** | **Boolean** | If true, downloading of files for this article is disabled | 
**authors** | [**List&lt;Author&gt;**](Author.md) | List of authors | 
**figshareUrl** | **String** | Article public url | 



