
# PublicFileWithFolder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**files** | [**List&lt;PublicFile&gt;**](PublicFile.md) | List of files with folder information. | 
**folderStructure** | **Object** | Mapping of file ids to folder paths, if folders are used | 



