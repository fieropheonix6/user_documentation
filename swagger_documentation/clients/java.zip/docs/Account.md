

# Account


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** | Account id |  |
|**firstName** | **String** | First Name |  |
|**lastName** | **String** | Last Name |  |
|**usedQuotaPrivate** | **Integer** | Account used private quota |  |
|**modifiedDate** | **String** | Date of last account modification |  |
|**usedQuota** | **Integer** | Account total used quota |  |
|**createdDate** | **String** | Date when account was created |  |
|**quota** | **Integer** | Account quota |  |
|**groupId** | **Integer** | Account group id |  |
|**institutionUserId** | **String** | Account institution user id |  |
|**institutionId** | **Integer** | Account institution |  |
|**email** | **String** | User email |  |
|**usedQuotaPublic** | **Integer** | Account public used quota |  |
|**pendingQuotaRequest** | **Boolean** | True if a quota request is pending |  |
|**active** | **Integer** | Account activity status |  |
|**maximumFileSize** | **Integer** | Maximum upload size for account |  |
|**userId** | **Integer** | User id associated with account, useful for example for adding the account as an author to an item |  |
|**orcidId** | **String** | ORCID iD associated to account |  |
|**symplecticUserId** | **String** | Symplectic ID associated to account |  |



