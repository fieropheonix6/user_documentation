
# PrivateProjectArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**citation** | **String** | Article citation |  [optional]
**confidentialReason** | **String** | Confidentiality reason |  [optional]
**isConfidential** | **Boolean** | Article Confidentiality |  [optional]
**size** | **Long** | Article size |  [optional]
**funding** | **String** | Article funding |  [optional]
**fundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Article funding information |  [optional]
**keywords** | **List&lt;String&gt;** | List of article keywords |  [optional]
**version** | **Long** | Article version |  [optional]
**isMetadataRecord** | **Boolean** | True if article has no files |  [optional]
**metadataReason** | **String** | Article metadata reason |  [optional]
**status** | **String** | Article status |  [optional]
**description** | **String** | Article description |  [optional]
**isEmbargoed** | **Boolean** | True if article is embargoed |  [optional]
**isPublic** | **Boolean** | True if article is published |  [optional]
**createdDate** | **String** | Date when article was created | 
**hasLinkedFile** | **Boolean** | True if any files are linked to the article |  [optional]
**categories** | [**List&lt;Category&gt;**](Category.md) | List of categories selected for the article |  [optional]
**license** | [**License**](License.md) | Article selected license |  [optional]
**embargoTitle** | **String** | Title for embargo |  [optional]
**embargoReason** | **String** | Reason for embargo |  [optional]
**references** | **List&lt;String&gt;** | List of references |  [optional]
**relatedMaterials** | [**List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. |  [optional]
**id** | **Long** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**urlPublicHtml** | **String** | Public site endpoint for article | 
**urlPublicApi** | **String** | Public Api endpoint for article | 
**urlPrivateHtml** | **String** | Private site endpoint for article | 
**urlPrivateApi** | **String** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**thumb** | **String** | Thumbnail image | 
**definedType** | **Long** | Type of article identifier | 
**definedTypeName** | **String** | Name of the article type identifier | 
**resourceDoi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | 
**resourceTitle** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | 
**files** | [**List&lt;PublicFile&gt;**](PublicFile.md) | List of up to 10 article files. | 
**embargoOptions** | [**List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md) | List of embargo options | 
**customFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | List of custom fields values | 
**accountId** | **Long** | ID of the account owning the article | 
**downloadDisabled** | **Boolean** | If true, downloading of files for this article is disabled | 
**authors** | [**List&lt;Author&gt;**](Author.md) | List of authors | 
**figshareUrl** | **String** | Article public url | 
**curationStatus** | **String** | Curation status of the article | 



