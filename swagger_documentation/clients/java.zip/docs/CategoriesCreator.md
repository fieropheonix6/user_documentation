

# CategoriesCreator


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**categories** | **List&lt;Integer&gt;** | List of category ids |  |



