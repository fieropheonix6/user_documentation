

# CurationComment


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** | The ID of the comment. |  |
|**accountId** | **Integer** | The ID of the account which generated this comment. |  |
|**type** | [**TypeEnum**](#TypeEnum) | The ID of the account which generated this comment. |  |
|**text** | **String** | The value/content of the comment. |  |
|**createdDate** | **String** | The creation date of the comment. |  |
|**modifiedDate** | **String** | The date the comment has been modified. |  |



## Enum: TypeEnum

| Name | Value |
|---- | -----|
| COMMENT | &quot;comment&quot; |
| APPROVED | &quot;approved&quot; |
| REJECTED | &quot;rejected&quot; |
| CLOSED | &quot;closed&quot; |



