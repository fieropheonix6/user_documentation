import unittest

from flask import json

from openapi_server.models.altmetric_institution import AltmetricInstitution  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.test import BaseTestCase


class TestAltmetricController(BaseTestCase):
    """AltmetricController integration test stubs"""

    def test_altmetric_institutions_list(self):
        """Test case for altmetric_institutions_list

        List Altmetric Institutions
        """
        query_string = [('offset', 0)]
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/altmetric/institutions',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
