import connexion
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.altmetric_institution import AltmetricInstitution  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server import util


def altmetric_institutions_list(offset=None):  # noqa: E501
    """List Altmetric Institutions

    Returns a list of institutions available for Altmetric reporting # noqa: E501

    :param offset: Where to start the listing. The offset of the first item.
    :type offset: int

    :rtype: Union[List[AltmetricInstitution], Tuple[List[AltmetricInstitution], int], Tuple[List[AltmetricInstitution], int, Dict[str, str]]
    """
    return 'do some magic!'
