import connexion
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.article import Article  # noqa: E501
from openapi_server.models.articles_creator import ArticlesCreator  # noqa: E501
from openapi_server.models.author import Author  # noqa: E501
from openapi_server.models.authors_creator import AuthorsCreator  # noqa: E501
from openapi_server.models.categories_creator import CategoriesCreator  # noqa: E501
from openapi_server.models.category import Category  # noqa: E501
from openapi_server.models.collection import Collection  # noqa: E501
from openapi_server.models.collection_complete import CollectionComplete  # noqa: E501
from openapi_server.models.collection_complete_private import CollectionCompletePrivate  # noqa: E501
from openapi_server.models.collection_create import CollectionCreate  # noqa: E501
from openapi_server.models.collection_doi import CollectionDOI  # noqa: E501
from openapi_server.models.collection_handle import CollectionHandle  # noqa: E501
from openapi_server.models.collection_private_link_creator import CollectionPrivateLinkCreator  # noqa: E501
from openapi_server.models.collection_search import CollectionSearch  # noqa: E501
from openapi_server.models.collection_update import CollectionUpdate  # noqa: E501
from openapi_server.models.collection_versions import CollectionVersions  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.location import Location  # noqa: E501
from openapi_server.models.location_warnings import LocationWarnings  # noqa: E501
from openapi_server.models.location_warnings_update import LocationWarningsUpdate  # noqa: E501
from openapi_server.models.private_collection_search import PrivateCollectionSearch  # noqa: E501
from openapi_server.models.private_link import PrivateLink  # noqa: E501
from openapi_server.models.private_link_response import PrivateLinkResponse  # noqa: E501
from openapi_server.models.resource import Resource  # noqa: E501
from openapi_server import util


def collection_articles(collection_id, page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """Public Collection Articles

    Returns a list of public collection articles # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: Union[List[Article], Tuple[List[Article], int], Tuple[List[Article], int, Dict[str, str]]
    """
    return 'do some magic!'


def collection_details(collection_id):  # noqa: E501
    """Collection details

    View a collection # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: Union[CollectionComplete, Tuple[CollectionComplete, int], Tuple[CollectionComplete, int, Dict[str, str]]
    """
    return 'do some magic!'


def collection_version_details(collection_id, version_id):  # noqa: E501
    """Collection Version details

    View details for a certain version of a collection # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int
    :param version_id: Version Number
    :type version_id: int

    :rtype: Union[CollectionComplete, Tuple[CollectionComplete, int], Tuple[CollectionComplete, int, Dict[str, str]]
    """
    return 'do some magic!'


def collection_versions(collection_id):  # noqa: E501
    """Collection Versions list

    Returns a list of public collection Versions # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: Union[List[CollectionVersions], Tuple[List[CollectionVersions], int], Tuple[List[CollectionVersions], int, Dict[str, str]]
    """
    return 'do some magic!'


def collections_list(x_cursor=None, page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, institution=None, published_since=None, modified_since=None, group=None, resource_doi=None, doi=None, handle=None):  # noqa: E501
    """Public Collections

    Returns a list of public collections # noqa: E501

    :param x_cursor: Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
    :type x_cursor: str
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param institution: only return collections from this institution
    :type institution: int
    :param published_since: Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
    :type published_since: str
    :param modified_since: Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD
    :type modified_since: str
    :param group: only return collections from this group
    :type group: int
    :param resource_doi: only return collections with this resource_doi
    :type resource_doi: str
    :param doi: only return collections with this doi
    :type doi: str
    :param handle: only return collections with this handle
    :type handle: str

    :rtype: Union[List[Collection], Tuple[List[Collection], int], Tuple[List[Collection], int, Dict[str, str]]
    """
    return 'do some magic!'


def collections_search(x_cursor=None, search=None):  # noqa: E501
    """Public Collections Search

    Returns a list of public collections # noqa: E501

    :param x_cursor: Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
    :type x_cursor: str
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: Union[List[Collection], Tuple[List[Collection], int], Tuple[List[Collection], int, Dict[str, str]]
    """
    if connexion.request.is_json:
        search = CollectionSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_article_delete(collection_id, article_id):  # noqa: E501
    """Delete collection article

    De-associate article from collection # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param article_id: Collection article unique identifier
    :type article_id: int

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_articles_add(collection_id, articles):  # noqa: E501
    """Add collection articles

    Associate new articles with the collection. This will add new articles to the list of already associated articles # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param articles: Articles list
    :type articles: dict | bytes

    :rtype: Union[Location, Tuple[Location, int], Tuple[Location, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        articles = ArticlesCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_articles_list(collection_id, page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """List collection articles

    List collection articles # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: Union[List[Article], Tuple[List[Article], int], Tuple[List[Article], int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_articles_replace(collection_id, articles):  # noqa: E501
    """Replace collection articles

    Associate new articles with the collection. This will remove all already associated articles and add these new ones # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param articles: Articles List
    :type articles: dict | bytes

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        articles = ArticlesCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_author_delete(collection_id, author_id):  # noqa: E501
    """Delete collection author

    Delete collection author # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param author_id: Collection Author unique identifier
    :type author_id: int

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_authors_add(collection_id, authors):  # noqa: E501
    """Add collection authors

    Associate new authors with the collection. This will add new authors to the list of already associated authors # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param authors: List of authors
    :type authors: dict | bytes

    :rtype: Union[Location, Tuple[Location, int], Tuple[Location, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        authors = AuthorsCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_authors_list(collection_id):  # noqa: E501
    """List collection authors

    List collection authors # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int

    :rtype: Union[List[Author], Tuple[List[Author], int], Tuple[List[Author], int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_authors_replace(collection_id, authors):  # noqa: E501
    """Replace collection authors

    Associate new authors with the collection. This will remove all already associated authors and add these new ones # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param authors: List of authors
    :type authors: dict | bytes

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        authors = AuthorsCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_categories_add(collection_id, categories):  # noqa: E501
    """Add collection categories

    Associate new categories with the collection. This will add new categories to the list of already associated categories # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param categories: Categories list
    :type categories: dict | bytes

    :rtype: Union[Location, Tuple[Location, int], Tuple[Location, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        categories = CategoriesCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_categories_list(collection_id):  # noqa: E501
    """List collection categories

    List collection categories # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int

    :rtype: Union[List[Category], Tuple[List[Category], int], Tuple[List[Category], int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_categories_replace(collection_id, categories):  # noqa: E501
    """Replace collection categories

    Associate new categories with the collection. This will remove all already associated categories and add these new ones # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param categories: Categories list
    :type categories: dict | bytes

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        categories = CategoriesCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_category_delete(collection_id, category_id):  # noqa: E501
    """Delete collection category

    De-associate category from collection # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param category_id: Collection category unique identifier
    :type category_id: int

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_create(collection):  # noqa: E501
    """Create collection

    Create a new Collection by sending collection information # noqa: E501

    :param collection: Collection description
    :type collection: dict | bytes

    :rtype: Union[LocationWarnings, Tuple[LocationWarnings, int], Tuple[LocationWarnings, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        collection = CollectionCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_delete(collection_id):  # noqa: E501
    """Delete collection

    Delete n collection # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_details(collection_id):  # noqa: E501
    """Collection details

    View a collection # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: Union[CollectionCompletePrivate, Tuple[CollectionCompletePrivate, int], Tuple[CollectionCompletePrivate, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_patch(collection_id, collection):  # noqa: E501
    """Partially update collection

    Partially update a collection by sending only the fields to change. # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int
    :param collection: Subset of collection fields to update
    :type collection: dict | bytes

    :rtype: Union[LocationWarningsUpdate, Tuple[LocationWarningsUpdate, int], Tuple[LocationWarningsUpdate, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        collection = CollectionUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_private_link_create(collection_id, private_link=None):  # noqa: E501
    """Create collection private link

    Create new private link # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param private_link: 
    :type private_link: dict | bytes

    :rtype: Union[PrivateLinkResponse, Tuple[PrivateLinkResponse, int], Tuple[PrivateLinkResponse, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        private_link = CollectionPrivateLinkCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_private_link_delete(collection_id, link_id):  # noqa: E501
    """Disable private link

    Disable/delete private link for this collection # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param link_id: Private link token
    :type link_id: str

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_private_link_details(collection_id, link_id):  # noqa: E501
    """View collection private link

    View existing private link for this collection # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param link_id: Private link token
    :type link_id: str

    :rtype: Union[PrivateLink, Tuple[PrivateLink, int], Tuple[PrivateLink, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_private_link_update(collection_id, link_id, private_link=None):  # noqa: E501
    """Update collection private link

    Update existing private link for this collection # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param link_id: Private link token
    :type link_id: str
    :param private_link: 
    :type private_link: dict | bytes

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        private_link = CollectionPrivateLinkCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_private_links_list(collection_id):  # noqa: E501
    """List collection private links

    List article private links # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int

    :rtype: Union[List[PrivateLink], Tuple[List[PrivateLink], int], Tuple[List[PrivateLink], int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_publish(collection_id):  # noqa: E501
    """Private Collection Publish

    When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed. # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: Union[Location, Tuple[Location, int], Tuple[Location, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_reserve_doi(collection_id):  # noqa: E501
    """Private Collection Reserve DOI

    Reserve DOI for collection # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: Union[CollectionDOI, Tuple[CollectionDOI, int], Tuple[CollectionDOI, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_reserve_handle(collection_id):  # noqa: E501
    """Private Collection Reserve Handle

    Reserve Handle for collection # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: Union[CollectionHandle, Tuple[CollectionHandle, int], Tuple[CollectionHandle, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collection_resource(collection_id, resource):  # noqa: E501
    """Private Collection Resource

    Edit collection resource data. # noqa: E501

    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param resource: Resource data
    :type resource: dict | bytes

    :rtype: Union[Location, Tuple[Location, int], Tuple[Location, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        resource = Resource.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collection_update(collection_id, collection):  # noqa: E501
    """Update collection

    Update a collection by passing full body parameters. # noqa: E501

    :param collection_id: Collection Unique identifier
    :type collection_id: int
    :param collection: Collection description
    :type collection: dict | bytes

    :rtype: Union[LocationWarningsUpdate, Tuple[LocationWarningsUpdate, int], Tuple[LocationWarningsUpdate, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        collection = CollectionUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_collections_list(page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None):  # noqa: E501
    """Private Collections List

    List private collections # noqa: E501

    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str

    :rtype: Union[List[Collection], Tuple[List[Collection], int], Tuple[List[Collection], int, Dict[str, str]]
    """
    return 'do some magic!'


def private_collections_search(search):  # noqa: E501
    """Private Collections Search

    Returns a list of private Collections # noqa: E501

    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: Union[List[Collection], Tuple[List[Collection], int], Tuple[List[Collection], int, Dict[str, str]]
    """
    if connexion.request.is_json:
        search = PrivateCollectionSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
