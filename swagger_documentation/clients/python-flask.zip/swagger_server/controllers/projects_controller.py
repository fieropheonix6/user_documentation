import connexion
import six

from swagger_server.models.article import Article  # noqa: E501
from swagger_server.models.article_project_create import ArticleProjectCreate  # noqa: E501
from swagger_server.models.create_project_response import CreateProjectResponse  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.location import Location  # noqa: E501
from swagger_server.models.private_file import PrivateFile  # noqa: E501
from swagger_server.models.private_project_article import PrivateProjectArticle  # noqa: E501
from swagger_server.models.project import Project  # noqa: E501
from swagger_server.models.project_article import ProjectArticle  # noqa: E501
from swagger_server.models.project_collaborator import ProjectCollaborator  # noqa: E501
from swagger_server.models.project_collaborator_invite import ProjectCollaboratorInvite  # noqa: E501
from swagger_server.models.project_complete import ProjectComplete  # noqa: E501
from swagger_server.models.project_complete_private import ProjectCompletePrivate  # noqa: E501
from swagger_server.models.project_create import ProjectCreate  # noqa: E501
from swagger_server.models.project_note import ProjectNote  # noqa: E501
from swagger_server.models.project_note_create import ProjectNoteCreate  # noqa: E501
from swagger_server.models.project_note_private import ProjectNotePrivate  # noqa: E501
from swagger_server.models.project_private import ProjectPrivate  # noqa: E501
from swagger_server.models.project_update import ProjectUpdate  # noqa: E501
from swagger_server.models.projects_search import ProjectsSearch  # noqa: E501
from swagger_server.models.response_message import ResponseMessage  # noqa: E501
from swagger_server import util


def private_project_article_delete(project_id, article_id):  # noqa: E501
    """Delete project article

    Delete project article # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_project_article_details(project_id, article_id):  # noqa: E501
    """Project article details

    Project article details # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int

    :rtype: ProjectArticle
    """
    return 'do some magic!'


def private_project_article_file(project_id, article_id, file_id):  # noqa: E501
    """Project article file details

    Project article file details # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int
    :param file_id: File unique identifier
    :type file_id: int

    :rtype: PrivateFile
    """
    return 'do some magic!'


def private_project_article_files(project_id, article_id):  # noqa: E501
    """Project article list files

    List article files # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int

    :rtype: List[PrivateFile]
    """
    return 'do some magic!'


def private_project_articles_create(project_id, Article):  # noqa: E501
    """Create project article

    Create a new Article and associate it with this project # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param Article: Article description
    :type Article: dict | bytes

    :rtype: Location
    """
    if connexion.request.is_json:
        Article = ArticleProjectCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_articles_list(project_id):  # noqa: E501
    """List project articles

    List project articles # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: List[PrivateProjectArticle]
    """
    return 'do some magic!'


def private_project_collaborator_delete(project_id, user_id):  # noqa: E501
    """Remove project collaborator

    Remove project collaborator # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param user_id: User unique identifier
    :type user_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_project_collaborators_invite(project_id, Collaborator):  # noqa: E501
    """Invite project collaborators

    Invite users to collaborate on project or view the project # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param Collaborator: viewer or collaborator role. User user_id or email of user
    :type Collaborator: dict | bytes

    :rtype: ResponseMessage
    """
    if connexion.request.is_json:
        Collaborator = ProjectCollaboratorInvite.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_collaborators_list(project_id):  # noqa: E501
    """List project collaborators

    List Project collaborators and invited users # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: List[ProjectCollaborator]
    """
    return 'do some magic!'


def private_project_create(Project):  # noqa: E501
    """Create project

    Create a new project # noqa: E501

    :param Project: Project  description
    :type Project: dict | bytes

    :rtype: CreateProjectResponse
    """
    if connexion.request.is_json:
        Project = ProjectCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_delete(project_id):  # noqa: E501
    """Delete project

    A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project.  # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_project_details(project_id):  # noqa: E501
    """View project details

    View a private project # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: ProjectCompletePrivate
    """
    return 'do some magic!'


def private_project_leave(project_id):  # noqa: E501
    """Private Project Leave

    Please note: project&#39;s owner cannot leave the project. # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_project_note(project_id, note_id):  # noqa: E501
    """Project note details

     # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param note_id: Note unique identifier
    :type note_id: int

    :rtype: ProjectNotePrivate
    """
    return 'do some magic!'


def private_project_note_delete(project_id, note_id):  # noqa: E501
    """Delete project note

     # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param note_id: Note unique identifier
    :type note_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_project_note_update(project_id, note_id, Note):  # noqa: E501
    """Update project note

     # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param note_id: Note unique identifier
    :type note_id: int
    :param Note: Note message
    :type Note: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Note = ProjectNoteCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_notes_create(project_id, Note):  # noqa: E501
    """Create project note

    Create a new project note # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param Note: Note message
    :type Note: dict | bytes

    :rtype: Location
    """
    if connexion.request.is_json:
        Note = ProjectNoteCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_notes_list(project_id, page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """List project notes

    List project notes # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: List[ProjectNote]
    """
    return 'do some magic!'


def private_project_publish(project_id):  # noqa: E501
    """Private Project Publish

    Publish a project. Possible after all items inside it are public # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: ResponseMessage
    """
    return 'do some magic!'


def private_project_update(project_id, Project):  # noqa: E501
    """Update project

    Updating an project by passing body parameters; request can also be made with the PATCH method. # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param Project: Project description
    :type Project: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Project = ProjectUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_projects_list(page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, storage=None, roles=None):  # noqa: E501
    """Private Projects

    List private projects # noqa: E501

    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param storage: only return collections from this institution
    :type storage: str
    :param roles: Any combination of owner, collaborator, viewer separated by comma. Examples: \&quot;owner\&quot; or \&quot;owner,collaborator\&quot;.
    :type roles: str

    :rtype: List[ProjectPrivate]
    """
    return 'do some magic!'


def private_projects_search(search=None):  # noqa: E501
    """Private Projects search

    Search inside the private projects # noqa: E501

    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[ProjectPrivate]
    """
    if connexion.request.is_json:
        search = ProjectsSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def project_articles(project_id, page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """Public Project Articles

    List articles in project # noqa: E501

    :param project_id: Project Unique identifier
    :type project_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: List[Article]
    """
    return 'do some magic!'


def project_details(project_id):  # noqa: E501
    """Public Project

    View a project # noqa: E501

    :param project_id: Project Unique identifier
    :type project_id: int

    :rtype: ProjectComplete
    """
    return 'do some magic!'


def projects_list(X_Cursor=None, page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, institution=None, published_since=None, group=None):  # noqa: E501
    """Public Projects

    Returns a list of public projects # noqa: E501

    :param X_Cursor: Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
    :type X_Cursor: 
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param institution: only return collections from this institution
    :type institution: int
    :param published_since: Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
    :type published_since: str
    :param group: only return collections from this group
    :type group: int

    :rtype: List[Project]
    """
    return 'do some magic!'


def projects_search(X_Cursor=None, search=None):  # noqa: E501
    """Public Projects Search

    Returns a list of public articles # noqa: E501

    :param X_Cursor: Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
    :type X_Cursor: 
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[Project]
    """
    if connexion.request.is_json:
        search = ProjectsSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
