import connexion
import six

from swagger_server.models.create_o_auth_token import CreateOAuthToken  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.o_auth_token import OAuthToken  # noqa: E501
from swagger_server import util


def create_token(body=None):  # noqa: E501
    """Create OAuth token

    Creates OAuth token using various grant types # noqa: E501

    :param body: Create OAuth Token Parameters
    :type body: dict | bytes

    :rtype: OAuthToken
    """
    if connexion.request.is_json:
        body = CreateOAuthToken.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def get_token_info(access_token=None):  # noqa: E501
    """Get OAuth token information

    Returns information about the current OAuth token # noqa: E501

    :param access_token: OAuth access token
    :type access_token: str

    :rtype: OAuthToken
    """
    return 'do some magic!'
