import connexion
import six

from swagger_server.models.account_report import AccountReport  # noqa: E501
from swagger_server.models.article import Article  # noqa: E501
from swagger_server.models.article_complete import ArticleComplete  # noqa: E501
from swagger_server.models.article_complete_private import ArticleCompletePrivate  # noqa: E501
from swagger_server.models.article_confidentiality import ArticleConfidentiality  # noqa: E501
from swagger_server.models.article_create import ArticleCreate  # noqa: E501
from swagger_server.models.article_doi import ArticleDOI  # noqa: E501
from swagger_server.models.article_embargo import ArticleEmbargo  # noqa: E501
from swagger_server.models.article_embargo_updater import ArticleEmbargoUpdater  # noqa: E501
from swagger_server.models.article_handle import ArticleHandle  # noqa: E501
from swagger_server.models.article_search import ArticleSearch  # noqa: E501
from swagger_server.models.article_unpublish_data import ArticleUnpublishData  # noqa: E501
from swagger_server.models.article_update import ArticleUpdate  # noqa: E501
from swagger_server.models.article_version_update import ArticleVersionUpdate  # noqa: E501
from swagger_server.models.article_versions import ArticleVersions  # noqa: E501
from swagger_server.models.article_with_project import ArticleWithProject  # noqa: E501
from swagger_server.models.author import Author  # noqa: E501
from swagger_server.models.authors_creator import AuthorsCreator  # noqa: E501
from swagger_server.models.categories_creator import CategoriesCreator  # noqa: E501
from swagger_server.models.category import Category  # noqa: E501
from swagger_server.models.confidentiality_creator import ConfidentialityCreator  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.file_creator import FileCreator  # noqa: E501
from swagger_server.models.file_id import FileId  # noqa: E501
from swagger_server.models.location import Location  # noqa: E501
from swagger_server.models.location_warnings import LocationWarnings  # noqa: E501
from swagger_server.models.location_warnings_update import LocationWarningsUpdate  # noqa: E501
from swagger_server.models.private_article_search import PrivateArticleSearch  # noqa: E501
from swagger_server.models.private_file import PrivateFile  # noqa: E501
from swagger_server.models.private_link import PrivateLink  # noqa: E501
from swagger_server.models.private_link_creator import PrivateLinkCreator  # noqa: E501
from swagger_server.models.private_link_response import PrivateLinkResponse  # noqa: E501
from swagger_server.models.public_file import PublicFile  # noqa: E501
from swagger_server.models.resource import Resource  # noqa: E501
from swagger_server import util


def account_article_publish(article_id):  # noqa: E501
    """Private Article Publish

    - If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: Location
    """
    return 'do some magic!'


def account_article_report(group_id=None):  # noqa: E501
    """Account Article Report

    Return status on all reports generated for the account from the oauth credentials # noqa: E501

    :param group_id: A group ID to filter by
    :type group_id: int

    :rtype: List[AccountReport]
    """
    return 'do some magic!'


def account_article_report_generate():  # noqa: E501
    """Initiate a new Report

    Initiate a new Article Report for this Account. There is a limit of 1 report per day. # noqa: E501


    :rtype: AccountReport
    """
    return 'do some magic!'


def account_article_unpublish(article_id, reason):  # noqa: E501
    """Public Article Unpublish

    Allows authorized users to unpublish an article. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param reason: Article unpublish data
    :type reason: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        reason = ArticleUnpublishData.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def article_details(article_id):  # noqa: E501
    """View article details

    View an article # noqa: E501

    :param article_id: Article Unique identifier
    :type article_id: int

    :rtype: ArticleComplete
    """
    return 'do some magic!'


def article_file_details(article_id, file_id):  # noqa: E501
    """Article file details

    File by id # noqa: E501

    :param article_id: Article Unique identifier
    :type article_id: int
    :param file_id: File Unique identifier
    :type file_id: int

    :rtype: PublicFile
    """
    return 'do some magic!'


def article_files(article_id, page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """List article files

    Files list for article # noqa: E501

    :param article_id: Article Unique identifier
    :type article_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: List[PublicFile]
    """
    return 'do some magic!'


def article_version_confidentiality(article_id, version_id):  # noqa: E501
    """Public Article Confidentiality for article version

    Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows. # noqa: E501

    :param article_id: Article Unique identifier
    :type article_id: int
    :param version_id: Version Number
    :type version_id: int

    :rtype: ArticleConfidentiality
    """
    return 'do some magic!'


def article_version_details(article_id, version_id):  # noqa: E501
    """Article details for version

    Article with specified version # noqa: E501

    :param article_id: Article Unique identifier
    :type article_id: int
    :param version_id: Article Version Number
    :type version_id: int

    :rtype: ArticleComplete
    """
    return 'do some magic!'


def article_version_embargo(article_id, version_id):  # noqa: E501
    """Public Article Embargo for article version

    Embargo for article version # noqa: E501

    :param article_id: Article Unique identifier
    :type article_id: int
    :param version_id: Version Number
    :type version_id: int

    :rtype: ArticleEmbargo
    """
    return 'do some magic!'


def article_version_files(article_id, version_id, page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """Article version file details

    File by version id # noqa: E501

    :param article_id: Article Unique identifier
    :type article_id: int
    :param version_id: Article Version Unique identifier
    :type version_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: List[PublicFile]
    """
    return 'do some magic!'


def article_version_partial_update(article_id, version_id, Article):  # noqa: E501
    """Partially update article version

    Partially updating an article version by passing only the fields to change. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param version_id: Article version identifier
    :type version_id: int
    :param Article: Subset of article version fields to update
    :type Article: dict | bytes

    :rtype: LocationWarningsUpdate
    """
    if connexion.request.is_json:
        Article = ArticleVersionUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def article_version_update(article_id, version_id, Article):  # noqa: E501
    """Update article version

    Updating an article version by passing body parameters. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param version_id: Article version identifier
    :type version_id: int
    :param Article: Article description
    :type Article: dict | bytes

    :rtype: LocationWarningsUpdate
    """
    if connexion.request.is_json:
        Article = ArticleVersionUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def article_version_update_thumb(article_id, version_id, FileId):  # noqa: E501
    """Update article version thumbnail

    For a given public article version update the article thumbnail by choosing one of the associated files # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param version_id: Article version identifier
    :type version_id: int
    :param FileId: File ID
    :type FileId: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        FileId = FileId.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def article_versions(article_id):  # noqa: E501
    """List article versions

    List public article versions # noqa: E501

    :param article_id: Article Unique identifier
    :type article_id: int

    :rtype: List[ArticleVersions]
    """
    return 'do some magic!'


def articles_list(X_Cursor=None, page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, institution=None, published_since=None, modified_since=None, group=None, resource_doi=None, item_type=None, doi=None, handle=None):  # noqa: E501
    """Public Articles

    Returns a list of public articles # noqa: E501

    :param X_Cursor: Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
    :type X_Cursor: 
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param institution: only return articles from this institution
    :type institution: int
    :param published_since: Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
    :type published_since: str
    :param modified_since: Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
    :type modified_since: str
    :param group: only return articles from this group
    :type group: int
    :param resource_doi: Deprecated by related materials. Only return articles with this resource_doi
    :type resource_doi: str
    :param item_type: Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
    :type item_type: int
    :param doi: only return articles with this doi
    :type doi: str
    :param handle: only return articles with this handle
    :type handle: str

    :rtype: List[Article]
    """
    return 'do some magic!'


def articles_search(X_Cursor=None, search=None):  # noqa: E501
    """Public Articles Search

    Returns a list of public articles, filtered by the search parameters # noqa: E501

    :param X_Cursor: Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
    :type X_Cursor: 
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[ArticleWithProject]
    """
    if connexion.request.is_json:
        search = ArticleSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_author_delete(article_id, author_id):  # noqa: E501
    """Delete article author

    De-associate author from article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param author_id: Article Author unique identifier
    :type author_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_article_authors_add(article_id, Authors):  # noqa: E501
    """Add article authors

    Associate new authors with the article. This will add new authors to the list of already associated authors # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param Authors: Authors description
    :type Authors: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Authors = AuthorsCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_authors_list(article_id):  # noqa: E501
    """List article authors

    List article authors # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: List[Author]
    """
    return 'do some magic!'


def private_article_authors_replace(article_id, Authors):  # noqa: E501
    """Replace article authors

    Associate new authors with the article. This will remove all already associated authors and add these new ones # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param Authors: Authors description
    :type Authors: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Authors = AuthorsCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_categories_add(article_id, categories):  # noqa: E501
    """Add article categories

    Associate new categories with the article. This will add new categories to the list of already associated categories # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param categories: 
    :type categories: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        categories = CategoriesCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_categories_list(article_id):  # noqa: E501
    """List article categories

    List article categories # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: List[Category]
    """
    return 'do some magic!'


def private_article_categories_replace(article_id, categories):  # noqa: E501
    """Replace article categories

    Associate new categories with the article. This will remove all already associated categories and add these new ones # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param categories: 
    :type categories: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        categories = CategoriesCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_category_delete(article_id, category_id):  # noqa: E501
    """Delete article category

    De-associate category from article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param category_id: Category unique identifier
    :type category_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_article_confidentiality_delete(article_id):  # noqa: E501
    """Delete article confidentiality

    Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_article_confidentiality_details(article_id):  # noqa: E501
    """Article confidentiality details

    View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: ArticleConfidentiality
    """
    return 'do some magic!'


def private_article_confidentiality_update(article_id, reason):  # noqa: E501
    """Update article confidentiality

    Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param reason: 
    :type reason: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        reason = ConfidentialityCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_create(Article):  # noqa: E501
    """Create new Article

    Create a new Article by sending article information # noqa: E501

    :param Article: Article description
    :type Article: dict | bytes

    :rtype: LocationWarnings
    """
    if connexion.request.is_json:
        Article = ArticleCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_delete(article_id):  # noqa: E501
    """Delete article

    Delete an article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_article_details(article_id):  # noqa: E501
    """Article details

    View a private article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: ArticleCompletePrivate
    """
    return 'do some magic!'


def private_article_download(article_id, folder_path=None):  # noqa: E501
    """Private Article Download

    Download files from a private article preserving the folder structure # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param folder_path: Folder path to download. If not provided, all files from the article will be downloaded
    :type folder_path: str

    :rtype: None
    """
    return 'do some magic!'


def private_article_embargo_delete(article_id):  # noqa: E501
    """Delete Article Embargo

    Will lift the embargo for the specified article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_article_embargo_details(article_id):  # noqa: E501
    """Article Embargo Details

    View a private article embargo details # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: ArticleEmbargo
    """
    return 'do some magic!'


def private_article_embargo_update(article_id, Embargo):  # noqa: E501
    """Update Article Embargo

    Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param Embargo: Embargo description
    :type Embargo: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Embargo = ArticleEmbargoUpdater.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_file(article_id, file_id):  # noqa: E501
    """Single File

    View details of file for specified article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param file_id: File unique identifier
    :type file_id: int

    :rtype: PrivateFile
    """
    return 'do some magic!'


def private_article_file_delete(article_id, file_id):  # noqa: E501
    """File Delete

    Complete file upload # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param file_id: File unique identifier
    :type file_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_article_files_list(article_id, page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """List article files

    List private files # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: List[PrivateFile]
    """
    return 'do some magic!'


def private_article_partial_update(article_id, Article):  # noqa: E501
    """Partially update article

    Partially update an article by sending only the fields to change. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param Article: Subset of article fields to update
    :type Article: dict | bytes

    :rtype: LocationWarningsUpdate
    """
    if connexion.request.is_json:
        Article = ArticleUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_private_link(article_id):  # noqa: E501
    """List private links

    List private links # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: List[PrivateLink]
    """
    return 'do some magic!'


def private_article_private_link_create(article_id, private_link=None):  # noqa: E501
    """Create private link

    Create new private link for this article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param private_link: 
    :type private_link: dict | bytes

    :rtype: PrivateLinkResponse
    """
    if connexion.request.is_json:
        private_link = PrivateLinkCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_private_link_delete(article_id, link_id):  # noqa: E501
    """Disable private link

    Disable/delete private link for this article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param link_id: Private link token
    :type link_id: str

    :rtype: None
    """
    return 'do some magic!'


def private_article_private_link_update(article_id, link_id, private_link=None):  # noqa: E501
    """Update private link

    Update existing private link for this article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param link_id: Private link token
    :type link_id: str
    :param private_link: 
    :type private_link: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        private_link = PrivateLinkCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_reserve_doi(article_id):  # noqa: E501
    """Private Article Reserve DOI

    Reserve DOI for article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: ArticleDOI
    """
    return 'do some magic!'


def private_article_reserve_handle(article_id):  # noqa: E501
    """Private Article Reserve Handle

    Reserve Handle for article # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int

    :rtype: ArticleHandle
    """
    return 'do some magic!'


def private_article_resource(article_id, Resource):  # noqa: E501
    """Private Article Resource

    Edit article resource data. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param Resource: Resource data
    :type Resource: dict | bytes

    :rtype: Location
    """
    if connexion.request.is_json:
        Resource = Resource.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_update(article_id, Article):  # noqa: E501
    """Update article

    Update an article by passing full body parameters. # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param Article: Full article representation
    :type Article: dict | bytes

    :rtype: LocationWarningsUpdate
    """
    if connexion.request.is_json:
        Article = ArticleUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_article_upload_complete(article_id, file_id):  # noqa: E501
    """Complete Upload

    Complete file upload # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param file_id: File unique identifier
    :type file_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_article_upload_initiate(article_id, File, page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """Initiate Upload

    Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size). # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param File: 
    :type File: dict | bytes
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: Location
    """
    if connexion.request.is_json:
        File = FileCreator.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_articles_list(page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """Private Articles

    Get Own Articles # noqa: E501

    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: List[Article]
    """
    return 'do some magic!'


def private_articles_search(search):  # noqa: E501
    """Private Articles search

    Returns a list of private articles filtered by the search parameters # noqa: E501

    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[ArticleWithProject]
    """
    if connexion.request.is_json:
        search = PrivateArticleSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def public_article_download(article_id, folder_path=None):  # noqa: E501
    """Public Article Download

    Download files from a public article preserving the folder structure # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param folder_path: Folder path to download. If not provided, all files from the article will be downloaded
    :type folder_path: str

    :rtype: None
    """
    return 'do some magic!'


def public_article_version_download(article_id, version_id, folder_path=None):  # noqa: E501
    """Public Article Version Download

    Download files from a certain version of an public article preserving the folder structure # noqa: E501

    :param article_id: Article unique identifier
    :type article_id: int
    :param version_id: Version Number
    :type version_id: int
    :param folder_path: Folder path to download. If not provided, all files from the article will be downloaded
    :type folder_path: str

    :rtype: None
    """
    return 'do some magic!'
