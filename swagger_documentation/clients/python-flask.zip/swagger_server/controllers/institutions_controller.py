import connexion
import six

from swagger_server.models.account_create import AccountCreate  # noqa: E501
from swagger_server.models.account_create_response import AccountCreateResponse  # noqa: E501
from swagger_server.models.account_group_roles import AccountGroupRoles  # noqa: E501
from swagger_server.models.account_group_roles_create import AccountGroupRolesCreate  # noqa: E501
from swagger_server.models.account_update import AccountUpdate  # noqa: E501
from swagger_server.models.article import Article  # noqa: E501
from swagger_server.models.category import Category  # noqa: E501
from swagger_server.models.curation import Curation  # noqa: E501
from swagger_server.models.curation_comment import CurationComment  # noqa: E501
from swagger_server.models.curation_comment_create import CurationCommentCreate  # noqa: E501
from swagger_server.models.curation_detail import CurationDetail  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.group import Group  # noqa: E501
from swagger_server.models.group_embargo_options import GroupEmbargoOptions  # noqa: E501
from swagger_server.models.institution import Institution  # noqa: E501
from swagger_server.models.institution_accounts_search import InstitutionAccountsSearch  # noqa: E501
from swagger_server.models.response_message import ResponseMessage  # noqa: E501
from swagger_server.models.role import Role  # noqa: E501
from swagger_server.models.short_account import ShortAccount  # noqa: E501
from swagger_server.models.short_custom_field import ShortCustomField  # noqa: E501
from swagger_server.models.user import User  # noqa: E501
from swagger_server import util


def account_institution_curation(curation_id):  # noqa: E501
    """Institution Curation Review

    Retrieve a certain curation review by its ID # noqa: E501

    :param curation_id: ID of the curation
    :type curation_id: int

    :rtype: CurationDetail
    """
    return 'do some magic!'


def account_institution_curations(group_id=None, article_id=None, status=None, limit=None, offset=None):  # noqa: E501
    """Institution Curation Reviews

    Retrieve a list of curation reviews for this institution # noqa: E501

    :param group_id: Filter by the group ID
    :type group_id: int
    :param article_id: Retrieve the reviews for this article
    :type article_id: int
    :param status: Filter by the status of the review
    :type status: str
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: Curation
    """
    return 'do some magic!'


def custom_fields_list(group_id=None):  # noqa: E501
    """Private account institution group custom fields

    Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access. # noqa: E501

    :param group_id: Group_id
    :type group_id: int

    :rtype: List[ShortCustomField]
    """
    return 'do some magic!'


def custom_fields_upload(custom_field_id, external_file=None):  # noqa: E501
    """Custom fields values files upload

    Uploads a CSV containing values for a specific custom field of type &lt;b&gt;dropdown_large_list&lt;/b&gt;. More details in the &lt;a href&#x3D;\&quot;#custom_fields\&quot;&gt;Custom Fields section&lt;/a&gt; # noqa: E501

    :param custom_field_id: Custom field identifier
    :type custom_field_id: int
    :param external_file: CSV file to be uploaded
    :type external_file: werkzeug.datastructures.FileStorage

    :rtype: object
    """
    return 'do some magic!'


def get_account_institution_curation_comments(curation_id, limit=None, offset=None):  # noqa: E501
    """Institution Curation Review Comments

    Retrieve a certain curation review&#39;s comments. # noqa: E501

    :param curation_id: ID of the curation
    :type curation_id: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: CurationComment
    """
    return 'do some magic!'


def institution_articles(institution_string_id, resource_id, filename):  # noqa: E501
    """Public Institution Articles

    Returns a list of articles belonging to the institution # noqa: E501

    :param institution_string_id: 
    :type institution_string_id: str
    :param resource_id: 
    :type resource_id: str
    :param filename: 
    :type filename: str

    :rtype: List[Article]
    """
    return 'do some magic!'


def institution_hrfeed_upload(hrfeed=None):  # noqa: E501
    """Private Institution HRfeed Upload

    More info in the &lt;a href&#x3D;\&quot;#hr_feed\&quot;&gt;HR Feed section&lt;/a&gt; # noqa: E501

    :param hrfeed: You can find an example in the Hr Feed section
    :type hrfeed: werkzeug.datastructures.FileStorage

    :rtype: ResponseMessage
    """
    return 'do some magic!'


def post_account_institution_curation_comments(curation_id, CurationComment):  # noqa: E501
    """POST Institution Curation Review Comment

    Add a new comment to the review. # noqa: E501

    :param curation_id: ID of the curation
    :type curation_id: int
    :param CurationComment: The content/value of the comment.
    :type CurationComment: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        CurationComment = CurationCommentCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_account_institution_user(account_id):  # noqa: E501
    """Private Account Institution User

    Retrieve institution user information using the account_id # noqa: E501

    :param account_id: Account identifier the user is associated to
    :type account_id: int

    :rtype: User
    """
    return 'do some magic!'


def private_categories_list():  # noqa: E501
    """Private Account Categories

    List institution categories (including parent Categories) # noqa: E501


    :rtype: List[Category]
    """
    return 'do some magic!'


def private_group_embargo_options_details(group_id):  # noqa: E501
    """Private Account Institution Group Embargo Options

    Account institution group embargo options details # noqa: E501

    :param group_id: Group identifier
    :type group_id: int

    :rtype: List[GroupEmbargoOptions]
    """
    return 'do some magic!'


def private_institution_account_group_role_delete(account_id, group_id, role_id):  # noqa: E501
    """Delete Institution Account Group Role

    Delete Institution Account Group Role # noqa: E501

    :param account_id: Account identifier for which to remove the role
    :type account_id: int
    :param group_id: Group identifier for which to remove the role
    :type group_id: int
    :param role_id: Role identifier
    :type role_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_institution_account_group_roles(account_id):  # noqa: E501
    """List Institution Account Group Roles

    List Institution Account Group Roles # noqa: E501

    :param account_id: Account identifier the user is associated to
    :type account_id: int

    :rtype: AccountGroupRoles
    """
    return 'do some magic!'


def private_institution_account_group_roles_create(account_id, Account):  # noqa: E501
    """Add Institution Account Group Roles

    Add Institution Account Group Roles # noqa: E501

    :param account_id: Account identifier the user is associated to
    :type account_id: int
    :param Account: Account description
    :type Account: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Account = AccountGroupRolesCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_institution_accounts_create(Account):  # noqa: E501
    """Create new Institution Account

    Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created. # noqa: E501

    :param Account: Account description
    :type Account: dict | bytes

    :rtype: AccountCreateResponse
    """
    if connexion.request.is_json:
        Account = AccountCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_institution_accounts_list(page=None, page_size=None, limit=None, offset=None, is_active=None, institution_user_id=None, email=None, id_lte=None, id_gte=None):  # noqa: E501
    """Private Account Institution Accounts

    Returns the accounts for which the account has administrative privileges (assigned and inherited). # noqa: E501

    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int
    :param is_active: Filter by active status
    :type is_active: int
    :param institution_user_id: Filter by institution_user_id
    :type institution_user_id: str
    :param email: Filter by email
    :type email: str
    :param id_lte: Retrieve accounts with an ID lower or equal to the specified value
    :type id_lte: int
    :param id_gte: Retrieve accounts with an ID greater or equal to the specified value
    :type id_gte: int

    :rtype: List[ShortAccount]
    """
    return 'do some magic!'


def private_institution_accounts_search(search):  # noqa: E501
    """Private Account Institution Accounts Search

    Returns the accounts for which the account has administrative privileges (assigned and inherited). # noqa: E501

    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[ShortAccount]
    """
    if connexion.request.is_json:
        search = InstitutionAccountsSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_institution_accounts_update(account_id, Account):  # noqa: E501
    """Update Institution Account

    Update Institution Account # noqa: E501

    :param account_id: Account identifier the user is associated to
    :type account_id: int
    :param Account: Account description
    :type Account: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Account = AccountUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_institution_articles(page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, published_since=None, modified_since=None, status=None, resource_doi=None, item_type=None, group=None):  # noqa: E501
    """Private Institution Articles

    Get Articles from own institution. User must be administrator of the institution # noqa: E501

    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param published_since: Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
    :type published_since: str
    :param modified_since: Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
    :type modified_since: str
    :param status: only return collections with this status
    :type status: int
    :param resource_doi: only return collections with this resource_doi
    :type resource_doi: str
    :param item_type: Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
    :type item_type: int
    :param group: only return articles from this group
    :type group: int

    :rtype: List[Article]
    """
    return 'do some magic!'


def private_institution_details():  # noqa: E501
    """Private Account Institutions

    Account institution details # noqa: E501


    :rtype: Institution
    """
    return 'do some magic!'


def private_institution_embargo_options_details():  # noqa: E501
    """Private Account Institution embargo options

    Account institution embargo options details # noqa: E501


    :rtype: List[GroupEmbargoOptions]
    """
    return 'do some magic!'


def private_institution_groups_list():  # noqa: E501
    """Private Account Institution Groups

    Returns the groups for which the account has administrative privileges (assigned and inherited). # noqa: E501


    :rtype: List[Group]
    """
    return 'do some magic!'


def private_institution_roles_list():  # noqa: E501
    """Private Account Institution Roles

    Returns the roles available for groups and the institution group. # noqa: E501


    :rtype: List[Role]
    """
    return 'do some magic!'
