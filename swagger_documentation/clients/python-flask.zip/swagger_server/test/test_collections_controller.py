# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.article import Article  # noqa: E501
from swagger_server.models.articles_creator import ArticlesCreator  # noqa: E501
from swagger_server.models.author import Author  # noqa: E501
from swagger_server.models.authors_creator import AuthorsCreator  # noqa: E501
from swagger_server.models.categories_creator import CategoriesCreator  # noqa: E501
from swagger_server.models.category import Category  # noqa: E501
from swagger_server.models.collection import Collection  # noqa: E501
from swagger_server.models.collection_complete import CollectionComplete  # noqa: E501
from swagger_server.models.collection_complete_private import CollectionCompletePrivate  # noqa: E501
from swagger_server.models.collection_create import CollectionCreate  # noqa: E501
from swagger_server.models.collection_doi import CollectionDOI  # noqa: E501
from swagger_server.models.collection_handle import CollectionHandle  # noqa: E501
from swagger_server.models.collection_private_link_creator import CollectionPrivateLinkCreator  # noqa: E501
from swagger_server.models.collection_search import CollectionSearch  # noqa: E501
from swagger_server.models.collection_update import CollectionUpdate  # noqa: E501
from swagger_server.models.collection_versions import CollectionVersions  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.location import Location  # noqa: E501
from swagger_server.models.location_warnings import LocationWarnings  # noqa: E501
from swagger_server.models.location_warnings_update import LocationWarningsUpdate  # noqa: E501
from swagger_server.models.private_collection_search import PrivateCollectionSearch  # noqa: E501
from swagger_server.models.private_link import PrivateLink  # noqa: E501
from swagger_server.models.private_link_response import PrivateLinkResponse  # noqa: E501
from swagger_server.models.resource import Resource  # noqa: E501
from swagger_server.test import BaseTestCase


class TestCollectionsController(BaseTestCase):
    """CollectionsController integration test stubs"""

    def test_collection_articles(self):
        """Test case for collection_articles

        Public Collection Articles
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000)]
        response = self.client.open(
            '/v2/collections/{collection_id}/articles'.format(collection_id=2),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_collection_details(self):
        """Test case for collection_details

        Collection details
        """
        response = self.client.open(
            '/v2/collections/{collection_id}'.format(collection_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_collection_version_details(self):
        """Test case for collection_version_details

        Collection Version details
        """
        response = self.client.open(
            '/v2/collections/{collection_id}/versions/{version_id}'.format(collection_id=2, version_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_collection_versions(self):
        """Test case for collection_versions

        Collection Versions list
        """
        response = self.client.open(
            '/v2/collections/{collection_id}/versions'.format(collection_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_collections_list(self):
        """Test case for collections_list

        Public Collections
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000),
                        ('order', 'published_date'),
                        ('order_direction', 'desc'),
                        ('institution', 789),
                        ('published_since', 'published_since_example'),
                        ('modified_since', 'modified_since_example'),
                        ('group', 789),
                        ('resource_doi', 'resource_doi_example'),
                        ('doi', 'doi_example'),
                        ('handle', 'handle_example')]
        headers = [('X_Cursor', 'X_Cursor_example')]
        response = self.client.open(
            '/v2/collections',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_collections_search(self):
        """Test case for collections_search

        Public Collections Search
        """
        search = CollectionSearch()
        headers = [('X_Cursor', 'X_Cursor_example')]
        response = self.client.open(
            '/v2/collections/search',
            method='POST',
            data=json.dumps(search),
            content_type='application/json',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_article_delete(self):
        """Test case for private_collection_article_delete

        Delete collection article
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/articles/{article_id}'.format(collection_id=2, article_id=2),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_articles_add(self):
        """Test case for private_collection_articles_add

        Add collection articles
        """
        articles = ArticlesCreator()
        response = self.client.open(
            '/v2/account/collections/{collection_id}/articles'.format(collection_id=2),
            method='POST',
            data=json.dumps(articles),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_articles_list(self):
        """Test case for private_collection_articles_list

        List collection articles
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000)]
        response = self.client.open(
            '/v2/account/collections/{collection_id}/articles'.format(collection_id=2),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_articles_replace(self):
        """Test case for private_collection_articles_replace

        Replace collection articles
        """
        articles = ArticlesCreator()
        response = self.client.open(
            '/v2/account/collections/{collection_id}/articles'.format(collection_id=2),
            method='PUT',
            data=json.dumps(articles),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_author_delete(self):
        """Test case for private_collection_author_delete

        Delete collection author
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/authors/{author_id}'.format(collection_id=2, author_id=2),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_authors_add(self):
        """Test case for private_collection_authors_add

        Add collection authors
        """
        Authors = AuthorsCreator()
        response = self.client.open(
            '/v2/account/collections/{collection_id}/authors'.format(collection_id=2),
            method='POST',
            data=json.dumps(Authors),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_authors_list(self):
        """Test case for private_collection_authors_list

        List collection authors
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/authors'.format(collection_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_authors_replace(self):
        """Test case for private_collection_authors_replace

        Replace collection authors
        """
        Authors = AuthorsCreator()
        response = self.client.open(
            '/v2/account/collections/{collection_id}/authors'.format(collection_id=2),
            method='PUT',
            data=json.dumps(Authors),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_categories_add(self):
        """Test case for private_collection_categories_add

        Add collection categories
        """
        categories = CategoriesCreator()
        response = self.client.open(
            '/v2/account/collections/{collection_id}/categories'.format(collection_id=2),
            method='POST',
            data=json.dumps(categories),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_categories_list(self):
        """Test case for private_collection_categories_list

        List collection categories
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/categories'.format(collection_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_categories_replace(self):
        """Test case for private_collection_categories_replace

        Replace collection categories
        """
        categories = CategoriesCreator()
        response = self.client.open(
            '/v2/account/collections/{collection_id}/categories'.format(collection_id=2),
            method='PUT',
            data=json.dumps(categories),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_category_delete(self):
        """Test case for private_collection_category_delete

        Delete collection category
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/categories/{category_id}'.format(collection_id=2, category_id=2),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_create(self):
        """Test case for private_collection_create

        Create collection
        """
        Collection = CollectionCreate()
        response = self.client.open(
            '/v2/account/collections',
            method='POST',
            data=json.dumps(Collection),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_delete(self):
        """Test case for private_collection_delete

        Delete collection
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}'.format(collection_id=2),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_details(self):
        """Test case for private_collection_details

        Collection details
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}'.format(collection_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_patch(self):
        """Test case for private_collection_patch

        Partially update collection
        """
        Collection = CollectionUpdate()
        response = self.client.open(
            '/v2/account/collections/{collection_id}'.format(collection_id=2),
            method='PATCH',
            data=json.dumps(Collection),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_private_link_create(self):
        """Test case for private_collection_private_link_create

        Create collection private link
        """
        private_link = CollectionPrivateLinkCreator()
        response = self.client.open(
            '/v2/account/collections/{collection_id}/private_links'.format(collection_id=2),
            method='POST',
            data=json.dumps(private_link),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_private_link_delete(self):
        """Test case for private_collection_private_link_delete

        Disable private link
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/private_links/{link_id}'.format(collection_id=2, link_id='link_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_private_link_details(self):
        """Test case for private_collection_private_link_details

        View collection private link
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/private_links/{link_id}'.format(collection_id=2, link_id='link_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_private_link_update(self):
        """Test case for private_collection_private_link_update

        Update collection private link
        """
        private_link = CollectionPrivateLinkCreator()
        response = self.client.open(
            '/v2/account/collections/{collection_id}/private_links/{link_id}'.format(collection_id=2, link_id='link_id_example'),
            method='PUT',
            data=json.dumps(private_link),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_private_links_list(self):
        """Test case for private_collection_private_links_list

        List collection private links
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/private_links'.format(collection_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_publish(self):
        """Test case for private_collection_publish

        Private Collection Publish
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/publish'.format(collection_id=2),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_reserve_doi(self):
        """Test case for private_collection_reserve_doi

        Private Collection Reserve DOI
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/reserve_doi'.format(collection_id=2),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_reserve_handle(self):
        """Test case for private_collection_reserve_handle

        Private Collection Reserve Handle
        """
        response = self.client.open(
            '/v2/account/collections/{collection_id}/reserve_handle'.format(collection_id=2),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_resource(self):
        """Test case for private_collection_resource

        Private Collection Resource
        """
        Resource = Resource()
        response = self.client.open(
            '/v2/account/collections/{collection_id}/resource'.format(collection_id=2),
            method='POST',
            data=json.dumps(Resource),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_update(self):
        """Test case for private_collection_update

        Update collection
        """
        Collection = CollectionUpdate()
        response = self.client.open(
            '/v2/account/collections/{collection_id}'.format(collection_id=2),
            method='PUT',
            data=json.dumps(Collection),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collections_list(self):
        """Test case for private_collections_list

        Private Collections List
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000),
                        ('order', 'published_date'),
                        ('order_direction', 'desc')]
        response = self.client.open(
            '/v2/account/collections',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collections_search(self):
        """Test case for private_collections_search

        Private Collections Search
        """
        search = PrivateCollectionSearch()
        response = self.client.open(
            '/v2/account/collections/search',
            method='POST',
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
