# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.article import Article  # noqa: E501
from swagger_server.models.article_complete_private import ArticleCompletePrivate  # noqa: E501
from swagger_server.models.article_project_create import ArticleProjectCreate  # noqa: E501
from swagger_server.models.create_project_response import CreateProjectResponse  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.location import Location  # noqa: E501
from swagger_server.models.private_file import PrivateFile  # noqa: E501
from swagger_server.models.project import Project  # noqa: E501
from swagger_server.models.project_collaborator import ProjectCollaborator  # noqa: E501
from swagger_server.models.project_collaborator_invite import ProjectCollaboratorInvite  # noqa: E501
from swagger_server.models.project_complete import ProjectComplete  # noqa: E501
from swagger_server.models.project_complete_private import ProjectCompletePrivate  # noqa: E501
from swagger_server.models.project_create import ProjectCreate  # noqa: E501
from swagger_server.models.project_note import ProjectNote  # noqa: E501
from swagger_server.models.project_note_create import ProjectNoteCreate  # noqa: E501
from swagger_server.models.project_note_private import ProjectNotePrivate  # noqa: E501
from swagger_server.models.project_private import ProjectPrivate  # noqa: E501
from swagger_server.models.project_update import ProjectUpdate  # noqa: E501
from swagger_server.models.projects_search import ProjectsSearch  # noqa: E501
from swagger_server.models.response_message import ResponseMessage  # noqa: E501
from swagger_server.test import BaseTestCase


class TestProjectsController(BaseTestCase):
    """ProjectsController integration test stubs"""

    def test_private_project_article_delete(self):
        """Test case for private_project_article_delete

        Delete project article
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles/{article_id}'.format(project_id=2, article_id=2),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_article_details(self):
        """Test case for private_project_article_details

        Project article details
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles/{article_id}'.format(project_id=2, article_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_article_file(self):
        """Test case for private_project_article_file

        Project article file details
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles/{article_id}/files/{file_id}'.format(project_id=2, article_id=2, file_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_article_files(self):
        """Test case for private_project_article_files

        Project article list files
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles/{article_id}/files'.format(project_id=2, article_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_articles_create(self):
        """Test case for private_project_articles_create

        Create project article
        """
        Article = ArticleProjectCreate()
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles'.format(project_id=2),
            method='POST',
            data=json.dumps(Article),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_articles_list(self):
        """Test case for private_project_articles_list

        List project articles
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles'.format(project_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_collaborator_delete(self):
        """Test case for private_project_collaborator_delete

        Remove project collaborator
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/collaborators/{user_id}'.format(project_id=2, user_id=2),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_collaborators_invite(self):
        """Test case for private_project_collaborators_invite

        Invite project collaborators
        """
        Collaborator = ProjectCollaboratorInvite()
        response = self.client.open(
            '/v2/account/projects/{project_id}/collaborators'.format(project_id=2),
            method='POST',
            data=json.dumps(Collaborator),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_collaborators_list(self):
        """Test case for private_project_collaborators_list

        List project collaborators
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/collaborators'.format(project_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_create(self):
        """Test case for private_project_create

        Create project
        """
        Project = ProjectCreate()
        response = self.client.open(
            '/v2/account/projects',
            method='POST',
            data=json.dumps(Project),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_delete(self):
        """Test case for private_project_delete

        Delete project
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}'.format(project_id=2),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_details(self):
        """Test case for private_project_details

        View project details
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}'.format(project_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_leave(self):
        """Test case for private_project_leave

        Private Project Leave
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/leave'.format(project_id=2),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_note(self):
        """Test case for private_project_note

        Project note details
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/notes/{note_id}'.format(project_id=2, note_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_note_delete(self):
        """Test case for private_project_note_delete

        Delete project note
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/notes/{note_id}'.format(project_id=2, note_id=2),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_note_update(self):
        """Test case for private_project_note_update

        Update project note
        """
        Note = ProjectNoteCreate()
        response = self.client.open(
            '/v2/account/projects/{project_id}/notes/{note_id}'.format(project_id=2, note_id=2),
            method='PUT',
            data=json.dumps(Note),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_notes_create(self):
        """Test case for private_project_notes_create

        Create project note
        """
        Note = ProjectNoteCreate()
        response = self.client.open(
            '/v2/account/projects/{project_id}/notes'.format(project_id=2),
            method='POST',
            data=json.dumps(Note),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_notes_list(self):
        """Test case for private_project_notes_list

        List project notes
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000)]
        response = self.client.open(
            '/v2/account/projects/{project_id}/notes'.format(project_id=2),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_publish(self):
        """Test case for private_project_publish

        Private Project Publish
        """
        response = self.client.open(
            '/v2/account/projects/{project_id}/publish'.format(project_id=2),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_update(self):
        """Test case for private_project_update

        Update project
        """
        Project = ProjectUpdate()
        response = self.client.open(
            '/v2/account/projects/{project_id}'.format(project_id=2),
            method='PUT',
            data=json.dumps(Project),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_projects_list(self):
        """Test case for private_projects_list

        Private Projects
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000),
                        ('order', 'published_date'),
                        ('order_direction', 'desc'),
                        ('storage', 'storage_example'),
                        ('roles', 'roles_example')]
        response = self.client.open(
            '/v2/account/projects',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_projects_search(self):
        """Test case for private_projects_search

        Private Projects search
        """
        search = ProjectsSearch()
        response = self.client.open(
            '/v2/account/projects/search',
            method='POST',
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_project_articles(self):
        """Test case for project_articles

        Public Project Articles
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000)]
        response = self.client.open(
            '/v2/projects/{project_id}/articles'.format(project_id=2),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_project_details(self):
        """Test case for project_details

        Public Project
        """
        response = self.client.open(
            '/v2/projects/{project_id}'.format(project_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_projects_list(self):
        """Test case for projects_list

        Public Projects
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000),
                        ('order', 'published_date'),
                        ('order_direction', 'desc'),
                        ('institution', 789),
                        ('published_since', 'published_since_example'),
                        ('group', 789)]
        headers = [('X_Cursor', 'X_Cursor_example')]
        response = self.client.open(
            '/v2/projects',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_projects_search(self):
        """Test case for projects_search

        Public Projects Search
        """
        search = ProjectsSearch()
        headers = [('X_Cursor', 'X_Cursor_example')]
        response = self.client.open(
            '/v2/projects/search',
            method='POST',
            data=json.dumps(search),
            content_type='application/json',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
