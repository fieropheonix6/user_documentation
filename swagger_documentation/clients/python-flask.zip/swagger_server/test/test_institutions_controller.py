# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.account_create import AccountCreate  # noqa: E501
from swagger_server.models.account_create_response import AccountCreateResponse  # noqa: E501
from swagger_server.models.account_group_roles import AccountGroupRoles  # noqa: E501
from swagger_server.models.account_group_roles_create import AccountGroupRolesCreate  # noqa: E501
from swagger_server.models.account_update import AccountUpdate  # noqa: E501
from swagger_server.models.article import Article  # noqa: E501
from swagger_server.models.category import Category  # noqa: E501
from swagger_server.models.curation import Curation  # noqa: E501
from swagger_server.models.curation_comment import CurationComment  # noqa: E501
from swagger_server.models.curation_comment_create import CurationCommentCreate  # noqa: E501
from swagger_server.models.curation_detail import CurationDetail  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.group import Group  # noqa: E501
from swagger_server.models.group_embargo_options import GroupEmbargoOptions  # noqa: E501
from swagger_server.models.institution import Institution  # noqa: E501
from swagger_server.models.institution_accounts_search import InstitutionAccountsSearch  # noqa: E501
from swagger_server.models.response_message import ResponseMessage  # noqa: E501
from swagger_server.models.role import Role  # noqa: E501
from swagger_server.models.short_account import ShortAccount  # noqa: E501
from swagger_server.models.short_custom_field import ShortCustomField  # noqa: E501
from swagger_server.models.user import User  # noqa: E501
from swagger_server.test import BaseTestCase


class TestInstitutionsController(BaseTestCase):
    """InstitutionsController integration test stubs"""

    def test_account_institution_curation(self):
        """Test case for account_institution_curation

        Institution Curation Review
        """
        response = self.client.open(
            '/v2/account/institution/review/{curation_id}'.format(curation_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_account_institution_curations(self):
        """Test case for account_institution_curations

        Institution Curation Reviews
        """
        query_string = [('group_id', 1),
                        ('article_id', 1),
                        ('status', 'status_example'),
                        ('limit', 1000),
                        ('offset', 5000)]
        response = self.client.open(
            '/v2/account/institution/reviews',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_custom_fields_list(self):
        """Test case for custom_fields_list

        Private account institution group custom fields
        """
        query_string = [('group_id', 789)]
        response = self.client.open(
            '/v2/account/institution/custom_fields',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_custom_fields_upload(self):
        """Test case for custom_fields_upload

        Custom fields values files upload
        """
        data = dict(external_file=(BytesIO(b'some file data'), 'file.txt'))
        response = self.client.open(
            '/v2/account/institution/custom_fields/{custom_field_id}/items/upload'.format(custom_field_id=2),
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_account_institution_curation_comments(self):
        """Test case for get_account_institution_curation_comments

        Institution Curation Review Comments
        """
        query_string = [('limit', 1000),
                        ('offset', 5000)]
        response = self.client.open(
            '/v2/account/institution/review/{curation_id}/comments'.format(curation_id=2),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_institution_articles(self):
        """Test case for institution_articles

        Public Institution Articles
        """
        query_string = [('resource_id', 'resource_id_example'),
                        ('filename', 'filename_example')]
        response = self.client.open(
            '/v2/institutions/{institution_string_id}/articles/filter-by'.format(institution_string_id='institution_string_id_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_institution_hrfeed_upload(self):
        """Test case for institution_hrfeed_upload

        Private Institution HRfeed Upload
        """
        data = dict(hrfeed=(BytesIO(b'some file data'), 'file.txt'))
        response = self.client.open(
            '/v2/institution/hrfeed/upload',
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_post_account_institution_curation_comments(self):
        """Test case for post_account_institution_curation_comments

        POST Institution Curation Review Comment
        """
        CurationComment = CurationCommentCreate()
        response = self.client.open(
            '/v2/account/institution/review/{curation_id}/comments'.format(curation_id=2),
            method='POST',
            data=json.dumps(CurationComment),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_account_institution_user(self):
        """Test case for private_account_institution_user

        Private Account Institution User
        """
        response = self.client.open(
            '/v2/account/institution/users/{account_id}'.format(account_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_categories_list(self):
        """Test case for private_categories_list

        Private Account Categories
        """
        response = self.client.open(
            '/v2/account/categories',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_group_embargo_options_details(self):
        """Test case for private_group_embargo_options_details

        Private Account Institution Group Embargo Options
        """
        response = self.client.open(
            '/v2/account/institution/groups/{group_id}/embargo_options'.format(group_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_account_group_role_delete(self):
        """Test case for private_institution_account_group_role_delete

        Delete Institution Account Group Role
        """
        response = self.client.open(
            '/v2/account/institution/roles/{account_id}/{group_id}/{role_id}'.format(account_id=2, group_id=2, role_id=2),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_account_group_roles(self):
        """Test case for private_institution_account_group_roles

        List Institution Account Group Roles
        """
        response = self.client.open(
            '/v2/account/institution/roles/{account_id}'.format(account_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_account_group_roles_create(self):
        """Test case for private_institution_account_group_roles_create

        Add Institution Account Group Roles
        """
        Account = AccountGroupRolesCreate()
        response = self.client.open(
            '/v2/account/institution/roles/{account_id}'.format(account_id=2),
            method='POST',
            data=json.dumps(Account),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_accounts_create(self):
        """Test case for private_institution_accounts_create

        Create new Institution Account
        """
        Account = AccountCreate()
        response = self.client.open(
            '/v2/account/institution/accounts',
            method='POST',
            data=json.dumps(Account),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_accounts_list(self):
        """Test case for private_institution_accounts_list

        Private Account Institution Accounts
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000),
                        ('is_active', 1),
                        ('institution_user_id', 'institution_user_id_example'),
                        ('email', 'email_example'),
                        ('id_lte', 1),
                        ('id_gte', 1)]
        response = self.client.open(
            '/v2/account/institution/accounts',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_accounts_search(self):
        """Test case for private_institution_accounts_search

        Private Account Institution Accounts Search
        """
        search = InstitutionAccountsSearch()
        response = self.client.open(
            '/v2/account/institution/accounts/search',
            method='POST',
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_accounts_update(self):
        """Test case for private_institution_accounts_update

        Update Institution Account
        """
        Account = AccountUpdate()
        response = self.client.open(
            '/v2/account/institution/accounts/{account_id}'.format(account_id=2),
            method='PUT',
            data=json.dumps(Account),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_articles(self):
        """Test case for private_institution_articles

        Private Institution Articles
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000),
                        ('order', 'published_date'),
                        ('order_direction', 'desc'),
                        ('published_since', 'published_since_example'),
                        ('modified_since', 'modified_since_example'),
                        ('status', 789),
                        ('resource_doi', 'resource_doi_example'),
                        ('item_type', 789),
                        ('group', 789)]
        response = self.client.open(
            '/v2/account/institution/articles',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_details(self):
        """Test case for private_institution_details

        Private Account Institutions
        """
        response = self.client.open(
            '/v2/account/institution',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_embargo_options_details(self):
        """Test case for private_institution_embargo_options_details

        Private Account Institution embargo options
        """
        response = self.client.open(
            '/v2/account/institution/embargo_options',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_groups_list(self):
        """Test case for private_institution_groups_list

        Private Account Institution Groups
        """
        response = self.client.open(
            '/v2/account/institution/groups',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_roles_list(self):
        """Test case for private_institution_roles_list

        Private Account Institution Roles
        """
        response = self.client.open(
            '/v2/account/institution/roles',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
