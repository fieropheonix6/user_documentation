# openapi_client.SymplecticApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**symplectic_account_articles**](SymplecticApi.md#symplectic_account_articles) | **GET** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account
[**symplectic_accounts_ids**](SymplecticApi.md#symplectic_accounts_ids) | **GET** /symplectic/accounts | Get changed accounts for Symplectic Elements
[**symplectic_article**](SymplecticApi.md#symplectic_article) | **GET** /symplectic/articles/{article_id} | Get article details for Symplectic Elements
[**symplectic_changed_articles**](SymplecticApi.md#symplectic_changed_articles) | **GET** /symplectic/articles | Get changed articles for Symplectic Elements
[**symplectic_user_id**](SymplecticApi.md#symplectic_user_id) | **GET** /symplectic/users/{user_id} | Get institutional user ID for a user


# **symplectic_account_articles**
> List[object] symplectic_account_articles(external_user_id, offset=offset, limit=limit, status=status, is_embargoed=is_embargoed)

Get articles for a specific account

Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.SymplecticApi(api_client)
    external_user_id = 'external_user_id_example' # str | External user ID (symplectic_user_id or institution_user_id)
    offset = 0 # int | Number of results to skip for pagination (optional) (default to 0)
    limit = 10 # int | Maximum number of results to return (optional) (default to 10)
    status = 'status_example' # str | Filter by article status (optional)
    is_embargoed = 'is_embargoed_example' # str | Filter by embargo status (optional)

    try:
        # Get articles for a specific account
        api_response = api_instance.symplectic_account_articles(external_user_id, offset=offset, limit=limit, status=status, is_embargoed=is_embargoed)
        print("The response of SymplecticApi->symplectic_account_articles:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SymplecticApi->symplectic_account_articles: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **external_user_id** | **str**| External user ID (symplectic_user_id or institution_user_id) | 
 **offset** | **int**| Number of results to skip for pagination | [optional] [default to 0]
 **limit** | **int**| Maximum number of results to return | [optional] [default to 10]
 **status** | **str**| Filter by article status | [optional] 
 **is_embargoed** | **str**| Filter by embargo status | [optional] 

### Return type

**List[object]**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Returns a list of articles for the specified account |  * ETag - Hash of the returned accounts for caching purposes <br>  |
**401** | Unauthorized - Missing or invalid OAuth token |  -  |
**403** | Forbidden - Insufficient permissions |  -  |
**404** | Not Found - Account not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplectic_accounts_ids**
> List[SymplecticAccountsIds200ResponseInner] symplectic_accounts_ids(since)

Get changed accounts for Symplectic Elements

Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.symplectic_accounts_ids200_response_inner import SymplecticAccountsIds200ResponseInner
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.SymplecticApi(api_client)
    since = '2015-01-01 00:00:00' # str | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)

    try:
        # Get changed accounts for Symplectic Elements
        api_response = api_instance.symplectic_accounts_ids(since)
        print("The response of SymplecticApi->symplectic_accounts_ids:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SymplecticApi->symplectic_accounts_ids: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **since** | **str**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | 

### Return type

[**List[SymplecticAccountsIds200ResponseInner]**](SymplecticAccountsIds200ResponseInner.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Returns a list of modified accounts |  * ETag - Hash of the returned accounts for caching purposes <br>  |
**400** | Bad Request - Missing or invalid parameters |  -  |
**401** | Unauthorized - Missing or invalid OAuth token |  -  |
**403** | Forbidden - Insufficient permissions |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplectic_article**
> object symplectic_article(article_id)

Get article details for Symplectic Elements

Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.SymplecticApi(api_client)
    article_id = 56 # int | Article ID

    try:
        # Get article details for Symplectic Elements
        api_response = api_instance.symplectic_article(article_id)
        print("The response of SymplecticApi->symplectic_article:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SymplecticApi->symplectic_article: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article ID | 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Returns the article details with full metadata |  * ETag - Hash of the returned accounts for caching purposes <br>  |
**401** | Unauthorized - Missing or invalid OAuth token |  -  |
**403** | Forbidden - Insufficient permissions |  -  |
**404** | Not Found - Article not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplectic_changed_articles**
> List[object] symplectic_changed_articles(since, offset=offset, limit=limit, status=status, is_embargoed=is_embargoed)

Get changed articles for Symplectic Elements

Returns a list of articles for Symplectic Elements integration to synchronize article data.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.SymplecticApi(api_client)
    since = '2015-01-01 00:00:00' # str | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
    offset = 0 # int | Number of results to skip for pagination (optional) (default to 0)
    limit = 10 # int | Maximum number of results to return (optional) (default to 10)
    status = 'status_example' # str | Filter by article status (optional)
    is_embargoed = 'is_embargoed_example' # str | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type (optional)

    try:
        # Get changed articles for Symplectic Elements
        api_response = api_instance.symplectic_changed_articles(since, offset=offset, limit=limit, status=status, is_embargoed=is_embargoed)
        print("The response of SymplecticApi->symplectic_changed_articles:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SymplecticApi->symplectic_changed_articles: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **since** | **str**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | 
 **offset** | **int**| Number of results to skip for pagination | [optional] [default to 0]
 **limit** | **int**| Maximum number of results to return | [optional] [default to 10]
 **status** | **str**| Filter by article status | [optional] 
 **is_embargoed** | **str**| Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type | [optional] 

### Return type

**List[object]**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Returns a list of symplectic articles |  * ETag - Hash of the returned accounts for caching purposes <br>  |
**400** | Bad Request - Missing or invalid parameters |  -  |
**401** | Unauthorized - Missing or invalid OAuth token |  -  |
**403** | Forbidden - Insufficient permissions |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplectic_user_id**
> SymplecticUserId200Response symplectic_user_id(user_id)

Get institutional user ID for a user

Returns the institution user ID for a given user within the authenticated account's institution.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.symplectic_user_id200_response import SymplecticUserId200Response
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.SymplecticApi(api_client)
    user_id = 56 # int | User ID

    try:
        # Get institutional user ID for a user
        api_response = api_instance.symplectic_user_id(user_id)
        print("The response of SymplecticApi->symplectic_user_id:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SymplecticApi->symplectic_user_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**| User ID | 

### Return type

[**SymplecticUserId200Response**](SymplecticUserId200Response.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Returns the institutional user ID |  -  |
**401** | Unauthorized - Missing or invalid OAuth token |  -  |
**403** | Forbidden - Insufficient permissions |  -  |
**404** | Not Found - User not found or user has no account in this institution |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

