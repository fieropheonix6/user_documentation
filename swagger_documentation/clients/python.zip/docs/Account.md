# Account


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Account id | 
**first_name** | **str** | First Name | 
**last_name** | **str** | Last Name | 
**used_quota_private** | **int** | Account used private quota | 
**modified_date** | **str** | Date of last account modification | 
**used_quota** | **int** | Account total used quota | 
**created_date** | **str** | Date when account was created | 
**quota** | **int** | Account quota | 
**group_id** | **int** | Account group id | 
**institution_user_id** | **str** | Account institution user id | 
**institution_id** | **int** | Account institution | 
**email** | **str** | User email | 
**used_quota_public** | **int** | Account public used quota | 
**pending_quota_request** | **bool** | True if a quota request is pending | 
**active** | **int** | Account activity status | 
**maximum_file_size** | **int** | Maximum upload size for account | 
**user_id** | **int** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcid_id** | **str** | ORCID iD associated to account | 
**symplectic_user_id** | **str** | Symplectic ID associated to account | 

## Example

```python
from openapi_client.models.account import Account

# TODO update the JSON string below
json = "{}"
# create an instance of Account from a JSON string
account_instance = Account.from_json(json)
# print the JSON string representation of the object
print(Account.to_json())

# convert the object into a dict
account_dict = account_instance.to_dict()
# create an instance of Account from a dict
account_from_dict = Account.from_dict(account_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


