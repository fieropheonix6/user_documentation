# ProjectNotePrivate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **str** | Full text of note | 
**id** | **int** | Project note id | 
**user_id** | **int** | User who wrote the note | 
**abstract** | **str** | Note Abstract - short/truncated content | 
**user_name** | **str** | Username of the one who wrote the note | 
**created_date** | **str** | Date when note was created | 
**modified_date** | **str** | Date when note was last modified | 

## Example

```python
from openapi_client.models.project_note_private import ProjectNotePrivate

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectNotePrivate from a JSON string
project_note_private_instance = ProjectNotePrivate.from_json(json)
# print the JSON string representation of the object
print(ProjectNotePrivate.to_json())

# convert the object into a dict
project_note_private_dict = project_note_private_instance.to_dict()
# create an instance of ProjectNotePrivate from a dict
project_note_private_from_dict = ProjectNotePrivate.from_dict(project_note_private_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


