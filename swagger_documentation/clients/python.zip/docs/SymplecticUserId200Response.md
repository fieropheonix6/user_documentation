# SymplecticUserId200Response


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**institution_user_id** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.symplectic_user_id200_response import SymplecticUserId200Response

# TODO update the JSON string below
json = "{}"
# create an instance of SymplecticUserId200Response from a JSON string
symplectic_user_id200_response_instance = SymplecticUserId200Response.from_json(json)
# print the JSON string representation of the object
print(SymplecticUserId200Response.to_json())

# convert the object into a dict
symplectic_user_id200_response_dict = symplectic_user_id200_response_instance.to_dict()
# create an instance of SymplecticUserId200Response from a dict
symplectic_user_id200_response_from_dict = SymplecticUserId200Response.from_dict(symplectic_user_id200_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


