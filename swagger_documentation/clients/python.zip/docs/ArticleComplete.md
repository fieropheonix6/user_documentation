# ArticleComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**citation** | **str** | Article citation | [optional] 
**confidential_reason** | **str** | Confidentiality reason | [optional] 
**is_confidential** | **bool** | Article Confidentiality | [optional] 
**size** | **int** | Article size | [optional] 
**funding** | **str** | Article funding | [optional] 
**funding_list** | [**list[FundingInformation]**](FundingInformation.md) | Full Article funding information | [optional] 
**tags** | **list[str]** | List of article tags | [optional] 
**version** | **int** | Article version | [optional] 
**is_active** | **bool** | True if article is active | [optional] 
**is_metadata_record** | **bool** | True if article has no files | [optional] 
**metadata_reason** | **str** | Article metadata reason | [optional] 
**status** | **str** | Article status | [optional] 
**description** | **str** | Article description | [optional] 
**is_embargoed** | **bool** | True if article is embargoed | [optional] 
**is_public** | **bool** | True if article is published | [optional] 
**created_date** | **str** | Date when article was created | [optional] 
**has_linked_file** | **bool** | True if any files are linked to the article | [optional] 
**categories** | [**list[Category]**](Category.md) | List of categories selected for the article | [optional] 
**license** | [**License**](License.md) | Article selected license | [optional] 
**embargo_title** | **str** | Title for embargo | [optional] 
**embargo_reason** | **str** | Reason for embargo | [optional] 
**references** | **list[str]** | List of references | [optional] 
**related_materials** | [**list[RelatedMaterial]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**id** | **int** | Unique identifier for article | 
**title** | **str** | Title of article | 
**doi** | **str** | DOI | 
**handle** | **str** | Handle | 
**url** | **str** | Api endpoint for article | 
**url_public_html** | **str** | Public site endpoint for article | 
**url_public_api** | **str** | Public Api endpoint for article | 
**url_private_html** | **str** | Private site endpoint for article | 
**url_private_api** | **str** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**thumb** | **str** | Thumbnail image | 
**defined_type** | **int** | Type of article identifier | 
**defined_type_name** | **str** | Name of the article type identifier | 
**resource_doi** | **str** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to '']
**resource_title** | **str** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to '']
**figshare_url** | **str** | Article public url | 
**download_disabled** | **bool** | If true, downloading of files for this article is disabled | 
**files** | [**list[PublicFile]**](PublicFile.md) | List of up to 10 article files. | 
**authors** | [**list[Author]**](Author.md) | List of article authors | 
**custom_fields** | [**list[CustomArticleField]**](CustomArticleField.md) | List of custom fields values | 
**embargo_options** | [**list[GroupEmbargoOptions]**](GroupEmbargoOptions.md) | List of embargo options | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


