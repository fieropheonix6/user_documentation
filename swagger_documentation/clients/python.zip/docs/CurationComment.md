# CurationComment


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the comment. | 
**account_id** | **int** | The ID of the account which generated this comment. | 
**type** | **str** | The ID of the account which generated this comment. | 
**text** | **str** | The value/content of the comment. | 
**created_date** | **str** | The creation date of the comment. | 
**modified_date** | **str** | The date the comment has been modified. | 

## Example

```python
from openapi_client.models.curation_comment import CurationComment

# TODO update the JSON string below
json = "{}"
# create an instance of CurationComment from a JSON string
curation_comment_instance = CurationComment.from_json(json)
# print the JSON string representation of the object
print(CurationComment.to_json())

# convert the object into a dict
curation_comment_dict = curation_comment_instance.to_dict()
# create an instance of CurationComment from a dict
curation_comment_from_dict = CurationComment.from_dict(curation_comment_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


