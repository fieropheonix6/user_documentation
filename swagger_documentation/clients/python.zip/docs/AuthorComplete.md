# AuthorComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Author id | 
**full_name** | **str** | Author full name | 
**first_name** | **str** | First Name | 
**last_name** | **str** | Last Name | 
**is_active** | **bool** | True if author has published items | 
**url_name** | **str** | Author url name | 
**orcid_id** | **str** | Author Orcid | 
**group_id** | **int** | Group id | 
**is_public** | **int** | if 1 then the author has published items | 
**institution_id** | **int** | Institution id | 
**job_title** | **str** | Job title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


