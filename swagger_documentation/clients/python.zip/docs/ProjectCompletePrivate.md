# ProjectCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **str** | Role inside this project | [optional] 
**storage** | **str** | Project storage type | [optional] 
**url** | **str** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **str** | Project title | 
**created_date** | **str** | Date when project was created | 
**modified_date** | **str** | Date when project was last modified | 
**funding** | **str** | Project funding | 
**funding_list** | [**list[FundingInformation]**](FundingInformation.md) | Full Project funding information | 
**description** | **str** | Project description | 
**collaborators** | [**list[Collaborator]**](Collaborator.md) | List of project collaborators | 
**quota** | **int** | Project quota | 
**used_quota** | **int** | Project used quota | 
**used_quota_private** | **int** | Project private quota used | 
**used_quota_public** | **int** | Project public quota used | 
**group_id** | **int** | Group of project if any | 
**account_id** | **int** | ID of the account owning the project | 
**custom_fields** | [**list[ShortCustomField]**](ShortCustomField.md) | Collection custom fields | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


