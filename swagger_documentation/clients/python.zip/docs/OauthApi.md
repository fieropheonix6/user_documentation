# swagger_client.OauthApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_token**](OauthApi.md#create_token) | **POST** /token | Create OAuth token
[**get_token_info**](OauthApi.md#get_token_info) | **GET** /token | Get OAuth token information


# **create_token**
> OAuthToken create_token(body=body)

Create OAuth token

Creates OAuth token using various grant types

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.OauthApi()
body = swagger_client.CreateOAuthToken() # CreateOAuthToken | Create OAuth Token Parameters (optional)

try:
    # Create OAuth token
    api_response = api_instance.create_token(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OauthApi->create_token: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateOAuthToken**](CreateOAuthToken.md)| Create OAuth Token Parameters | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_info**
> OAuthToken get_token_info(access_token=access_token)

Get OAuth token information

Returns information about the current OAuth token

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.OauthApi()
access_token = 'access_token_example' # str | OAuth access token (optional)

try:
    # Get OAuth token information
    api_response = api_instance.get_token_info(access_token=access_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OauthApi->get_token_info: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **access_token** | **str**| OAuth access token | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

