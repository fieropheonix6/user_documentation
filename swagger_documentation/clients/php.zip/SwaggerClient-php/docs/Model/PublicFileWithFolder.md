# PublicFileWithFolder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**files** | [**\Swagger\Client\Model\PublicFile[]**](PublicFile.md) | List of files with folder information. | 
**folder_structure** | **object** | Mapping of file ids to folder paths, if folders are used | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


