# ProjectComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **string** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **string** | Project title | 
**funding** | **string** | Project funding | 
**funding_list** | [**\Swagger\Client\Model\FundingInformation[]**](FundingInformation.md) | Full Project funding information | 
**description** | **string** | Project description | 
**collaborators** | [**\Swagger\Client\Model\Collaborator[]**](Collaborator.md) | List of project collaborators | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


