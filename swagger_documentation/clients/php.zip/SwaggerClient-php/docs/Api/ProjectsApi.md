# Swagger\Client\ProjectsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**privateProjectArticleDelete**](ProjectsApi.md#privateProjectArticleDelete) | **DELETE** /account/projects/{project_id}/articles/{article_id} | Delete project article
[**privateProjectArticleDetails**](ProjectsApi.md#privateProjectArticleDetails) | **GET** /account/projects/{project_id}/articles/{article_id} | Project article details
[**privateProjectArticleFile**](ProjectsApi.md#privateProjectArticleFile) | **GET** /account/projects/{project_id}/articles/{article_id}/files/{file_id} | Project article file details
[**privateProjectArticleFiles**](ProjectsApi.md#privateProjectArticleFiles) | **GET** /account/projects/{project_id}/articles/{article_id}/files | Project article list files
[**privateProjectArticlesCreate**](ProjectsApi.md#privateProjectArticlesCreate) | **POST** /account/projects/{project_id}/articles | Create project article
[**privateProjectArticlesList**](ProjectsApi.md#privateProjectArticlesList) | **GET** /account/projects/{project_id}/articles | List project articles
[**privateProjectCollaboratorDelete**](ProjectsApi.md#privateProjectCollaboratorDelete) | **DELETE** /account/projects/{project_id}/collaborators/{user_id} | Remove project collaborator
[**privateProjectCollaboratorsInvite**](ProjectsApi.md#privateProjectCollaboratorsInvite) | **POST** /account/projects/{project_id}/collaborators | Invite project collaborators
[**privateProjectCollaboratorsList**](ProjectsApi.md#privateProjectCollaboratorsList) | **GET** /account/projects/{project_id}/collaborators | List project collaborators
[**privateProjectCreate**](ProjectsApi.md#privateProjectCreate) | **POST** /account/projects | Create project
[**privateProjectDelete**](ProjectsApi.md#privateProjectDelete) | **DELETE** /account/projects/{project_id} | Delete project
[**privateProjectDetails**](ProjectsApi.md#privateProjectDetails) | **GET** /account/projects/{project_id} | View project details
[**privateProjectLeave**](ProjectsApi.md#privateProjectLeave) | **POST** /account/projects/{project_id}/leave | Private Project Leave
[**privateProjectNote**](ProjectsApi.md#privateProjectNote) | **GET** /account/projects/{project_id}/notes/{note_id} | Project note details
[**privateProjectNoteDelete**](ProjectsApi.md#privateProjectNoteDelete) | **DELETE** /account/projects/{project_id}/notes/{note_id} | Delete project note
[**privateProjectNoteUpdate**](ProjectsApi.md#privateProjectNoteUpdate) | **PUT** /account/projects/{project_id}/notes/{note_id} | Update project note
[**privateProjectNotesCreate**](ProjectsApi.md#privateProjectNotesCreate) | **POST** /account/projects/{project_id}/notes | Create project note
[**privateProjectNotesList**](ProjectsApi.md#privateProjectNotesList) | **GET** /account/projects/{project_id}/notes | List project notes
[**privateProjectPartialUpdate**](ProjectsApi.md#privateProjectPartialUpdate) | **PATCH** /account/projects/{project_id} | Partially update project
[**privateProjectPublish**](ProjectsApi.md#privateProjectPublish) | **POST** /account/projects/{project_id}/publish | Private Project Publish
[**privateProjectUpdate**](ProjectsApi.md#privateProjectUpdate) | **PUT** /account/projects/{project_id} | Update project
[**privateProjectsList**](ProjectsApi.md#privateProjectsList) | **GET** /account/projects | Private Projects
[**privateProjectsSearch**](ProjectsApi.md#privateProjectsSearch) | **POST** /account/projects/search | Private Projects search
[**projectArticles**](ProjectsApi.md#projectArticles) | **GET** /projects/{project_id}/articles | Public Project Articles
[**projectDetails**](ProjectsApi.md#projectDetails) | **GET** /projects/{project_id} | Public Project
[**projectsList**](ProjectsApi.md#projectsList) | **GET** /projects | Public Projects
[**projectsSearch**](ProjectsApi.md#projectsSearch) | **POST** /projects/search | Public Projects Search


# **privateProjectArticleDelete**
> privateProjectArticleDelete($project_id, $article_id)

Delete project article

Delete project article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$article_id = 789; // int | Project Article unique identifier

try {
    $apiInstance->privateProjectArticleDelete($project_id, $article_id);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectArticleDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **article_id** | **int**| Project Article unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectArticleDetails**
> \Swagger\Client\Model\ArticleCompletePrivate privateProjectArticleDetails($project_id, $article_id)

Project article details

Project article details

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$article_id = 789; // int | Project Article unique identifier

try {
    $result = $apiInstance->privateProjectArticleDetails($project_id, $article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectArticleDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **article_id** | **int**| Project Article unique identifier |

### Return type

[**\Swagger\Client\Model\ArticleCompletePrivate**](../Model/ArticleCompletePrivate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectArticleFile**
> \Swagger\Client\Model\PrivateFile privateProjectArticleFile($project_id, $article_id, $file_id)

Project article file details

Project article file details

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$article_id = 789; // int | Project Article unique identifier
$file_id = 789; // int | File unique identifier

try {
    $result = $apiInstance->privateProjectArticleFile($project_id, $article_id, $file_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectArticleFile: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **article_id** | **int**| Project Article unique identifier |
 **file_id** | **int**| File unique identifier |

### Return type

[**\Swagger\Client\Model\PrivateFile**](../Model/PrivateFile.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectArticleFiles**
> \Swagger\Client\Model\PrivateFile[] privateProjectArticleFiles($project_id, $article_id)

Project article list files

List article files

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$article_id = 789; // int | Project Article unique identifier

try {
    $result = $apiInstance->privateProjectArticleFiles($project_id, $article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectArticleFiles: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **article_id** | **int**| Project Article unique identifier |

### Return type

[**\Swagger\Client\Model\PrivateFile[]**](../Model/PrivateFile.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectArticlesCreate**
> \Swagger\Client\Model\Location privateProjectArticlesCreate($project_id, $article)

Create project article

Create a new Article and associate it with this project

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$article = new \Swagger\Client\Model\ArticleProjectCreate(); // \Swagger\Client\Model\ArticleProjectCreate | Article description

try {
    $result = $apiInstance->privateProjectArticlesCreate($project_id, $article);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectArticlesCreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **article** | [**\Swagger\Client\Model\ArticleProjectCreate**](../Model/ArticleProjectCreate.md)| Article description |

### Return type

[**\Swagger\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectArticlesList**
> \Swagger\Client\Model\Article[] privateProjectArticlesList($project_id)

List project articles

List project articles

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier

try {
    $result = $apiInstance->privateProjectArticlesList($project_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectArticlesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |

### Return type

[**\Swagger\Client\Model\Article[]**](../Model/Article.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectCollaboratorDelete**
> privateProjectCollaboratorDelete($project_id, $user_id)

Remove project collaborator

Remove project collaborator

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$user_id = 789; // int | User unique identifier

try {
    $apiInstance->privateProjectCollaboratorDelete($project_id, $user_id);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectCollaboratorDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **user_id** | **int**| User unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectCollaboratorsInvite**
> \Swagger\Client\Model\ResponseMessage privateProjectCollaboratorsInvite($project_id, $collaborator)

Invite project collaborators

Invite users to collaborate on project or view the project

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$collaborator = new \Swagger\Client\Model\ProjectCollaboratorInvite(); // \Swagger\Client\Model\ProjectCollaboratorInvite | viewer or collaborator role. User user_id or email of user

try {
    $result = $apiInstance->privateProjectCollaboratorsInvite($project_id, $collaborator);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectCollaboratorsInvite: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **collaborator** | [**\Swagger\Client\Model\ProjectCollaboratorInvite**](../Model/ProjectCollaboratorInvite.md)| viewer or collaborator role. User user_id or email of user |

### Return type

[**\Swagger\Client\Model\ResponseMessage**](../Model/ResponseMessage.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectCollaboratorsList**
> \Swagger\Client\Model\ProjectCollaborator[] privateProjectCollaboratorsList($project_id)

List project collaborators

List Project collaborators and invited users

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier

try {
    $result = $apiInstance->privateProjectCollaboratorsList($project_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectCollaboratorsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |

### Return type

[**\Swagger\Client\Model\ProjectCollaborator[]**](../Model/ProjectCollaborator.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectCreate**
> \Swagger\Client\Model\CreateProjectResponse privateProjectCreate($project)

Create project

Create a new project

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project = new \Swagger\Client\Model\ProjectCreate(); // \Swagger\Client\Model\ProjectCreate | Project  description

try {
    $result = $apiInstance->privateProjectCreate($project);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectCreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project** | [**\Swagger\Client\Model\ProjectCreate**](../Model/ProjectCreate.md)| Project  description |

### Return type

[**\Swagger\Client\Model\CreateProjectResponse**](../Model/CreateProjectResponse.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectDelete**
> privateProjectDelete($project_id)

Delete project

A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier

try {
    $apiInstance->privateProjectDelete($project_id);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectDetails**
> \Swagger\Client\Model\ProjectCompletePrivate privateProjectDetails($project_id)

View project details

View a private project

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier

try {
    $result = $apiInstance->privateProjectDetails($project_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |

### Return type

[**\Swagger\Client\Model\ProjectCompletePrivate**](../Model/ProjectCompletePrivate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectLeave**
> privateProjectLeave($project_id)

Private Project Leave

Please note: project's owner cannot leave the project.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier

try {
    $apiInstance->privateProjectLeave($project_id);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectLeave: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectNote**
> \Swagger\Client\Model\ProjectNotePrivate privateProjectNote($project_id, $note_id)

Project note details

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$note_id = 789; // int | Note unique identifier

try {
    $result = $apiInstance->privateProjectNote($project_id, $note_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectNote: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **note_id** | **int**| Note unique identifier |

### Return type

[**\Swagger\Client\Model\ProjectNotePrivate**](../Model/ProjectNotePrivate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectNoteDelete**
> privateProjectNoteDelete($project_id, $note_id)

Delete project note

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$note_id = 789; // int | Note unique identifier

try {
    $apiInstance->privateProjectNoteDelete($project_id, $note_id);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectNoteDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **note_id** | **int**| Note unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectNoteUpdate**
> privateProjectNoteUpdate($project_id, $note_id, $note)

Update project note

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$note_id = 789; // int | Note unique identifier
$note = new \Swagger\Client\Model\ProjectNoteCreate(); // \Swagger\Client\Model\ProjectNoteCreate | Note message

try {
    $apiInstance->privateProjectNoteUpdate($project_id, $note_id, $note);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectNoteUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **note_id** | **int**| Note unique identifier |
 **note** | [**\Swagger\Client\Model\ProjectNoteCreate**](../Model/ProjectNoteCreate.md)| Note message |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectNotesCreate**
> \Swagger\Client\Model\Location privateProjectNotesCreate($project_id, $note)

Create project note

Create a new project note

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$note = new \Swagger\Client\Model\ProjectNoteCreate(); // \Swagger\Client\Model\ProjectNoteCreate | Note message

try {
    $result = $apiInstance->privateProjectNotesCreate($project_id, $note);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectNotesCreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **note** | [**\Swagger\Client\Model\ProjectNoteCreate**](../Model/ProjectNoteCreate.md)| Note message |

### Return type

[**\Swagger\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectNotesList**
> \Swagger\Client\Model\ProjectNote[] privateProjectNotesList($project_id, $page, $page_size, $limit, $offset)

List project notes

List project notes

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->privateProjectNotesList($project_id, $page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectNotesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]

### Return type

[**\Swagger\Client\Model\ProjectNote[]**](../Model/ProjectNote.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectPartialUpdate**
> privateProjectPartialUpdate($project_id, $project)

Partially update project

Partially update a project; only provided fields will be changed.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$project = new \Swagger\Client\Model\ProjectUpdate(); // \Swagger\Client\Model\ProjectUpdate | Fields to update

try {
    $apiInstance->privateProjectPartialUpdate($project_id, $project);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectPartialUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **project** | [**\Swagger\Client\Model\ProjectUpdate**](../Model/ProjectUpdate.md)| Fields to update | [optional]

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectPublish**
> \Swagger\Client\Model\ResponseMessage privateProjectPublish($project_id)

Private Project Publish

Publish a project. Possible after all items inside it are public

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier

try {
    $result = $apiInstance->privateProjectPublish($project_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectPublish: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |

### Return type

[**\Swagger\Client\Model\ResponseMessage**](../Model/ResponseMessage.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectUpdate**
> privateProjectUpdate($project_id, $project)

Update project

Updating an project by passing body parameters.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$project_id = 789; // int | Project unique identifier
$project = new \Swagger\Client\Model\ProjectUpdate(); // \Swagger\Client\Model\ProjectUpdate | Project description

try {
    $apiInstance->privateProjectUpdate($project_id, $project);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier |
 **project** | [**\Swagger\Client\Model\ProjectUpdate**](../Model/ProjectUpdate.md)| Project description |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectsList**
> \Swagger\Client\Model\ProjectPrivate[] privateProjectsList($page, $page_size, $limit, $offset, $order, $order_direction, $storage, $roles)

Private Projects

List private projects

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing (the offset of the first result). Used for pagination with limit
$order = "published_date"; // string | The field by which to order.
$order_direction = "desc"; // string | 
$storage = "storage_example"; // string | only return collections from this institution
$roles = "roles_example"; // string | Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\".

try {
    $result = $apiInstance->privateProjectsList($page, $page_size, $limit, $offset, $order, $order_direction, $storage, $roles);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]
 **order** | **string**| The field by which to order. | [optional] [default to published_date]
 **order_direction** | **string**|  | [optional] [default to desc]
 **storage** | **string**| only return collections from this institution | [optional]
 **roles** | **string**| Any combination of owner, collaborator, viewer separated by comma. Examples: \&quot;owner\&quot; or \&quot;owner,collaborator\&quot;. | [optional]

### Return type

[**\Swagger\Client\Model\ProjectPrivate[]**](../Model/ProjectPrivate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateProjectsSearch**
> \Swagger\Client\Model\ProjectPrivate[] privateProjectsSearch($search)

Private Projects search

Search inside the private projects

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search = new \Swagger\Client\Model\ProjectsSearch(); // \Swagger\Client\Model\ProjectsSearch | Search Parameters

try {
    $result = $apiInstance->privateProjectsSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->privateProjectsSearch: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**\Swagger\Client\Model\ProjectsSearch**](../Model/ProjectsSearch.md)| Search Parameters | [optional]

### Return type

[**\Swagger\Client\Model\ProjectPrivate[]**](../Model/ProjectPrivate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **projectArticles**
> \Swagger\Client\Model\Article[] projectArticles($project_id, $page, $page_size, $limit, $offset)

Public Project Articles

List articles in project

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$project_id = 789; // int | Project Unique identifier
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->projectArticles($project_id, $page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->projectArticles: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project Unique identifier |
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]

### Return type

[**\Swagger\Client\Model\Article[]**](../Model/Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **projectDetails**
> \Swagger\Client\Model\ProjectComplete projectDetails($project_id)

Public Project

View a project

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$project_id = 789; // int | Project Unique identifier

try {
    $result = $apiInstance->projectDetails($project_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->projectDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project Unique identifier |

### Return type

[**\Swagger\Client\Model\ProjectComplete**](../Model/ProjectComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **projectsList**
> \Swagger\Client\Model\Project[] projectsList($x_cursor, $page, $page_size, $limit, $offset, $order, $order_direction, $institution, $published_since, $group)

Public Projects

Returns a list of public projects

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$x_cursor = "x_cursor_example"; // string | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing (the offset of the first result). Used for pagination with limit
$order = "published_date"; // string | The field by which to order. Default varies by endpoint/resource.
$order_direction = "desc"; // string | 
$institution = 789; // int | only return collections from this institution
$published_since = "published_since_example"; // string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
$group = 789; // int | only return collections from this group

try {
    $result = $apiInstance->projectsList($x_cursor, $page, $page_size, $limit, $offset, $order, $order_direction, $institution, $published_since, $group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->projectsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **x_cursor** | [**string**](../Model/.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional]
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **string**|  | [optional] [default to desc]
 **institution** | **int**| only return collections from this institution | [optional]
 **published_since** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional]
 **group** | **int**| only return collections from this group | [optional]

### Return type

[**\Swagger\Client\Model\Project[]**](../Model/Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **projectsSearch**
> \Swagger\Client\Model\Project[] projectsSearch($x_cursor, $search)

Public Projects Search

Returns a list of public articles

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProjectsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$x_cursor = "x_cursor_example"; // string | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
$search = new \Swagger\Client\Model\ProjectsSearch(); // \Swagger\Client\Model\ProjectsSearch | Search Parameters

try {
    $result = $apiInstance->projectsSearch($x_cursor, $search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProjectsApi->projectsSearch: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **x_cursor** | [**string**](../Model/.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional]
 **search** | [**\Swagger\Client\Model\ProjectsSearch**](../Model/ProjectsSearch.md)| Search Parameters | [optional]

### Return type

[**\Swagger\Client\Model\Project[]**](../Model/Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

