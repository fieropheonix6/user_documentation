# # ArticleConfidentiality

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_confidential** | **bool** | True if article is confidential |
**reason** | **string** | Reason for confidentiality |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
