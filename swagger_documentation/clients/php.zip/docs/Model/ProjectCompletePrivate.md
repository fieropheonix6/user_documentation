# # ProjectCompletePrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **string** | Project funding |
**funding_list** | [**\OpenAPI\Client\Model\FundingInformation[]**](FundingInformation.md) | Full Project funding information |
**description** | **string** | Project description |
**collaborators** | [**\OpenAPI\Client\Model\Collaborator[]**](Collaborator.md) | List of project collaborators |
**quota** | **int** | Project quota |
**used_quota** | **int** | Project used quota |
**created_date** | **string** | Date when project was created |
**modified_date** | **string** | Date when project was last modified |
**used_quota_private** | **int** | Project private quota used |
**used_quota_public** | **int** | Project public quota used |
**group_id** | **int** | Group of project if any |
**account_id** | **int** | ID of the account owning the project |
**custom_fields** | [**\OpenAPI\Client\Model\ShortCustomField[]**](ShortCustomField.md) | Collection custom fields |
**role** | **string** | Role inside this project |
**storage** | **string** | Project storage type |
**url** | **string** | Api endpoint |
**id** | **int** | Project id |
**title** | **string** | Project title |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
