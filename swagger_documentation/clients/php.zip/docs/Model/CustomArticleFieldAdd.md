# # CustomArticleFieldAdd

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Custom  metadata name |
**value** | [**\OpenAPI\Client\Model\CustomArticleFieldAddValue**](CustomArticleFieldAddValue.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
