# # ArticlesCreator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | **int[]** | List of article ids |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
