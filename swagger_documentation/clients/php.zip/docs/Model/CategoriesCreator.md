# # CategoriesCreator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | **int[]** | List of category ids |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
