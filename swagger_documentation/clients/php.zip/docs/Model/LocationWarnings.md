# # LocationWarnings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entity_id** | **int** | Figshare ID of the entity |
**location** | **string** | Url for entity |
**warnings** | **string[]** | Issues encountered during the operation |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
