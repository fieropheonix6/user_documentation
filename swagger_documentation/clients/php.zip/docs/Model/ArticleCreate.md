# # ArticleCreate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** | Title of article |
**description** | **string** | The article description. In a publisher case, usually this is the remote article description | [optional] [default to '']
**is_metadata_record** | **bool** | True if article has no files | [optional]
**metadata_reason** | **string** | Article metadata reason | [optional]
**tags** | **string[]** | List of tags to be associated with the article. Keywords can be used instead | [optional]
**keywords** | **string[]** | List of tags to be associated with the article. Tags can be used instead | [optional]
**references** | **string[]** | List of links to be associated with the article (e.g [\&quot;http://link1\&quot;, \&quot;http://link2\&quot;, \&quot;http://link3\&quot;]) | [optional]
**related_materials** | [**\OpenAPI\Client\Model\RelatedMaterial[]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional]
**categories** | **int[]** | List of category ids to be associated with the article(e.g [1, 23, 33, 66]) | [optional]
**categories_by_source_id** | **string[]** | List of category source ids to be associated with the article, supersedes the categories property | [optional]
**authors** | **object[]** | List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint. | [optional]
**custom_fields** | **object** | List of key, values pairs to be associated with the article | [optional]
**custom_fields_list** | [**\OpenAPI\Client\Model\CustomArticleFieldAdd[]**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter | [optional]
**defined_type** | **string** | &lt;b&gt;One of:&lt;/b&gt; &lt;code&gt;figure&lt;/code&gt; &lt;code&gt;online resource&lt;/code&gt; &lt;code&gt;preprint&lt;/code&gt; &lt;code&gt;book&lt;/code&gt; &lt;code&gt;conference contribution&lt;/code&gt; &lt;code&gt;media&lt;/code&gt; &lt;code&gt;dataset&lt;/code&gt; &lt;code&gt;poster&lt;/code&gt; &lt;code&gt;journal contribution&lt;/code&gt; &lt;code&gt;presentation&lt;/code&gt; &lt;code&gt;thesis&lt;/code&gt; &lt;code&gt;software&lt;/code&gt; | [optional]
**funding** | **string** | Grant number or funding authority | [optional] [default to '']
**funding_list** | [**\OpenAPI\Client\Model\FundingCreate[]**](FundingCreate.md) | Funding creation / update items | [optional]
**license** | **int** | License id for this article. | [optional] [default to 0]
**doi** | **string** | Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional] [default to '']
**handle** | **string** | Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional] [default to '']
**resource_doi** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [optional] [default to '']
**resource_title** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [optional] [default to '']
**timeline** | [**\OpenAPI\Client\Model\TimelineUpdate**](TimelineUpdate.md) |  | [optional]
**group_id** | **int** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
