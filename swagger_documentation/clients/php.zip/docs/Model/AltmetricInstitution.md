# # AltmetricInstitution

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Institution id |
**name** | **string** | Institution name |
**custom_domain** | **string** | Custom domain for the institution | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
