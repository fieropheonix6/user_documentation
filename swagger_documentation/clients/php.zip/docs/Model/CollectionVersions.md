# # CollectionVersions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **int** | Version number |
**url** | **string** | Api endpoint for the collection version |
**funding** | [**\OpenAPI\Client\Model\FundingInformation[]**](FundingInformation.md) | Full Collection funding information |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
