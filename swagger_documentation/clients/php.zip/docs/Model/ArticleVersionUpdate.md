# # ArticleVersionUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supplementary_fields** | **object[]** | List of supplementary fields to be associated with the article version | [optional]
**internal_metadata** | **object** | List of supplementary fields to be associated with the article version | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
