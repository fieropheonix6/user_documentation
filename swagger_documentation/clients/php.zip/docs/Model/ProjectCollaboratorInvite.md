# # ProjectCollaboratorInvite

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_name** | **string** | Role of the the collaborator inside the project |
**user_id** | **int** | User id of the collaborator | [optional]
**email** | **string** | Collaborator email | [optional]
**comment** | **string** | Text sent when inviting the user to the project | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
