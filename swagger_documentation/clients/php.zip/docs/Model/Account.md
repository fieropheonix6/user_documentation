# # Account

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Account id |
**first_name** | **string** | First Name |
**last_name** | **string** | Last Name |
**used_quota_private** | **int** | Account used private quota |
**modified_date** | **string** | Date of last account modification |
**used_quota** | **int** | Account total used quota |
**created_date** | **string** | Date when account was created |
**quota** | **int** | Account quota |
**group_id** | **int** | Account group id |
**institution_user_id** | **string** | Account institution user id |
**institution_id** | **int** | Account institution |
**email** | **string** | User email |
**used_quota_public** | **int** | Account public used quota |
**pending_quota_request** | **bool** | True if a quota request is pending |
**active** | **int** | Account activity status |
**maximum_file_size** | **int** | Maximum upload size for account |
**user_id** | **int** | User id associated with account, useful for example for adding the account as an author to an item |
**orcid_id** | **string** | ORCID iD associated to account |
**symplectic_user_id** | **string** | Symplectic ID associated to account |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
