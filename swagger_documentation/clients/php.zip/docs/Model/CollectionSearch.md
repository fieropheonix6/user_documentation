# # CollectionSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource_doi** | **string** | Only return collections with this resource_doi | [optional]
**doi** | **string** | Only return collections with this doi | [optional]
**handle** | **string** | Only return collections with this handle | [optional]
**order** | **string** | The field by which to order. | [optional] [default to 'created_date']
**search_for** | **string** | Search term | [optional]
**page** | **int** | Page number. Used for pagination with page_size | [optional]
**page_size** | **int** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **int** | Number of results included on a page. Used for pagination with query | [optional]
**offset** | **int** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]
**order_direction** | **string** | Direction of ordering | [optional] [default to 'desc']
**institution** | **int** | only return collections from this institution | [optional]
**published_since** | **string** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional]
**modified_since** | **string** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional]
**group** | **int** | only return collections from this group | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
