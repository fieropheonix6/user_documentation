# # ProfileUpdateDataPersonalProfilesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **string** | Label for the personal profile link | [optional]
**url** | **string** | URL for the personal profile link | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
