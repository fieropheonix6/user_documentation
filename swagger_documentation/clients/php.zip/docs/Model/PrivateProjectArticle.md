# # PrivateProjectArticle

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**files** | [**\OpenAPI\Client\Model\PublicFile[]**](PublicFile.md) | List of up to 10 article files. |
**embargo_options** | [**\OpenAPI\Client\Model\GroupEmbargoOptions[]**](GroupEmbargoOptions.md) | List of embargo options |
**custom_fields** | [**\OpenAPI\Client\Model\CustomArticleField[]**](CustomArticleField.md) | List of custom fields values |
**account_id** | **int** | ID of the account owning the article |
**download_disabled** | **bool** | If true, downloading of files for this article is disabled |
**authors** | [**\OpenAPI\Client\Model\Author[]**](Author.md) | List of authors |
**figshare_url** | **string** | Article public url |
**curation_status** | **string** | Curation status of the article |
**citation** | **string** | Article citation |
**confidential_reason** | **string** | Confidentiality reason |
**is_confidential** | **bool** | Article Confidentiality |
**size** | **int** | Article size |
**funding** | **string** | Article funding |
**funding_list** | [**\OpenAPI\Client\Model\FundingInformation[]**](FundingInformation.md) | Full Article funding information |
**tags** | **string[]** | List of article tags. Keywords can be used instead |
**keywords** | **string[]** | List of article keywords. Tags can be used instead |
**version** | **int** | Article version |
**is_metadata_record** | **bool** | True if article has no files |
**metadata_reason** | **string** | Article metadata reason |
**status** | **string** | Article status |
**description** | **string** | Article description |
**is_embargoed** | **bool** | True if article is embargoed |
**is_public** | **bool** | True if article is published |
**created_date** | **string** | Date when article was created |
**has_linked_file** | **bool** | True if any files are linked to the article |
**categories** | [**\OpenAPI\Client\Model\Category[]**](Category.md) | List of categories selected for the article |
**license** | [**\OpenAPI\Client\Model\License**](License.md) |  |
**embargo_title** | **string** | Title for embargo |
**embargo_reason** | **string** | Reason for embargo |
**references** | **string[]** | List of references |
**related_materials** | [**\OpenAPI\Client\Model\RelatedMaterial[]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional]
**id** | **int** | Unique identifier for article |
**title** | **string** | Title of article |
**doi** | **string** | DOI |
**handle** | **string** | Handle |
**url** | **string** | Api endpoint for article |
**url_public_html** | **string** | Public site endpoint for article |
**url_public_api** | **string** | Public Api endpoint for article |
**url_private_html** | **string** | Private site endpoint for article |
**url_private_api** | **string** | Private Api endpoint for article |
**timeline** | [**\OpenAPI\Client\Model\Timeline**](Timeline.md) |  |
**thumb** | **string** | Thumbnail image |
**defined_type** | **int** | Type of article identifier |
**defined_type_name** | **string** | Name of the article type identifier |
**resource_doi** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to '']
**resource_title** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to '']

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
