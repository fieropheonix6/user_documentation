# OpenAPI\Client\ArticlesApi

All URIs are relative to http://localhost, except if the operation defines another base path.

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**accountArticlePublish()**](ArticlesApi.md#accountArticlePublish) | **POST** /account/articles/{article_id}/publish | Private Article Publish |
| [**accountArticleReport()**](ArticlesApi.md#accountArticleReport) | **GET** /account/articles/export | Account Article Report |
| [**accountArticleReportGenerate()**](ArticlesApi.md#accountArticleReportGenerate) | **POST** /account/articles/export | Initiate a new Report |
| [**accountArticleUnpublish()**](ArticlesApi.md#accountArticleUnpublish) | **POST** /account/articles/{article_id}/unpublish | Public Article Unpublish |
| [**articleDetails()**](ArticlesApi.md#articleDetails) | **GET** /articles/{article_id} | View article details |
| [**articleFileDetails()**](ArticlesApi.md#articleFileDetails) | **GET** /articles/{article_id}/files/{file_id} | Article file details |
| [**articleFiles()**](ArticlesApi.md#articleFiles) | **GET** /articles/{article_id}/files | List article files |
| [**articleVersionConfidentiality()**](ArticlesApi.md#articleVersionConfidentiality) | **GET** /articles/{article_id}/versions/{version_id}/confidentiality | Public Article Confidentiality for article version |
| [**articleVersionDetails()**](ArticlesApi.md#articleVersionDetails) | **GET** /articles/{article_id}/versions/{version_id} | Article details for version |
| [**articleVersionEmbargo()**](ArticlesApi.md#articleVersionEmbargo) | **GET** /articles/{article_id}/versions/{version_id}/embargo | Public Article Embargo for article version |
| [**articleVersionFiles()**](ArticlesApi.md#articleVersionFiles) | **GET** /articles/{article_id}/versions/{version_id}/files | Public Article version files |
| [**articleVersionPartialUpdate()**](ArticlesApi.md#articleVersionPartialUpdate) | **PATCH** /account/articles/{article_id}/versions/{version_id} | Partially update article version |
| [**articleVersionUpdate()**](ArticlesApi.md#articleVersionUpdate) | **PUT** /account/articles/{article_id}/versions/{version_id} | Update article version |
| [**articleVersionUpdateThumb()**](ArticlesApi.md#articleVersionUpdateThumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail |
| [**articleVersions()**](ArticlesApi.md#articleVersions) | **GET** /articles/{article_id}/versions | List article versions |
| [**articlesList()**](ArticlesApi.md#articlesList) | **GET** /articles | Public Articles |
| [**articlesSearch()**](ArticlesApi.md#articlesSearch) | **POST** /articles/search | Public Articles Search |
| [**privateArticleAuthorDelete()**](ArticlesApi.md#privateArticleAuthorDelete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author |
| [**privateArticleAuthorsAdd()**](ArticlesApi.md#privateArticleAuthorsAdd) | **POST** /account/articles/{article_id}/authors | Add article authors |
| [**privateArticleAuthorsList()**](ArticlesApi.md#privateArticleAuthorsList) | **GET** /account/articles/{article_id}/authors | List article authors |
| [**privateArticleAuthorsReplace()**](ArticlesApi.md#privateArticleAuthorsReplace) | **PUT** /account/articles/{article_id}/authors | Replace article authors |
| [**privateArticleCategoriesAdd()**](ArticlesApi.md#privateArticleCategoriesAdd) | **POST** /account/articles/{article_id}/categories | Add article categories |
| [**privateArticleCategoriesList()**](ArticlesApi.md#privateArticleCategoriesList) | **GET** /account/articles/{article_id}/categories | List article categories |
| [**privateArticleCategoriesReplace()**](ArticlesApi.md#privateArticleCategoriesReplace) | **PUT** /account/articles/{article_id}/categories | Replace article categories |
| [**privateArticleCategoryDelete()**](ArticlesApi.md#privateArticleCategoryDelete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category |
| [**privateArticleConfidentialityDelete()**](ArticlesApi.md#privateArticleConfidentialityDelete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality |
| [**privateArticleConfidentialityDetails()**](ArticlesApi.md#privateArticleConfidentialityDetails) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details |
| [**privateArticleConfidentialityUpdate()**](ArticlesApi.md#privateArticleConfidentialityUpdate) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality |
| [**privateArticleCreate()**](ArticlesApi.md#privateArticleCreate) | **POST** /account/articles | Create new Article |
| [**privateArticleDelete()**](ArticlesApi.md#privateArticleDelete) | **DELETE** /account/articles/{article_id} | Delete article |
| [**privateArticleDetails()**](ArticlesApi.md#privateArticleDetails) | **GET** /account/articles/{article_id} | Article details |
| [**privateArticleDownload()**](ArticlesApi.md#privateArticleDownload) | **GET** /account/articles/{article_id}/download | Private Article Download |
| [**privateArticleEmbargoDelete()**](ArticlesApi.md#privateArticleEmbargoDelete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo |
| [**privateArticleEmbargoDetails()**](ArticlesApi.md#privateArticleEmbargoDetails) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details |
| [**privateArticleEmbargoUpdate()**](ArticlesApi.md#privateArticleEmbargoUpdate) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo |
| [**privateArticleFile()**](ArticlesApi.md#privateArticleFile) | **GET** /account/articles/{article_id}/files/{file_id} | Single File |
| [**privateArticleFileDelete()**](ArticlesApi.md#privateArticleFileDelete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete |
| [**privateArticleFilesList()**](ArticlesApi.md#privateArticleFilesList) | **GET** /account/articles/{article_id}/files | List article files |
| [**privateArticlePartialUpdate()**](ArticlesApi.md#privateArticlePartialUpdate) | **PATCH** /account/articles/{article_id} | Partially update article |
| [**privateArticlePrivateLink()**](ArticlesApi.md#privateArticlePrivateLink) | **GET** /account/articles/{article_id}/private_links | List private links |
| [**privateArticlePrivateLinkCreate()**](ArticlesApi.md#privateArticlePrivateLinkCreate) | **POST** /account/articles/{article_id}/private_links | Create private link |
| [**privateArticlePrivateLinkDelete()**](ArticlesApi.md#privateArticlePrivateLinkDelete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link |
| [**privateArticlePrivateLinkUpdate()**](ArticlesApi.md#privateArticlePrivateLinkUpdate) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link |
| [**privateArticleReserveDoi()**](ArticlesApi.md#privateArticleReserveDoi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI |
| [**privateArticleReserveHandle()**](ArticlesApi.md#privateArticleReserveHandle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle |
| [**privateArticleResource()**](ArticlesApi.md#privateArticleResource) | **POST** /account/articles/{article_id}/resource | Private Article Resource |
| [**privateArticleUpdate()**](ArticlesApi.md#privateArticleUpdate) | **PUT** /account/articles/{article_id} | Update article |
| [**privateArticleUploadComplete()**](ArticlesApi.md#privateArticleUploadComplete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload |
| [**privateArticleUploadInitiate()**](ArticlesApi.md#privateArticleUploadInitiate) | **POST** /account/articles/{article_id}/files | Initiate Upload |
| [**privateArticlesList()**](ArticlesApi.md#privateArticlesList) | **GET** /account/articles | Private Articles |
| [**privateArticlesSearch()**](ArticlesApi.md#privateArticlesSearch) | **POST** /account/articles/search | Private Articles search |
| [**publicArticleDownload()**](ArticlesApi.md#publicArticleDownload) | **GET** /articles/{article_id}/download | Public Article Download |
| [**publicArticleVersionDownload()**](ArticlesApi.md#publicArticleVersionDownload) | **GET** /articles/{article_id}/versions/{version_id}/download | Public Article Version Download |


## `accountArticlePublish()`

```php
accountArticlePublish($article_id): \OpenAPI\Client\Model\Location
```

Private Article Publish

- If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $result = $apiInstance->accountArticlePublish($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->accountArticlePublish: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

[**\OpenAPI\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `accountArticleReport()`

```php
accountArticleReport($group_id): \OpenAPI\Client\Model\AccountReport[]
```

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$group_id = 56; // int | A group ID to filter by

try {
    $result = $apiInstance->accountArticleReport($group_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->accountArticleReport: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **group_id** | **int**| A group ID to filter by | [optional] |

### Return type

[**\OpenAPI\Client\Model\AccountReport[]**](../Model/AccountReport.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `accountArticleReportGenerate()`

```php
accountArticleReportGenerate(): \OpenAPI\Client\Model\AccountReport
```

Initiate a new Report

Initiate a new Article Report for this Account. There is a limit of 1 report per day.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->accountArticleReportGenerate();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->accountArticleReportGenerate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**\OpenAPI\Client\Model\AccountReport**](../Model/AccountReport.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `accountArticleUnpublish()`

```php
accountArticleUnpublish($article_id, $reason)
```

Public Article Unpublish

Allows authorized users to unpublish an article.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$reason = new \OpenAPI\Client\Model\ArticleUnpublishData(); // \OpenAPI\Client\Model\ArticleUnpublishData | Article unpublish data

try {
    $apiInstance->accountArticleUnpublish($article_id, $reason);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->accountArticleUnpublish: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **reason** | [**\OpenAPI\Client\Model\ArticleUnpublishData**](../Model/ArticleUnpublishData.md)| Article unpublish data | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleDetails()`

```php
articleDetails($article_id): \OpenAPI\Client\Model\ArticleComplete
```

View article details

View an article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 56; // int | Article Unique identifier

try {
    $result = $apiInstance->articleDetails($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article Unique identifier | |

### Return type

[**\OpenAPI\Client\Model\ArticleComplete**](../Model/ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleFileDetails()`

```php
articleFileDetails($article_id, $file_id): \OpenAPI\Client\Model\PublicFile
```

Article file details

File by id

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 56; // int | Article Unique identifier
$file_id = 56; // int | File Unique identifier

try {
    $result = $apiInstance->articleFileDetails($article_id, $file_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleFileDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article Unique identifier | |
| **file_id** | **int**| File Unique identifier | |

### Return type

[**\OpenAPI\Client\Model\PublicFile**](../Model/PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleFiles()`

```php
articleFiles($article_id, $page, $page_size, $limit, $offset): \OpenAPI\Client\Model\PublicFile[]
```

List article files

Files list for article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 56; // int | Article Unique identifier
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->articleFiles($article_id, $page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleFiles: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article Unique identifier | |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**\OpenAPI\Client\Model\PublicFile[]**](../Model/PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleVersionConfidentiality()`

```php
articleVersionConfidentiality($article_id, $version_id): \OpenAPI\Client\Model\ArticleConfidentiality
```

Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 56; // int | Article Unique identifier
$version_id = 56; // int | Version Number

try {
    $result = $apiInstance->articleVersionConfidentiality($article_id, $version_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionConfidentiality: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article Unique identifier | |
| **version_id** | **int**| Version Number | |

### Return type

[**\OpenAPI\Client\Model\ArticleConfidentiality**](../Model/ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleVersionDetails()`

```php
articleVersionDetails($article_id, $version_id): \OpenAPI\Client\Model\ArticleComplete
```

Article details for version

Article with specified version

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 56; // int | Article Unique identifier
$version_id = 56; // int | Article Version Number

try {
    $result = $apiInstance->articleVersionDetails($article_id, $version_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article Unique identifier | |
| **version_id** | **int**| Article Version Number | |

### Return type

[**\OpenAPI\Client\Model\ArticleComplete**](../Model/ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleVersionEmbargo()`

```php
articleVersionEmbargo($article_id, $version_id): \OpenAPI\Client\Model\ArticleEmbargo
```

Public Article Embargo for article version

Embargo for article version

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 56; // int | Article Unique identifier
$version_id = 56; // int | Version Number

try {
    $result = $apiInstance->articleVersionEmbargo($article_id, $version_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionEmbargo: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article Unique identifier | |
| **version_id** | **int**| Version Number | |

### Return type

[**\OpenAPI\Client\Model\ArticleEmbargo**](../Model/ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleVersionFiles()`

```php
articleVersionFiles($article_id, $version_id, $page, $page_size, $limit, $offset): \OpenAPI\Client\Model\PublicFile[]
```

Public Article version files

Article version file details

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 56; // int | Article Unique identifier
$version_id = 56; // int | Article Version Unique identifier
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->articleVersionFiles($article_id, $version_id, $page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionFiles: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article Unique identifier | |
| **version_id** | **int**| Article Version Unique identifier | |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**\OpenAPI\Client\Model\PublicFile[]**](../Model/PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleVersionPartialUpdate()`

```php
articleVersionPartialUpdate($article_id, $version_id, $article): \OpenAPI\Client\Model\LocationWarningsUpdate
```

Partially update article version

Partially updating an article version by passing only the fields to change.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$version_id = 56; // int | Article version identifier
$article = new \OpenAPI\Client\Model\ArticleVersionUpdate(); // \OpenAPI\Client\Model\ArticleVersionUpdate | Subset of article version fields to update

try {
    $result = $apiInstance->articleVersionPartialUpdate($article_id, $version_id, $article);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionPartialUpdate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **version_id** | **int**| Article version identifier | |
| **article** | [**\OpenAPI\Client\Model\ArticleVersionUpdate**](../Model/ArticleVersionUpdate.md)| Subset of article version fields to update | |

### Return type

[**\OpenAPI\Client\Model\LocationWarningsUpdate**](../Model/LocationWarningsUpdate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleVersionUpdate()`

```php
articleVersionUpdate($article_id, $version_id, $article): \OpenAPI\Client\Model\LocationWarningsUpdate
```

Update article version

Updating an article version by passing body parameters.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$version_id = 56; // int | Article version identifier
$article = new \OpenAPI\Client\Model\ArticleVersionUpdate(); // \OpenAPI\Client\Model\ArticleVersionUpdate | Article description

try {
    $result = $apiInstance->articleVersionUpdate($article_id, $version_id, $article);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionUpdate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **version_id** | **int**| Article version identifier | |
| **article** | [**\OpenAPI\Client\Model\ArticleVersionUpdate**](../Model/ArticleVersionUpdate.md)| Article description | |

### Return type

[**\OpenAPI\Client\Model\LocationWarningsUpdate**](../Model/LocationWarningsUpdate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleVersionUpdateThumb()`

```php
articleVersionUpdateThumb($article_id, $version_id, $file_id)
```

Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$version_id = 56; // int | Article version identifier
$file_id = new \OpenAPI\Client\Model\FileId(); // \OpenAPI\Client\Model\FileId | File ID

try {
    $apiInstance->articleVersionUpdateThumb($article_id, $version_id, $file_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionUpdateThumb: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **version_id** | **int**| Article version identifier | |
| **file_id** | [**\OpenAPI\Client\Model\FileId**](../Model/FileId.md)| File ID | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articleVersions()`

```php
articleVersions($article_id): \OpenAPI\Client\Model\ArticleVersions[]
```

List article versions

List public article versions

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 56; // int | Article Unique identifier

try {
    $result = $apiInstance->articleVersions($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersions: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article Unique identifier | |

### Return type

[**\OpenAPI\Client\Model\ArticleVersions[]**](../Model/ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articlesList()`

```php
articlesList($x_cursor, $page, $page_size, $limit, $offset, $order, $order_direction, $institution, $published_since, $modified_since, $group, $resource_doi, $item_type, $doi, $handle): \OpenAPI\Client\Model\Article[]
```

Public Articles

Returns a list of public articles

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$x_cursor = 'x_cursor_example'; // string | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit
$order = 'published_date'; // string | The field by which to order. Default varies by endpoint/resource.
$order_direction = 'desc'; // string
$institution = 56; // int | only return articles from this institution
$published_since = 'published_since_example'; // string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
$modified_since = 'modified_since_example'; // string | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
$group = 56; // int | only return articles from this group
$resource_doi = 'resource_doi_example'; // string | Deprecated by related materials. Only return articles with this resource_doi
$item_type = 56; // int | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
$doi = 'doi_example'; // string | only return articles with this doi
$handle = 'handle_example'; // string | only return articles with this handle

try {
    $result = $apiInstance->articlesList($x_cursor, $page, $page_size, $limit, $offset, $order, $order_direction, $institution, $published_since, $modified_since, $group, $resource_doi, $item_type, $doi, $handle);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articlesList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **x_cursor** | **string**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to &#39;published_date&#39;] |
| **order_direction** | **string**|  | [optional] [default to &#39;desc&#39;] |
| **institution** | **int**| only return articles from this institution | [optional] |
| **published_since** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **modified_since** | **string**| Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **group** | **int**| only return articles from this group | [optional] |
| **resource_doi** | **string**| Deprecated by related materials. Only return articles with this resource_doi | [optional] |
| **item_type** | **int**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] |
| **doi** | **string**| only return articles with this doi | [optional] |
| **handle** | **string**| only return articles with this handle | [optional] |

### Return type

[**\OpenAPI\Client\Model\Article[]**](../Model/Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `articlesSearch()`

```php
articlesSearch($x_cursor, $search): \OpenAPI\Client\Model\ArticleWithProject[]
```

Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$x_cursor = 'x_cursor_example'; // string | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
$search = new \OpenAPI\Client\Model\ArticleSearch(); // \OpenAPI\Client\Model\ArticleSearch | Search Parameters

try {
    $result = $apiInstance->articlesSearch($x_cursor, $search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articlesSearch: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **x_cursor** | **string**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **search** | [**\OpenAPI\Client\Model\ArticleSearch**](../Model/ArticleSearch.md)| Search Parameters | [optional] |

### Return type

[**\OpenAPI\Client\Model\ArticleWithProject[]**](../Model/ArticleWithProject.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleAuthorDelete()`

```php
privateArticleAuthorDelete($article_id, $author_id)
```

Delete article author

De-associate author from article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$author_id = 56; // int | Article Author unique identifier

try {
    $apiInstance->privateArticleAuthorDelete($article_id, $author_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleAuthorDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **author_id** | **int**| Article Author unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleAuthorsAdd()`

```php
privateArticleAuthorsAdd($article_id, $authors)
```

Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$authors = new \OpenAPI\Client\Model\AuthorsCreator(); // \OpenAPI\Client\Model\AuthorsCreator | Authors description

try {
    $apiInstance->privateArticleAuthorsAdd($article_id, $authors);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleAuthorsAdd: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **authors** | [**\OpenAPI\Client\Model\AuthorsCreator**](../Model/AuthorsCreator.md)| Authors description | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleAuthorsList()`

```php
privateArticleAuthorsList($article_id): \OpenAPI\Client\Model\Author[]
```

List article authors

List article authors

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $result = $apiInstance->privateArticleAuthorsList($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleAuthorsList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

[**\OpenAPI\Client\Model\Author[]**](../Model/Author.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleAuthorsReplace()`

```php
privateArticleAuthorsReplace($article_id, $authors)
```

Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$authors = new \OpenAPI\Client\Model\AuthorsCreator(); // \OpenAPI\Client\Model\AuthorsCreator | Authors description

try {
    $apiInstance->privateArticleAuthorsReplace($article_id, $authors);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleAuthorsReplace: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **authors** | [**\OpenAPI\Client\Model\AuthorsCreator**](../Model/AuthorsCreator.md)| Authors description | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleCategoriesAdd()`

```php
privateArticleCategoriesAdd($article_id, $categories)
```

Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$categories = new \OpenAPI\Client\Model\CategoriesCreator(); // \OpenAPI\Client\Model\CategoriesCreator

try {
    $apiInstance->privateArticleCategoriesAdd($article_id, $categories);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleCategoriesAdd: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **categories** | [**\OpenAPI\Client\Model\CategoriesCreator**](../Model/CategoriesCreator.md)|  | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleCategoriesList()`

```php
privateArticleCategoriesList($article_id): \OpenAPI\Client\Model\Category[]
```

List article categories

List article categories

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $result = $apiInstance->privateArticleCategoriesList($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleCategoriesList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

[**\OpenAPI\Client\Model\Category[]**](../Model/Category.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleCategoriesReplace()`

```php
privateArticleCategoriesReplace($article_id, $categories)
```

Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$categories = new \OpenAPI\Client\Model\CategoriesCreator(); // \OpenAPI\Client\Model\CategoriesCreator

try {
    $apiInstance->privateArticleCategoriesReplace($article_id, $categories);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleCategoriesReplace: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **categories** | [**\OpenAPI\Client\Model\CategoriesCreator**](../Model/CategoriesCreator.md)|  | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleCategoryDelete()`

```php
privateArticleCategoryDelete($article_id, $category_id)
```

Delete article category

De-associate category from article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$category_id = 56; // int | Category unique identifier

try {
    $apiInstance->privateArticleCategoryDelete($article_id, $category_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleCategoryDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **category_id** | **int**| Category unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleConfidentialityDelete()`

```php
privateArticleConfidentialityDelete($article_id)
```

Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $apiInstance->privateArticleConfidentialityDelete($article_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleConfidentialityDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleConfidentialityDetails()`

```php
privateArticleConfidentialityDetails($article_id): \OpenAPI\Client\Model\ArticleConfidentiality
```

Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $result = $apiInstance->privateArticleConfidentialityDetails($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleConfidentialityDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

[**\OpenAPI\Client\Model\ArticleConfidentiality**](../Model/ArticleConfidentiality.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleConfidentialityUpdate()`

```php
privateArticleConfidentialityUpdate($article_id, $reason)
```

Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$reason = new \OpenAPI\Client\Model\ConfidentialityCreator(); // \OpenAPI\Client\Model\ConfidentialityCreator

try {
    $apiInstance->privateArticleConfidentialityUpdate($article_id, $reason);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleConfidentialityUpdate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **reason** | [**\OpenAPI\Client\Model\ConfidentialityCreator**](../Model/ConfidentialityCreator.md)|  | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleCreate()`

```php
privateArticleCreate($article): \OpenAPI\Client\Model\LocationWarnings
```

Create new Article

Create a new Article by sending article information

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article = new \OpenAPI\Client\Model\ArticleCreate(); // \OpenAPI\Client\Model\ArticleCreate | Article description

try {
    $result = $apiInstance->privateArticleCreate($article);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleCreate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article** | [**\OpenAPI\Client\Model\ArticleCreate**](../Model/ArticleCreate.md)| Article description | |

### Return type

[**\OpenAPI\Client\Model\LocationWarnings**](../Model/LocationWarnings.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleDelete()`

```php
privateArticleDelete($article_id)
```

Delete article

Delete an article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $apiInstance->privateArticleDelete($article_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleDetails()`

```php
privateArticleDetails($article_id): \OpenAPI\Client\Model\ArticleCompletePrivate
```

Article details

View a private article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $result = $apiInstance->privateArticleDetails($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

[**\OpenAPI\Client\Model\ArticleCompletePrivate**](../Model/ArticleCompletePrivate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleDownload()`

```php
privateArticleDownload($article_id, $folder_path)
```

Private Article Download

Download files from a private article preserving the folder structure

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$folder_path = 'folder_path_example'; // string | Folder path to download. If not provided, all files from the article will be downloaded

try {
    $apiInstance->privateArticleDownload($article_id, $folder_path);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleDownload: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **folder_path** | **string**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleEmbargoDelete()`

```php
privateArticleEmbargoDelete($article_id)
```

Delete Article Embargo

Will lift the embargo for the specified article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $apiInstance->privateArticleEmbargoDelete($article_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleEmbargoDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleEmbargoDetails()`

```php
privateArticleEmbargoDetails($article_id): \OpenAPI\Client\Model\ArticleEmbargo
```

Article Embargo Details

View a private article embargo details

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $result = $apiInstance->privateArticleEmbargoDetails($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleEmbargoDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

[**\OpenAPI\Client\Model\ArticleEmbargo**](../Model/ArticleEmbargo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleEmbargoUpdate()`

```php
privateArticleEmbargoUpdate($article_id, $embargo)
```

Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$embargo = new \OpenAPI\Client\Model\ArticleEmbargoUpdater(); // \OpenAPI\Client\Model\ArticleEmbargoUpdater | Embargo description

try {
    $apiInstance->privateArticleEmbargoUpdate($article_id, $embargo);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleEmbargoUpdate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **embargo** | [**\OpenAPI\Client\Model\ArticleEmbargoUpdater**](../Model/ArticleEmbargoUpdater.md)| Embargo description | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleFile()`

```php
privateArticleFile($article_id, $file_id): \OpenAPI\Client\Model\PrivateFile
```

Single File

View details of file for specified article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$file_id = 56; // int | File unique identifier

try {
    $result = $apiInstance->privateArticleFile($article_id, $file_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleFile: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **file_id** | **int**| File unique identifier | |

### Return type

[**\OpenAPI\Client\Model\PrivateFile**](../Model/PrivateFile.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleFileDelete()`

```php
privateArticleFileDelete($article_id, $file_id)
```

File Delete

Complete file upload

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$file_id = 56; // int | File unique identifier

try {
    $apiInstance->privateArticleFileDelete($article_id, $file_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleFileDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **file_id** | **int**| File unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleFilesList()`

```php
privateArticleFilesList($article_id, $page, $page_size, $limit, $offset): \OpenAPI\Client\Model\PrivateFile[]
```

List article files

List private files

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->privateArticleFilesList($article_id, $page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleFilesList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**\OpenAPI\Client\Model\PrivateFile[]**](../Model/PrivateFile.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticlePartialUpdate()`

```php
privateArticlePartialUpdate($article_id, $article): \OpenAPI\Client\Model\LocationWarningsUpdate
```

Partially update article

Partially update an article by sending only the fields to change.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$article = new \OpenAPI\Client\Model\ArticleUpdate(); // \OpenAPI\Client\Model\ArticleUpdate | Subset of article fields to update

try {
    $result = $apiInstance->privateArticlePartialUpdate($article_id, $article);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlePartialUpdate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **article** | [**\OpenAPI\Client\Model\ArticleUpdate**](../Model/ArticleUpdate.md)| Subset of article fields to update | |

### Return type

[**\OpenAPI\Client\Model\LocationWarningsUpdate**](../Model/LocationWarningsUpdate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticlePrivateLink()`

```php
privateArticlePrivateLink($article_id): \OpenAPI\Client\Model\PrivateLink[]
```

List private links

List private links

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $result = $apiInstance->privateArticlePrivateLink($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlePrivateLink: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

[**\OpenAPI\Client\Model\PrivateLink[]**](../Model/PrivateLink.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticlePrivateLinkCreate()`

```php
privateArticlePrivateLinkCreate($article_id, $private_link): \OpenAPI\Client\Model\PrivateLinkResponse
```

Create private link

Create new private link for this article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$private_link = new \OpenAPI\Client\Model\PrivateLinkCreator(); // \OpenAPI\Client\Model\PrivateLinkCreator

try {
    $result = $apiInstance->privateArticlePrivateLinkCreate($article_id, $private_link);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlePrivateLinkCreate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **private_link** | [**\OpenAPI\Client\Model\PrivateLinkCreator**](../Model/PrivateLinkCreator.md)|  | [optional] |

### Return type

[**\OpenAPI\Client\Model\PrivateLinkResponse**](../Model/PrivateLinkResponse.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticlePrivateLinkDelete()`

```php
privateArticlePrivateLinkDelete($article_id, $link_id)
```

Disable private link

Disable/delete private link for this article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$link_id = 'link_id_example'; // string | Private link token

try {
    $apiInstance->privateArticlePrivateLinkDelete($article_id, $link_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlePrivateLinkDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **link_id** | **string**| Private link token | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticlePrivateLinkUpdate()`

```php
privateArticlePrivateLinkUpdate($article_id, $link_id, $private_link)
```

Update private link

Update existing private link for this article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$link_id = 'link_id_example'; // string | Private link token
$private_link = new \OpenAPI\Client\Model\PrivateLinkCreator(); // \OpenAPI\Client\Model\PrivateLinkCreator

try {
    $apiInstance->privateArticlePrivateLinkUpdate($article_id, $link_id, $private_link);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlePrivateLinkUpdate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **link_id** | **string**| Private link token | |
| **private_link** | [**\OpenAPI\Client\Model\PrivateLinkCreator**](../Model/PrivateLinkCreator.md)|  | [optional] |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleReserveDoi()`

```php
privateArticleReserveDoi($article_id): \OpenAPI\Client\Model\ArticleDOI
```

Private Article Reserve DOI

Reserve DOI for article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $result = $apiInstance->privateArticleReserveDoi($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleReserveDoi: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

[**\OpenAPI\Client\Model\ArticleDOI**](../Model/ArticleDOI.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleReserveHandle()`

```php
privateArticleReserveHandle($article_id): \OpenAPI\Client\Model\ArticleHandle
```

Private Article Reserve Handle

Reserve Handle for article

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $result = $apiInstance->privateArticleReserveHandle($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleReserveHandle: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |

### Return type

[**\OpenAPI\Client\Model\ArticleHandle**](../Model/ArticleHandle.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleResource()`

```php
privateArticleResource($article_id, $resource): \OpenAPI\Client\Model\Location
```

Private Article Resource

Edit article resource data.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$resource = new \OpenAPI\Client\Model\Resource(); // \OpenAPI\Client\Model\Resource | Resource data

try {
    $result = $apiInstance->privateArticleResource($article_id, $resource);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleResource: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **resource** | [**\OpenAPI\Client\Model\Resource**](../Model/Resource.md)| Resource data | |

### Return type

[**\OpenAPI\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleUpdate()`

```php
privateArticleUpdate($article_id, $article): \OpenAPI\Client\Model\LocationWarningsUpdate
```

Update article

Update an article by passing full body parameters.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$article = new \OpenAPI\Client\Model\ArticleUpdate(); // \OpenAPI\Client\Model\ArticleUpdate | Full article representation

try {
    $result = $apiInstance->privateArticleUpdate($article_id, $article);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleUpdate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **article** | [**\OpenAPI\Client\Model\ArticleUpdate**](../Model/ArticleUpdate.md)| Full article representation | |

### Return type

[**\OpenAPI\Client\Model\LocationWarningsUpdate**](../Model/LocationWarningsUpdate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleUploadComplete()`

```php
privateArticleUploadComplete($article_id, $file_id)
```

Complete Upload

Complete file upload

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$file_id = 56; // int | File unique identifier

try {
    $apiInstance->privateArticleUploadComplete($article_id, $file_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleUploadComplete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **file_id** | **int**| File unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticleUploadInitiate()`

```php
privateArticleUploadInitiate($article_id, $file, $page, $page_size, $limit, $offset): \OpenAPI\Client\Model\Location
```

Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier
$file = new \OpenAPI\Client\Model\FileCreator(); // \OpenAPI\Client\Model\FileCreator
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->privateArticleUploadInitiate($article_id, $file, $page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleUploadInitiate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **file** | [**\OpenAPI\Client\Model\FileCreator**](../Model/FileCreator.md)|  | |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**\OpenAPI\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticlesList()`

```php
privateArticlesList($page, $page_size, $limit, $offset): \OpenAPI\Client\Model\Article[]
```

Private Articles

Get Own Articles

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->privateArticlesList($page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlesList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**\OpenAPI\Client\Model\Article[]**](../Model/Article.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateArticlesSearch()`

```php
privateArticlesSearch($search): \OpenAPI\Client\Model\ArticleWithProject[]
```

Private Articles search

Returns a list of private articles filtered by the search parameters

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$search = new \OpenAPI\Client\Model\PrivateArticleSearch(); // \OpenAPI\Client\Model\PrivateArticleSearch | Search Parameters

try {
    $result = $apiInstance->privateArticlesSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlesSearch: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**\OpenAPI\Client\Model\PrivateArticleSearch**](../Model/PrivateArticleSearch.md)| Search Parameters | |

### Return type

[**\OpenAPI\Client\Model\ArticleWithProject[]**](../Model/ArticleWithProject.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `publicArticleDownload()`

```php
publicArticleDownload($article_id, $folder_path)
```

Public Article Download

Download files from a public article preserving the folder structure

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 56; // int | Article unique identifier
$folder_path = 'folder_path_example'; // string | Folder path to download. If not provided, all files from the article will be downloaded

try {
    $apiInstance->publicArticleDownload($article_id, $folder_path);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->publicArticleDownload: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **folder_path** | **string**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `publicArticleVersionDownload()`

```php
publicArticleVersionDownload($article_id, $version_id, $folder_path)
```

Public Article Version Download

Download files from a certain version of an public article preserving the folder structure

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 56; // int | Article unique identifier
$version_id = 56; // int | Version Number
$folder_path = 'folder_path_example'; // string | Folder path to download. If not provided, all files from the article will be downloaded

try {
    $apiInstance->publicArticleVersionDownload($article_id, $version_id, $folder_path);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->publicArticleVersionDownload: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article unique identifier | |
| **version_id** | **int**| Version Number | |
| **folder_path** | **string**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
