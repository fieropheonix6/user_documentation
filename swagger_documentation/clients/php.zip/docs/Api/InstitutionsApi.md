# OpenAPI\Client\InstitutionsApi

All URIs are relative to http://localhost, except if the operation defines another base path.

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**accountInstitutionCuration()**](InstitutionsApi.md#accountInstitutionCuration) | **GET** /account/institution/review/{curation_id} | Institution Curation Review |
| [**accountInstitutionCurations()**](InstitutionsApi.md#accountInstitutionCurations) | **GET** /account/institution/reviews | Institution Curation Reviews |
| [**customFieldsList()**](InstitutionsApi.md#customFieldsList) | **GET** /account/institution/custom_fields | Private account institution group custom fields |
| [**customFieldsUpload()**](InstitutionsApi.md#customFieldsUpload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload |
| [**getAccountInstitutionCurationComments()**](InstitutionsApi.md#getAccountInstitutionCurationComments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments |
| [**institutionArticles()**](InstitutionsApi.md#institutionArticles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Institution Articles |
| [**institutionHrfeedUpload()**](InstitutionsApi.md#institutionHrfeedUpload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload |
| [**postAccountInstitutionCurationComments()**](InstitutionsApi.md#postAccountInstitutionCurationComments) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment |
| [**privateAccountInstitutionUser()**](InstitutionsApi.md#privateAccountInstitutionUser) | **GET** /account/institution/users/{account_id} | Private Account Institution User |
| [**privateCategoriesList()**](InstitutionsApi.md#privateCategoriesList) | **GET** /account/categories | Private Account Categories |
| [**privateGroupEmbargoOptionsDetails()**](InstitutionsApi.md#privateGroupEmbargoOptionsDetails) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options |
| [**privateInstitutionAccount()**](InstitutionsApi.md#privateInstitutionAccount) | **GET** /account/institution/accounts/{account_id} | Private Institution Account information |
| [**privateInstitutionAccountGroupRoleDelete()**](InstitutionsApi.md#privateInstitutionAccountGroupRoleDelete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role |
| [**privateInstitutionAccountGroupRoles()**](InstitutionsApi.md#privateInstitutionAccountGroupRoles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles |
| [**privateInstitutionAccountGroupRolesCreate()**](InstitutionsApi.md#privateInstitutionAccountGroupRolesCreate) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles |
| [**privateInstitutionAccountsCreate()**](InstitutionsApi.md#privateInstitutionAccountsCreate) | **POST** /account/institution/accounts | Create new Institution Account |
| [**privateInstitutionAccountsList()**](InstitutionsApi.md#privateInstitutionAccountsList) | **GET** /account/institution/accounts | Private Account Institution Accounts |
| [**privateInstitutionAccountsSearch()**](InstitutionsApi.md#privateInstitutionAccountsSearch) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search |
| [**privateInstitutionAccountsUpdate()**](InstitutionsApi.md#privateInstitutionAccountsUpdate) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account |
| [**privateInstitutionArticles()**](InstitutionsApi.md#privateInstitutionArticles) | **GET** /account/institution/articles | Private Institution Articles |
| [**privateInstitutionDetails()**](InstitutionsApi.md#privateInstitutionDetails) | **GET** /account/institution | Private Account Institutions |
| [**privateInstitutionEmbargoOptionsDetails()**](InstitutionsApi.md#privateInstitutionEmbargoOptionsDetails) | **GET** /account/institution/embargo_options | Private Account Institution embargo options |
| [**privateInstitutionGroupsList()**](InstitutionsApi.md#privateInstitutionGroupsList) | **GET** /account/institution/groups | Private Account Institution Groups |
| [**privateInstitutionRolesList()**](InstitutionsApi.md#privateInstitutionRolesList) | **GET** /account/institution/roles | Private Account Institution Roles |


## `accountInstitutionCuration()`

```php
accountInstitutionCuration($curation_id): \OpenAPI\Client\Model\CurationDetail
```

Institution Curation Review

Retrieve a certain curation review by its ID

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$curation_id = 56; // int | ID of the curation

try {
    $result = $apiInstance->accountInstitutionCuration($curation_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->accountInstitutionCuration: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **curation_id** | **int**| ID of the curation | |

### Return type

[**\OpenAPI\Client\Model\CurationDetail**](../Model/CurationDetail.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `accountInstitutionCurations()`

```php
accountInstitutionCurations($group_id, $article_id, $status, $limit, $offset): \OpenAPI\Client\Model\Curation
```

Institution Curation Reviews

Retrieve a list of curation reviews for this institution

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$group_id = 56; // int | Filter by the group ID
$article_id = 56; // int | Retrieve the reviews for this article
$status = 'status_example'; // string | Filter by the status of the review
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->accountInstitutionCurations($group_id, $article_id, $status, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->accountInstitutionCurations: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **group_id** | **int**| Filter by the group ID | [optional] |
| **article_id** | **int**| Retrieve the reviews for this article | [optional] |
| **status** | **string**| Filter by the status of the review | [optional] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**\OpenAPI\Client\Model\Curation**](../Model/Curation.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `customFieldsList()`

```php
customFieldsList($group_id): \OpenAPI\Client\Model\ShortCustomField[]
```

Private account institution group custom fields

Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$group_id = 56; // int | Group_id

try {
    $result = $apiInstance->customFieldsList($group_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->customFieldsList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **group_id** | **int**| Group_id | [optional] |

### Return type

[**\OpenAPI\Client\Model\ShortCustomField[]**](../Model/ShortCustomField.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `customFieldsUpload()`

```php
customFieldsUpload($custom_field_id, $external_file): object
```

Custom fields values files upload

Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. The <code>custom_field_id</code> path parameter accepts both classic custom field IDs (legacy) and underlying field IDs (v2). The lookup is performed automatically — no additional parameter is required. More details in the <a href=\"#custom_fields\">Custom Fields section</a>

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$custom_field_id = 56; // int | Identifier of the custom field or underlying field (v2) of type <b>dropdown_large_list</b>
$external_file = "/path/to/file.txt"; // \SplFileObject | CSV file to be uploaded

try {
    $result = $apiInstance->customFieldsUpload($custom_field_id, $external_file);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->customFieldsUpload: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **custom_field_id** | **int**| Identifier of the custom field or underlying field (v2) of type &lt;b&gt;dropdown_large_list&lt;/b&gt; | |
| **external_file** | **\SplFileObject****\SplFileObject**| CSV file to be uploaded | [optional] |

### Return type

**object**

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `multipart/form-data`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getAccountInstitutionCurationComments()`

```php
getAccountInstitutionCurationComments($curation_id, $limit, $offset): \OpenAPI\Client\Model\CurationComment
```

Institution Curation Review Comments

Retrieve a certain curation review's comments.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$curation_id = 56; // int | ID of the curation
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->getAccountInstitutionCurationComments($curation_id, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->getAccountInstitutionCurationComments: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **curation_id** | **int**| ID of the curation | |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**\OpenAPI\Client\Model\CurationComment**](../Model/CurationComment.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `institutionArticles()`

```php
institutionArticles($institution_string_id, $resource_id, $filename): \OpenAPI\Client\Model\Article[]
```

Public Institution Articles

Returns a list of articles belonging to the institution

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$institution_string_id = 'institution_string_id_example'; // string
$resource_id = 'resource_id_example'; // string
$filename = 'filename_example'; // string

try {
    $result = $apiInstance->institutionArticles($institution_string_id, $resource_id, $filename);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->institutionArticles: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **institution_string_id** | **string**|  | |
| **resource_id** | **string**|  | |
| **filename** | **string**|  | |

### Return type

[**\OpenAPI\Client\Model\Article[]**](../Model/Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `institutionHrfeedUpload()`

```php
institutionHrfeedUpload($hrfeed): \OpenAPI\Client\Model\ResponseMessage
```

Private Institution HRfeed Upload

More info in the <a href=\"#hr_feed\">HR Feed section</a>

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$hrfeed = "/path/to/file.txt"; // \SplFileObject | You can find an example in the Hr Feed section

try {
    $result = $apiInstance->institutionHrfeedUpload($hrfeed);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->institutionHrfeedUpload: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **hrfeed** | **\SplFileObject****\SplFileObject**| You can find an example in the Hr Feed section | [optional] |

### Return type

[**\OpenAPI\Client\Model\ResponseMessage**](../Model/ResponseMessage.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `multipart/form-data`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `postAccountInstitutionCurationComments()`

```php
postAccountInstitutionCurationComments($curation_id, $curation_comment)
```

POST Institution Curation Review Comment

Add a new comment to the review.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$curation_id = 56; // int | ID of the curation
$curation_comment = new \OpenAPI\Client\Model\CurationCommentCreate(); // \OpenAPI\Client\Model\CurationCommentCreate | The content/value of the comment.

try {
    $apiInstance->postAccountInstitutionCurationComments($curation_id, $curation_comment);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->postAccountInstitutionCurationComments: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **curation_id** | **int**| ID of the curation | |
| **curation_comment** | [**\OpenAPI\Client\Model\CurationCommentCreate**](../Model/CurationCommentCreate.md)| The content/value of the comment. | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateAccountInstitutionUser()`

```php
privateAccountInstitutionUser($account_id): \OpenAPI\Client\Model\User
```

Private Account Institution User

Retrieve institution user information using the account_id

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$account_id = 56; // int | Account identifier the user is associated to

try {
    $result = $apiInstance->privateAccountInstitutionUser($account_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateAccountInstitutionUser: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **account_id** | **int**| Account identifier the user is associated to | |

### Return type

[**\OpenAPI\Client\Model\User**](../Model/User.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCategoriesList()`

```php
privateCategoriesList(): \OpenAPI\Client\Model\CategoryList[]
```

Private Account Categories

List institution categories (including parent Categories)

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->privateCategoriesList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateCategoriesList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**\OpenAPI\Client\Model\CategoryList[]**](../Model/CategoryList.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateGroupEmbargoOptionsDetails()`

```php
privateGroupEmbargoOptionsDetails($group_id): \OpenAPI\Client\Model\GroupEmbargoOptions[]
```

Private Account Institution Group Embargo Options

Account institution group embargo options details

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$group_id = 56; // int | Group identifier

try {
    $result = $apiInstance->privateGroupEmbargoOptionsDetails($group_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateGroupEmbargoOptionsDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **group_id** | **int**| Group identifier | |

### Return type

[**\OpenAPI\Client\Model\GroupEmbargoOptions[]**](../Model/GroupEmbargoOptions.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionAccount()`

```php
privateInstitutionAccount($account_id): \OpenAPI\Client\Model\Account
```

Private Institution Account information

Private Institution Account information

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$account_id = 56; // int | Account identifier the user is associated to

try {
    $result = $apiInstance->privateInstitutionAccount($account_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccount: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **account_id** | **int**| Account identifier the user is associated to | |

### Return type

[**\OpenAPI\Client\Model\Account**](../Model/Account.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionAccountGroupRoleDelete()`

```php
privateInstitutionAccountGroupRoleDelete($account_id, $group_id, $role_id)
```

Delete Institution Account Group Role

Delete Institution Account Group Role

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$account_id = 56; // int | Account identifier for which to remove the role
$group_id = 56; // int | Group identifier for which to remove the role
$role_id = 56; // int | Role identifier

try {
    $apiInstance->privateInstitutionAccountGroupRoleDelete($account_id, $group_id, $role_id);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountGroupRoleDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **account_id** | **int**| Account identifier for which to remove the role | |
| **group_id** | **int**| Group identifier for which to remove the role | |
| **role_id** | **int**| Role identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionAccountGroupRoles()`

```php
privateInstitutionAccountGroupRoles($account_id): object
```

List Institution Account Group Roles

List Institution Account Group Roles

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$account_id = 56; // int | Account identifier the user is associated to

try {
    $result = $apiInstance->privateInstitutionAccountGroupRoles($account_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountGroupRoles: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **account_id** | **int**| Account identifier the user is associated to | |

### Return type

**object**

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionAccountGroupRolesCreate()`

```php
privateInstitutionAccountGroupRolesCreate($account_id, $account)
```

Add Institution Account Group Roles

Add Institution Account Group Roles

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$account_id = 56; // int | Account identifier the user is associated to
$account = array('key' => new \stdClass); // object | Account description

try {
    $apiInstance->privateInstitutionAccountGroupRolesCreate($account_id, $account);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountGroupRolesCreate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **account_id** | **int**| Account identifier the user is associated to | |
| **account** | **object**| Account description | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionAccountsCreate()`

```php
privateInstitutionAccountsCreate($account): \OpenAPI\Client\Model\AccountCreateResponse
```

Create new Institution Account

Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$account = new \OpenAPI\Client\Model\AccountCreate(); // \OpenAPI\Client\Model\AccountCreate | Account description

try {
    $result = $apiInstance->privateInstitutionAccountsCreate($account);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountsCreate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **account** | [**\OpenAPI\Client\Model\AccountCreate**](../Model/AccountCreate.md)| Account description | |

### Return type

[**\OpenAPI\Client\Model\AccountCreateResponse**](../Model/AccountCreateResponse.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionAccountsList()`

```php
privateInstitutionAccountsList($page, $page_size, $limit, $offset, $is_active, $institution_user_id, $email, $id_lte, $id_gte): \OpenAPI\Client\Model\ShortAccount[]
```

Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit
$is_active = 56; // int | Filter by active status
$institution_user_id = 'institution_user_id_example'; // string | Filter by institution_user_id
$email = 'email_example'; // string | Filter by email
$id_lte = 56; // int | Retrieve accounts with an ID lower or equal to the specified value
$id_gte = 56; // int | Retrieve accounts with an ID greater or equal to the specified value

try {
    $result = $apiInstance->privateInstitutionAccountsList($page, $page_size, $limit, $offset, $is_active, $institution_user_id, $email, $id_lte, $id_gte);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountsList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **is_active** | **int**| Filter by active status | [optional] |
| **institution_user_id** | **string**| Filter by institution_user_id | [optional] |
| **email** | **string**| Filter by email | [optional] |
| **id_lte** | **int**| Retrieve accounts with an ID lower or equal to the specified value | [optional] |
| **id_gte** | **int**| Retrieve accounts with an ID greater or equal to the specified value | [optional] |

### Return type

[**\OpenAPI\Client\Model\ShortAccount[]**](../Model/ShortAccount.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionAccountsSearch()`

```php
privateInstitutionAccountsSearch($search): \OpenAPI\Client\Model\ShortAccount[]
```

Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$search = new \OpenAPI\Client\Model\InstitutionAccountsSearch(); // \OpenAPI\Client\Model\InstitutionAccountsSearch | Search Parameters

try {
    $result = $apiInstance->privateInstitutionAccountsSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountsSearch: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**\OpenAPI\Client\Model\InstitutionAccountsSearch**](../Model/InstitutionAccountsSearch.md)| Search Parameters | |

### Return type

[**\OpenAPI\Client\Model\ShortAccount[]**](../Model/ShortAccount.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionAccountsUpdate()`

```php
privateInstitutionAccountsUpdate($account_id, $account)
```

Update Institution Account

Update Institution Account

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$account_id = 56; // int | Account identifier the user is associated to
$account = new \OpenAPI\Client\Model\AccountUpdate(); // \OpenAPI\Client\Model\AccountUpdate | Account description

try {
    $apiInstance->privateInstitutionAccountsUpdate($account_id, $account);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountsUpdate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **account_id** | **int**| Account identifier the user is associated to | |
| **account** | [**\OpenAPI\Client\Model\AccountUpdate**](../Model/AccountUpdate.md)| Account description | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionArticles()`

```php
privateInstitutionArticles($page, $page_size, $limit, $offset, $order, $order_direction, $published_since, $modified_since, $status, $resource_doi, $item_type, $group): \OpenAPI\Client\Model\Article[]
```

Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit
$order = 'published_date'; // string | The field by which to order. Default varies by endpoint/resource.
$order_direction = 'desc'; // string
$published_since = 'published_since_example'; // string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
$modified_since = 'modified_since_example'; // string | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
$status = 56; // int | only return collections with this status
$resource_doi = 'resource_doi_example'; // string | only return collections with this resource_doi
$item_type = 56; // int | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
$group = 56; // int | only return articles from this group

try {
    $result = $apiInstance->privateInstitutionArticles($page, $page_size, $limit, $offset, $order, $order_direction, $published_since, $modified_since, $status, $resource_doi, $item_type, $group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionArticles: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to &#39;published_date&#39;] |
| **order_direction** | **string**|  | [optional] [default to &#39;desc&#39;] |
| **published_since** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **modified_since** | **string**| Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **status** | **int**| only return collections with this status | [optional] |
| **resource_doi** | **string**| only return collections with this resource_doi | [optional] |
| **item_type** | **int**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] |
| **group** | **int**| only return articles from this group | [optional] |

### Return type

[**\OpenAPI\Client\Model\Article[]**](../Model/Article.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionDetails()`

```php
privateInstitutionDetails(): \OpenAPI\Client\Model\Institution
```

Private Account Institutions

Account institution details

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->privateInstitutionDetails();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**\OpenAPI\Client\Model\Institution**](../Model/Institution.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionEmbargoOptionsDetails()`

```php
privateInstitutionEmbargoOptionsDetails(): \OpenAPI\Client\Model\GroupEmbargoOptions[]
```

Private Account Institution embargo options

Account institution embargo options details

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->privateInstitutionEmbargoOptionsDetails();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionEmbargoOptionsDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**\OpenAPI\Client\Model\GroupEmbargoOptions[]**](../Model/GroupEmbargoOptions.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionGroupsList()`

```php
privateInstitutionGroupsList(): \OpenAPI\Client\Model\Group[]
```

Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->privateInstitutionGroupsList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionGroupsList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**\OpenAPI\Client\Model\Group[]**](../Model/Group.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateInstitutionRolesList()`

```php
privateInstitutionRolesList(): \OpenAPI\Client\Model\Role[]
```

Private Account Institution Roles

Returns the roles available for groups and the institution group.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\InstitutionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->privateInstitutionRolesList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionRolesList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**\OpenAPI\Client\Model\Role[]**](../Model/Role.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
