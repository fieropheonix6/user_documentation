# FigshareApi.CreateOAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientId** | **String** |  | 
**clientSecret** | **String** |  | 
**grantType** | **String** |  | 
**code** | **String** | Required if grant_type is 'authorization_code' | [optional] 
**refreshToken** | **String** | Required if grant_type is 'refresh_token' | [optional] 
**username** | **String** | Required if grant_type is 'password' | [optional] 
**password** | **String** | Required if grant_type is 'password' | [optional] 


<a name="GrantTypeEnum"></a>
## Enum: GrantTypeEnum


* `authorizationCode` (value: `"authorization_code"`)

* `refreshToken` (value: `"refresh_token"`)

* `password` (value: `"password"`)

* `clientCredentials` (value: `"client_credentials"`)




