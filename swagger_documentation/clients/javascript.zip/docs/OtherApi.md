# FigshareApi.OtherApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categoriesList**](OtherApi.md#categoriesList) | **GET** /categories | Public Categories
[**fileDownload**](OtherApi.md#fileDownload) | **GET** /file/download/{file_id} | Public File Download
[**itemTypesList**](OtherApi.md#itemTypesList) | **GET** /item_types | Item Types
[**licensesList**](OtherApi.md#licensesList) | **GET** /licenses | Public Licenses
[**privateAccount**](OtherApi.md#privateAccount) | **GET** /account | Private Account information
[**privateFundingSearch**](OtherApi.md#privateFundingSearch) | **POST** /account/funding/search | Search Funding
[**privateLicensesList**](OtherApi.md#privateLicensesList) | **GET** /account/licenses | Private Account Licenses


<a name="categoriesList"></a>
# **categoriesList**
> [CategoryList] categoriesList()

Public Categories

Returns a list of public categories

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.OtherApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.categoriesList(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[CategoryList]**](CategoryList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="fileDownload"></a>
# **fileDownload**
> fileDownload(fileId)

Public File Download

Starts the download of a file

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.OtherApi();

var fileId = 789; // Number | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.fileDownload(fileId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **fileId** | **Number**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/force-download

<a name="itemTypesList"></a>
# **itemTypesList**
> [ItemType] itemTypesList(opts)

Item Types

Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.OtherApi();

var opts = { 
  'groupId': 0 // Number | Identifier of the group for which the item types are requested
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.itemTypesList(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **Number**| Identifier of the group for which the item types are requested | [optional] [default to 0]

### Return type

[**[ItemType]**](ItemType.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="licensesList"></a>
# **licensesList**
> [License] licensesList()

Public Licenses

Returns a list of public licenses

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.OtherApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.licensesList(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[License]**](License.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateAccount"></a>
# **privateAccount**
> Account privateAccount()

Private Account information

Account information for token/personal token

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.OtherApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateAccount(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateFundingSearch"></a>
# **privateFundingSearch**
> [FundingInformation] privateFundingSearch(opts)

Search Funding

Search for fundings

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.OtherApi();

var opts = { 
  'search': new FigshareApi.FundingSearch() // FundingSearch | Search Parameters
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateFundingSearch(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**FundingSearch**](FundingSearch.md)| Search Parameters | [optional] 

### Return type

[**[FundingInformation]**](FundingInformation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateLicensesList"></a>
# **privateLicensesList**
> [License] privateLicensesList()

Private Account Licenses

This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.OtherApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateLicensesList(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[License]**](License.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

