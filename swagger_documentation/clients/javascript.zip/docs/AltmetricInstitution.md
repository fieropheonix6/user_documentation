# FigshareApi.AltmetricInstitution

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Institution id | 
**name** | **String** | Institution name | 
**customDomain** | **String** | Custom domain for the institution | [optional] 


