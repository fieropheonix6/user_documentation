# FigshareApi.AccountGroupRolesCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


