# FigshareApi.ProjectCollaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | Status of collaborator invitation | 
**roleName** | **String** | Collaborator role | 
**userId** | **Number** | Collaborator id | 
**name** | **String** | Collaborator name | 


