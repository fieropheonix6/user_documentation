# FigshareApi.CustomArticleField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Custom  metadata name | 
**value** | **Object** | Custom metadata value (can be either a string or an array of strings) | 
**fieldType** | **String** | Custom field type | 
**settings** | **Object** | Settings for the custom field | 
**order** | **Number** | Order of the custom field | 
**isMandatory** | **Boolean** | Whether the field is mandatory or not | 


<a name="FieldTypeEnum"></a>
## Enum: FieldTypeEnum


* `text` (value: `"text"`)

* `textarea` (value: `"textarea"`)

* `dropdown` (value: `"dropdown"`)

* `url` (value: `"url"`)

* `email` (value: `"email"`)

* `_date` (value: `"date"`)

* `dropdownLargeList` (value: `"dropdown_large_list"`)




