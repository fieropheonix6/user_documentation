# FigshareApi.PrivateLinkResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **String** | Url for private link | 
**htmlLocation** | **String** | HTML url for private link | 
**token** | **String** | Token for private link | 


