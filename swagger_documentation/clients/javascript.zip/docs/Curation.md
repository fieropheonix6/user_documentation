# FigshareApi.Curation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | The review id | 
**groupId** | **Number** | The group in which the article is present. | 
**accountId** | **Number** | The ID of the account of the owner of the article of this review. | 
**assignedTo** | **Number** | The ID of the account to which this review is assigned. | 
**articleId** | **Number** | The ID of the article of this review. | 
**version** | **Number** | The Version number of the article in review. | 
**commentsCount** | **Number** | The number of comments in the review. | 
**status** | **String** | The status of the review. | 
**createdDate** | **String** | The creation date of the review. | 
**modifiedDate** | **String** | The date the review has been modified. | 
**requestNumber** | **Number** | The request number of the review. | 
**resolutionComment** | **String** | The resolution comment of the review. | 


<a name="StatusEnum"></a>
## Enum: StatusEnum


* `pending` (value: `"pending"`)

* `approved` (value: `"approved"`)

* `rejected` (value: `"rejected"`)

* `closed` (value: `"closed"`)




