# FigshareApi.ProjectNotePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** | Full text of note | 


