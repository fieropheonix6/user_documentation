# FigshareApi.ProjectNotePrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** | Full text of note | 
**id** | **Number** | Project note id | 
**userId** | **Number** | User who wrote the note | 
**_abstract** | **String** | Note Abstract - short/truncated content | 
**userName** | **String** | Username of the one who wrote the note | 
**createdDate** | **String** | Date when note was created | 
**modifiedDate** | **String** | Date when note was last modified | 


