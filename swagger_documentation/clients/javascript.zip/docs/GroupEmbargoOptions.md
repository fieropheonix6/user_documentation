# FigshareApi.GroupEmbargoOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Embargo option id | 
**type** | **String** | Embargo permission type | 
**ipName** | **String** | IP range name; value appears if type is ip_range | 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `loggedIn` (value: `"logged_in"`)

* `ipRange` (value: `"ip_range"`)

* `administrator` (value: `"administrator"`)




