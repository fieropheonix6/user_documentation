# FigshareApi.OauthApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createToken**](OauthApi.md#createToken) | **POST** /token | Create OAuth token
[**getTokenInfo**](OauthApi.md#getTokenInfo) | **GET** /token | Get OAuth token information


<a name="createToken"></a>
# **createToken**
> OAuthToken createToken(opts)

Create OAuth token

Creates OAuth token using various grant types

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.OauthApi();

var opts = { 
  'body': new FigshareApi.CreateOAuthToken() // CreateOAuthToken | Create OAuth Token Parameters
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.createToken(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateOAuthToken**](CreateOAuthToken.md)| Create OAuth Token Parameters | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getTokenInfo"></a>
# **getTokenInfo**
> OAuthToken getTokenInfo(opts)

Get OAuth token information

Returns information about the current OAuth token

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.OauthApi();

var opts = { 
  'accessToken': "accessToken_example" // String | OAuth access token
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.getTokenInfo(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accessToken** | **String**| OAuth access token | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

