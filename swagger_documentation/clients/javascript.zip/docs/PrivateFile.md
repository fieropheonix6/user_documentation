# FigshareApi.PrivateFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**viewerType** | **String** | File viewer type | 
**previewState** | **String** | File preview state | 
**uploadUrl** | **String** | Upload url for file | 
**uploadToken** | **String** | Token for file upload | 
**isAttachedToPublicVersion** | **Boolean** | True if the file is attached to a public item version | 


