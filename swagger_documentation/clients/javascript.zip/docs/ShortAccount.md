# FigshareApi.ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Account id | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**institutionId** | **Number** | Account institution | 
**email** | **String** | User email | 
**active** | **Number** | Account activity status | 
**institutionUserId** | **String** | Account institution user id | 
**quota** | **Number** | Total storage available to account, in bytes | 
**usedQuota** | **Number** | Storage used by the account, in bytes | 
**userId** | **Number** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcidId** | **String** | ORCID iD associated to account | 


