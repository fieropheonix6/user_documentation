# FigshareApi.ArticlesApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**accountArticlePublish**](ArticlesApi.md#accountArticlePublish) | **POST** /account/articles/{article_id}/publish | Private Article Publish
[**accountArticleReport**](ArticlesApi.md#accountArticleReport) | **GET** /account/articles/export | Account Article Report
[**accountArticleReportGenerate**](ArticlesApi.md#accountArticleReportGenerate) | **POST** /account/articles/export | Initiate a new Report
[**accountArticleUnpublish**](ArticlesApi.md#accountArticleUnpublish) | **POST** /account/articles/{article_id}/unpublish | Public Article Unpublish
[**articleDetails**](ArticlesApi.md#articleDetails) | **GET** /articles/{article_id} | View article details
[**articleFileDetails**](ArticlesApi.md#articleFileDetails) | **GET** /articles/{article_id}/files/{file_id} | Article file details
[**articleFiles**](ArticlesApi.md#articleFiles) | **GET** /articles/{article_id}/files | List article files
[**articleVersionConfidentiality**](ArticlesApi.md#articleVersionConfidentiality) | **GET** /articles/{article_id}/versions/{version_id}/confidentiality | Public Article Confidentiality for article version
[**articleVersionDetails**](ArticlesApi.md#articleVersionDetails) | **GET** /articles/{article_id}/versions/{version_id} | Article details for version
[**articleVersionEmbargo**](ArticlesApi.md#articleVersionEmbargo) | **GET** /articles/{article_id}/versions/{version_id}/embargo | Public Article Embargo for article version
[**articleVersionFiles**](ArticlesApi.md#articleVersionFiles) | **GET** /articles/{article_id}/versions/{version_id}/files | Article version file details
[**articleVersionPartialUpdate**](ArticlesApi.md#articleVersionPartialUpdate) | **PATCH** /account/articles/{article_id}/versions/{version_id} | Partially update article version
[**articleVersionUpdate**](ArticlesApi.md#articleVersionUpdate) | **PUT** /account/articles/{article_id}/versions/{version_id} | Update article version
[**articleVersionUpdateThumb**](ArticlesApi.md#articleVersionUpdateThumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail
[**articleVersions**](ArticlesApi.md#articleVersions) | **GET** /articles/{article_id}/versions | List article versions
[**articlesList**](ArticlesApi.md#articlesList) | **GET** /articles | Public Articles
[**articlesSearch**](ArticlesApi.md#articlesSearch) | **POST** /articles/search | Public Articles Search
[**privateArticleAuthorDelete**](ArticlesApi.md#privateArticleAuthorDelete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author
[**privateArticleAuthorsAdd**](ArticlesApi.md#privateArticleAuthorsAdd) | **POST** /account/articles/{article_id}/authors | Add article authors
[**privateArticleAuthorsList**](ArticlesApi.md#privateArticleAuthorsList) | **GET** /account/articles/{article_id}/authors | List article authors
[**privateArticleAuthorsReplace**](ArticlesApi.md#privateArticleAuthorsReplace) | **PUT** /account/articles/{article_id}/authors | Replace article authors
[**privateArticleCategoriesAdd**](ArticlesApi.md#privateArticleCategoriesAdd) | **POST** /account/articles/{article_id}/categories | Add article categories
[**privateArticleCategoriesList**](ArticlesApi.md#privateArticleCategoriesList) | **GET** /account/articles/{article_id}/categories | List article categories
[**privateArticleCategoriesReplace**](ArticlesApi.md#privateArticleCategoriesReplace) | **PUT** /account/articles/{article_id}/categories | Replace article categories
[**privateArticleCategoryDelete**](ArticlesApi.md#privateArticleCategoryDelete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category
[**privateArticleConfidentialityDelete**](ArticlesApi.md#privateArticleConfidentialityDelete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality
[**privateArticleConfidentialityDetails**](ArticlesApi.md#privateArticleConfidentialityDetails) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details
[**privateArticleConfidentialityUpdate**](ArticlesApi.md#privateArticleConfidentialityUpdate) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality
[**privateArticleCreate**](ArticlesApi.md#privateArticleCreate) | **POST** /account/articles | Create new Article
[**privateArticleDelete**](ArticlesApi.md#privateArticleDelete) | **DELETE** /account/articles/{article_id} | Delete article
[**privateArticleDetails**](ArticlesApi.md#privateArticleDetails) | **GET** /account/articles/{article_id} | Article details
[**privateArticleDownload**](ArticlesApi.md#privateArticleDownload) | **GET** /account/articles/{article_id}/download | Private Article Download
[**privateArticleEmbargoDelete**](ArticlesApi.md#privateArticleEmbargoDelete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo
[**privateArticleEmbargoDetails**](ArticlesApi.md#privateArticleEmbargoDetails) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details
[**privateArticleEmbargoUpdate**](ArticlesApi.md#privateArticleEmbargoUpdate) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo
[**privateArticleFile**](ArticlesApi.md#privateArticleFile) | **GET** /account/articles/{article_id}/files/{file_id} | Single File
[**privateArticleFileDelete**](ArticlesApi.md#privateArticleFileDelete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete
[**privateArticleFilesList**](ArticlesApi.md#privateArticleFilesList) | **GET** /account/articles/{article_id}/files | List article files
[**privateArticlePartialUpdate**](ArticlesApi.md#privateArticlePartialUpdate) | **PATCH** /account/articles/{article_id} | Partially update article
[**privateArticlePrivateLink**](ArticlesApi.md#privateArticlePrivateLink) | **GET** /account/articles/{article_id}/private_links | List private links
[**privateArticlePrivateLinkCreate**](ArticlesApi.md#privateArticlePrivateLinkCreate) | **POST** /account/articles/{article_id}/private_links | Create private link
[**privateArticlePrivateLinkDelete**](ArticlesApi.md#privateArticlePrivateLinkDelete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link
[**privateArticlePrivateLinkUpdate**](ArticlesApi.md#privateArticlePrivateLinkUpdate) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link
[**privateArticleReserveDoi**](ArticlesApi.md#privateArticleReserveDoi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI
[**privateArticleReserveHandle**](ArticlesApi.md#privateArticleReserveHandle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle
[**privateArticleResource**](ArticlesApi.md#privateArticleResource) | **POST** /account/articles/{article_id}/resource | Private Article Resource
[**privateArticleUpdate**](ArticlesApi.md#privateArticleUpdate) | **PUT** /account/articles/{article_id} | Update article
[**privateArticleUploadComplete**](ArticlesApi.md#privateArticleUploadComplete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload
[**privateArticleUploadInitiate**](ArticlesApi.md#privateArticleUploadInitiate) | **POST** /account/articles/{article_id}/files | Initiate Upload
[**privateArticlesList**](ArticlesApi.md#privateArticlesList) | **GET** /account/articles | Private Articles
[**privateArticlesSearch**](ArticlesApi.md#privateArticlesSearch) | **POST** /account/articles/search | Private Articles search
[**publicArticleDownload**](ArticlesApi.md#publicArticleDownload) | **GET** /articles/{article_id}/download | Public Article Download
[**publicArticleVersionDownload**](ArticlesApi.md#publicArticleVersionDownload) | **GET** /articles/{article_id}/versions/{version_id}/download | Public Article Version Download


<a name="accountArticlePublish"></a>
# **accountArticlePublish**
> Location accountArticlePublish(articleId)

Private Article Publish

- If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.accountArticlePublish(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="accountArticleReport"></a>
# **accountArticleReport**
> [AccountReport] accountArticleReport(opts)

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var opts = { 
  'groupId': 789 // Number | A group ID to filter by
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.accountArticleReport(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **Number**| A group ID to filter by | [optional] 

### Return type

[**[AccountReport]**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="accountArticleReportGenerate"></a>
# **accountArticleReportGenerate**
> AccountReport accountArticleReportGenerate()

Initiate a new Report

Initiate a new Article Report for this Account. There is a limit of 1 report per day.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.accountArticleReportGenerate(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="accountArticleUnpublish"></a>
# **accountArticleUnpublish**
> accountArticleUnpublish(articleId, reason)

Public Article Unpublish

Allows authorized users to unpublish an article.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var reason = new FigshareApi.ArticleUnpublishData(); // ArticleUnpublishData | Article unpublish data


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.accountArticleUnpublish(articleId, reason, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **reason** | [**ArticleUnpublishData**](ArticleUnpublishData.md)| Article unpublish data | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleDetails"></a>
# **articleDetails**
> ArticleComplete articleDetails(articleId)

View article details

View an article

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article Unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articleDetails(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article Unique identifier | 

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleFileDetails"></a>
# **articleFileDetails**
> PublicFile articleFileDetails(articleId, fileId)

Article file details

File by id

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article Unique identifier

var fileId = 789; // Number | File Unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articleFileDetails(articleId, fileId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article Unique identifier | 
 **fileId** | **Number**| File Unique identifier | 

### Return type

[**PublicFile**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleFiles"></a>
# **articleFiles**
> [PublicFile] articleFiles(articleId, opts)

List article files

Files list for article

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article Unique identifier

var opts = { 
  'page': 789, // Number | Page number. Used for pagination with page_size
  'pageSize': 10, // Number | The number of results included on a page. Used for pagination with page
  'limit': 789, // Number | Number of results included on a page. Used for pagination with query
  'offset': 789 // Number | Where to start the listing (the offset of the first result). Used for pagination with limit
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articleFiles(articleId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article Unique identifier | 
 **page** | **Number**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Number**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Number**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Number**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[PublicFile]**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleVersionConfidentiality"></a>
# **articleVersionConfidentiality**
> ArticleConfidentiality articleVersionConfidentiality(articleId, versionId)

Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article Unique identifier

var versionId = 789; // Number | Version Number


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articleVersionConfidentiality(articleId, versionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article Unique identifier | 
 **versionId** | **Number**| Version Number | 

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleVersionDetails"></a>
# **articleVersionDetails**
> ArticleComplete articleVersionDetails(articleId, versionId)

Article details for version

Article with specified version

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article Unique identifier

var versionId = 789; // Number | Article Version Number


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articleVersionDetails(articleId, versionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article Unique identifier | 
 **versionId** | **Number**| Article Version Number | 

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleVersionEmbargo"></a>
# **articleVersionEmbargo**
> ArticleEmbargo articleVersionEmbargo(articleId, versionId)

Public Article Embargo for article version

Embargo for article version

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article Unique identifier

var versionId = 789; // Number | Version Number


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articleVersionEmbargo(articleId, versionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article Unique identifier | 
 **versionId** | **Number**| Version Number | 

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleVersionFiles"></a>
# **articleVersionFiles**
> [PublicFile] articleVersionFiles(articleId, versionId, opts)

Article version file details

File by version id

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article Unique identifier

var versionId = 789; // Number | Article Version Unique identifier

var opts = { 
  'page': 789, // Number | Page number. Used for pagination with page_size
  'pageSize': 10, // Number | The number of results included on a page. Used for pagination with page
  'limit': 789, // Number | Number of results included on a page. Used for pagination with query
  'offset': 789 // Number | Where to start the listing (the offset of the first result). Used for pagination with limit
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articleVersionFiles(articleId, versionId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article Unique identifier | 
 **versionId** | **Number**| Article Version Unique identifier | 
 **page** | **Number**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Number**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Number**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Number**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[PublicFile]**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleVersionPartialUpdate"></a>
# **articleVersionPartialUpdate**
> LocationWarningsUpdate articleVersionPartialUpdate(articleId, versionId, article)

Partially update article version

Partially updating an article version by passing only the fields to change.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var versionId = 789; // Number | Article version identifier

var article = new FigshareApi.ArticleVersionUpdate(); // ArticleVersionUpdate | Subset of article version fields to update


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articleVersionPartialUpdate(articleId, versionId, article, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **versionId** | **Number**| Article version identifier | 
 **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md)| Subset of article version fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleVersionUpdate"></a>
# **articleVersionUpdate**
> LocationWarningsUpdate articleVersionUpdate(articleId, versionId, article)

Update article version

Updating an article version by passing body parameters.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var versionId = 789; // Number | Article version identifier

var article = new FigshareApi.ArticleVersionUpdate(); // ArticleVersionUpdate | Article description


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articleVersionUpdate(articleId, versionId, article, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **versionId** | **Number**| Article version identifier | 
 **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md)| Article description | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleVersionUpdateThumb"></a>
# **articleVersionUpdateThumb**
> articleVersionUpdateThumb(articleId, versionId, fileId)

Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var versionId = 789; // Number | Article version identifier

var fileId = new FigshareApi.FileId(); // FileId | File ID


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.articleVersionUpdateThumb(articleId, versionId, fileId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **versionId** | **Number**| Article version identifier | 
 **fileId** | [**FileId**](FileId.md)| File ID | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articleVersions"></a>
# **articleVersions**
> [ArticleVersions] articleVersions(articleId)

List article versions

List public article versions

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article Unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articleVersions(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article Unique identifier | 

### Return type

[**[ArticleVersions]**](ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articlesList"></a>
# **articlesList**
> [Article] articlesList(opts)

Public Articles

Returns a list of public articles

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var opts = { 
  'xCursor': "xCursor_example", // String | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
  'page': 789, // Number | Page number. Used for pagination with page_size
  'pageSize': 10, // Number | The number of results included on a page. Used for pagination with page
  'limit': 789, // Number | Number of results included on a page. Used for pagination with query
  'offset': 789, // Number | Where to start the listing (the offset of the first result). Used for pagination with limit
  'order': "published_date", // String | The field by which to order. Default varies by endpoint/resource.
  'orderDirection': "desc", // String | 
  'institution': 789, // Number | only return articles from this institution
  'publishedSince': "publishedSince_example", // String | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
  'modifiedSince': "modifiedSince_example", // String | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
  'group': 789, // Number | only return articles from this group
  'resourceDoi': "resourceDoi_example", // String | Deprecated by related materials. Only return articles with this resource_doi
  'itemType': 789, // Number | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
  'doi': "doi_example", // String | only return articles with this doi
  'handle': "handle_example" // String | only return articles with this handle
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articlesList(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | [**String**](.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **page** | **Number**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Number**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Number**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Number**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **String**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **orderDirection** | **String**|  | [optional] [default to desc]
 **institution** | **Number**| only return articles from this institution | [optional] 
 **publishedSince** | **String**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **modifiedSince** | **String**| Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **group** | **Number**| only return articles from this group | [optional] 
 **resourceDoi** | **String**| Deprecated by related materials. Only return articles with this resource_doi | [optional] 
 **itemType** | **Number**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
 **doi** | **String**| only return articles with this doi | [optional] 
 **handle** | **String**| only return articles with this handle | [optional] 

### Return type

[**[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="articlesSearch"></a>
# **articlesSearch**
> [ArticleWithProject] articlesSearch(opts)

Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var opts = { 
  'xCursor': "xCursor_example", // String | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
  'search': new FigshareApi.ArticleSearch() // ArticleSearch | Search Parameters
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.articlesSearch(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | [**String**](.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **search** | [**ArticleSearch**](ArticleSearch.md)| Search Parameters | [optional] 

### Return type

[**[ArticleWithProject]**](ArticleWithProject.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleAuthorDelete"></a>
# **privateArticleAuthorDelete**
> privateArticleAuthorDelete(articleId, authorId)

Delete article author

De-associate author from article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var authorId = 789; // Number | Article Author unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleAuthorDelete(articleId, authorId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **authorId** | **Number**| Article Author unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleAuthorsAdd"></a>
# **privateArticleAuthorsAdd**
> privateArticleAuthorsAdd(articleId, authors)

Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var authors = new FigshareApi.AuthorsCreator(); // AuthorsCreator | Authors description


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleAuthorsAdd(articleId, authors, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| Authors description | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleAuthorsList"></a>
# **privateArticleAuthorsList**
> [Author] privateArticleAuthorsList(articleId, )

List article authors

List article authors

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleAuthorsList(articleId, , callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

[**[Author]**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleAuthorsReplace"></a>
# **privateArticleAuthorsReplace**
> privateArticleAuthorsReplace(articleId, authors)

Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var authors = new FigshareApi.AuthorsCreator(); // AuthorsCreator | Authors description


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleAuthorsReplace(articleId, authors, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| Authors description | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleCategoriesAdd"></a>
# **privateArticleCategoriesAdd**
> privateArticleCategoriesAdd(articleId, categories)

Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var categories = new FigshareApi.CategoriesCreator(); // CategoriesCreator | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleCategoriesAdd(articleId, categories, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)|  | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleCategoriesList"></a>
# **privateArticleCategoriesList**
> [Category] privateArticleCategoriesList(articleId, )

List article categories

List article categories

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleCategoriesList(articleId, , callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

[**[Category]**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleCategoriesReplace"></a>
# **privateArticleCategoriesReplace**
> privateArticleCategoriesReplace(articleId, categories)

Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var categories = new FigshareApi.CategoriesCreator(); // CategoriesCreator | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleCategoriesReplace(articleId, categories, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)|  | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleCategoryDelete"></a>
# **privateArticleCategoryDelete**
> privateArticleCategoryDelete(articleId, categoryId)

Delete article category

De-associate category from article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var categoryId = 789; // Number | Category unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleCategoryDelete(articleId, categoryId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **categoryId** | **Number**| Category unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleConfidentialityDelete"></a>
# **privateArticleConfidentialityDelete**
> privateArticleConfidentialityDelete(articleId)

Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleConfidentialityDelete(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleConfidentialityDetails"></a>
# **privateArticleConfidentialityDetails**
> ArticleConfidentiality privateArticleConfidentialityDetails(articleId)

Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleConfidentialityDetails(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleConfidentialityUpdate"></a>
# **privateArticleConfidentialityUpdate**
> privateArticleConfidentialityUpdate(articleIdreason)

Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var reason = new FigshareApi.ConfidentialityCreator(); // ConfidentialityCreator | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleConfidentialityUpdate(articleIdreason, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **reason** | [**ConfidentialityCreator**](ConfidentialityCreator.md)|  | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleCreate"></a>
# **privateArticleCreate**
> LocationWarnings privateArticleCreate(article)

Create new Article

Create a new Article by sending article information

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var article = new FigshareApi.ArticleCreate(); // ArticleCreate | Article description


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleCreate(article, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article** | [**ArticleCreate**](ArticleCreate.md)| Article description | 

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleDelete"></a>
# **privateArticleDelete**
> privateArticleDelete(articleId, )

Delete article

Delete an article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleDelete(articleId, , callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleDetails"></a>
# **privateArticleDetails**
> ArticleCompletePrivate privateArticleDetails(articleId, )

Article details

View a private article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleDetails(articleId, , callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleDownload"></a>
# **privateArticleDownload**
> privateArticleDownload(articleId, opts)

Private Article Download

Download files from a private article preserving the folder structure

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var opts = { 
  'folderPath': "folderPath_example" // String | Folder path to download. If not provided, all files from the article will be downloaded
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleDownload(articleId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **folderPath** | **String**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleEmbargoDelete"></a>
# **privateArticleEmbargoDelete**
> privateArticleEmbargoDelete(articleId)

Delete Article Embargo

Will lift the embargo for the specified article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleEmbargoDelete(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleEmbargoDetails"></a>
# **privateArticleEmbargoDetails**
> ArticleEmbargo privateArticleEmbargoDetails(articleId)

Article Embargo Details

View a private article embargo details

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleEmbargoDetails(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleEmbargoUpdate"></a>
# **privateArticleEmbargoUpdate**
> privateArticleEmbargoUpdate(articleIdembargo)

Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var embargo = new FigshareApi.ArticleEmbargoUpdater(); // ArticleEmbargoUpdater | Embargo description


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleEmbargoUpdate(articleIdembargo, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **embargo** | [**ArticleEmbargoUpdater**](ArticleEmbargoUpdater.md)| Embargo description | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleFile"></a>
# **privateArticleFile**
> PrivateFile privateArticleFile(articleId, fileId)

Single File

View details of file for specified article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var fileId = 789; // Number | File unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleFile(articleId, fileId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **fileId** | **Number**| File unique identifier | 

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleFileDelete"></a>
# **privateArticleFileDelete**
> privateArticleFileDelete(articleId, fileId)

File Delete

Complete file upload

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var fileId = 789; // Number | File unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleFileDelete(articleId, fileId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **fileId** | **Number**| File unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleFilesList"></a>
# **privateArticleFilesList**
> [PrivateFile] privateArticleFilesList(articleId, , opts)

List article files

List private files

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var opts = { 
  'page': 789, // Number | Page number. Used for pagination with page_size
  'pageSize': 10, // Number | The number of results included on a page. Used for pagination with page
  'limit': 789, // Number | Number of results included on a page. Used for pagination with query
  'offset': 789 // Number | Where to start the listing (the offset of the first result). Used for pagination with limit
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleFilesList(articleId, , opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **page** | **Number**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Number**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Number**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Number**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[PrivateFile]**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticlePartialUpdate"></a>
# **privateArticlePartialUpdate**
> LocationWarningsUpdate privateArticlePartialUpdate(articleId, article)

Partially update article

Partially update an article by sending only the fields to change.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var article = new FigshareApi.ArticleUpdate(); // ArticleUpdate | Subset of article fields to update


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticlePartialUpdate(articleId, article, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **article** | [**ArticleUpdate**](ArticleUpdate.md)| Subset of article fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticlePrivateLink"></a>
# **privateArticlePrivateLink**
> [PrivateLink] privateArticlePrivateLink(articleId)

List private links

List private links

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticlePrivateLink(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

[**[PrivateLink]**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticlePrivateLinkCreate"></a>
# **privateArticlePrivateLinkCreate**
> PrivateLinkResponse privateArticlePrivateLinkCreate(articleId, opts)

Create private link

Create new private link for this article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var opts = { 
  'privateLink': new FigshareApi.PrivateLinkCreator() // PrivateLinkCreator | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticlePrivateLinkCreate(articleId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **privateLink** | [**PrivateLinkCreator**](PrivateLinkCreator.md)|  | [optional] 

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticlePrivateLinkDelete"></a>
# **privateArticlePrivateLinkDelete**
> privateArticlePrivateLinkDelete(articleId, linkId)

Disable private link

Disable/delete private link for this article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var linkId = "linkId_example"; // String | Private link token


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticlePrivateLinkDelete(articleId, linkId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **linkId** | **String**| Private link token | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticlePrivateLinkUpdate"></a>
# **privateArticlePrivateLinkUpdate**
> privateArticlePrivateLinkUpdate(articleId, linkId, opts)

Update private link

Update existing private link for this article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var linkId = "linkId_example"; // String | Private link token

var opts = { 
  'privateLink': new FigshareApi.PrivateLinkCreator() // PrivateLinkCreator | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticlePrivateLinkUpdate(articleId, linkId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **linkId** | **String**| Private link token | 
 **privateLink** | [**PrivateLinkCreator**](PrivateLinkCreator.md)|  | [optional] 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleReserveDoi"></a>
# **privateArticleReserveDoi**
> ArticleDOI privateArticleReserveDoi(articleId)

Private Article Reserve DOI

Reserve DOI for article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleReserveDoi(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

[**ArticleDOI**](ArticleDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleReserveHandle"></a>
# **privateArticleReserveHandle**
> ArticleHandle privateArticleReserveHandle(articleId)

Private Article Reserve Handle

Reserve Handle for article

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleReserveHandle(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 

### Return type

[**ArticleHandle**](ArticleHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleResource"></a>
# **privateArticleResource**
> Location privateArticleResource(articleId, resource)

Private Article Resource

Edit article resource data.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var resource = new FigshareApi.Resource(); // Resource | Resource data


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleResource(articleId, resource, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **resource** | [**Resource**](Resource.md)| Resource data | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleUpdate"></a>
# **privateArticleUpdate**
> LocationWarningsUpdate privateArticleUpdate(articleId, article)

Update article

Update an article by passing full body parameters.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var article = new FigshareApi.ArticleUpdate(); // ArticleUpdate | Full article representation


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleUpdate(articleId, article, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **article** | [**ArticleUpdate**](ArticleUpdate.md)| Full article representation | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleUploadComplete"></a>
# **privateArticleUploadComplete**
> privateArticleUploadComplete(articleId, fileId)

Complete Upload

Complete file upload

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var fileId = 789; // Number | File unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateArticleUploadComplete(articleId, fileId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **fileId** | **Number**| File unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticleUploadInitiate"></a>
# **privateArticleUploadInitiate**
> Location privateArticleUploadInitiate(articleId, file, opts)

Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var file = new FigshareApi.FileCreator(); // FileCreator | 

var opts = { 
  'page': 789, // Number | Page number. Used for pagination with page_size
  'pageSize': 10, // Number | The number of results included on a page. Used for pagination with page
  'limit': 789, // Number | Number of results included on a page. Used for pagination with query
  'offset': 789 // Number | Where to start the listing (the offset of the first result). Used for pagination with limit
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticleUploadInitiate(articleId, file, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **file** | [**FileCreator**](FileCreator.md)|  | 
 **page** | **Number**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Number**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Number**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Number**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticlesList"></a>
# **privateArticlesList**
> [Article] privateArticlesList(opts)

Private Articles

Get Own Articles

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var opts = { 
  'page': 789, // Number | Page number. Used for pagination with page_size
  'pageSize': 10, // Number | The number of results included on a page. Used for pagination with page
  'limit': 789, // Number | Number of results included on a page. Used for pagination with query
  'offset': 789 // Number | Where to start the listing (the offset of the first result). Used for pagination with limit
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticlesList(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **Number**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Number**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Number**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Number**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateArticlesSearch"></a>
# **privateArticlesSearch**
> [ArticleWithProject] privateArticlesSearch(search)

Private Articles search

Returns a list of private articles filtered by the search parameters

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ArticlesApi();

var search = new FigshareApi.PrivateArticleSearch(); // PrivateArticleSearch | Search Parameters


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateArticlesSearch(search, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateArticleSearch**](PrivateArticleSearch.md)| Search Parameters | 

### Return type

[**[ArticleWithProject]**](ArticleWithProject.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="publicArticleDownload"></a>
# **publicArticleDownload**
> publicArticleDownload(articleId, opts)

Public Article Download

Download files from a public article preserving the folder structure

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var opts = { 
  'folderPath': "folderPath_example" // String | Folder path to download. If not provided, all files from the article will be downloaded
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.publicArticleDownload(articleId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **folderPath** | **String**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="publicArticleVersionDownload"></a>
# **publicArticleVersionDownload**
> publicArticleVersionDownload(articleId, versionId, opts)

Public Article Version Download

Download files from a certain version of an public article preserving the folder structure

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.ArticlesApi();

var articleId = 789; // Number | Article unique identifier

var versionId = 789; // Number | Version Number

var opts = { 
  'folderPath': "folderPath_example" // String | Folder path to download. If not provided, all files from the article will be downloaded
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.publicArticleVersionDownload(articleId, versionId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article unique identifier | 
 **versionId** | **Number**| Version Number | 
 **folderPath** | **String**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

