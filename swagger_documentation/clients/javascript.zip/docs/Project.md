# FigshareApi.Project

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | Api endpoint | 
**id** | **Number** | Project id | 
**title** | **String** | Project title | 
**createdDate** | **String** | Date when project was created | 
**modifiedDate** | **String** | Date when project was last modified | 


