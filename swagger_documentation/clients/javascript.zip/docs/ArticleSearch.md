# FigshareApi.ArticleSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resourceDoi** | **String** | Only return articles with this resource_doi | [optional] 
**itemType** | **Number** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
**doi** | **String** | Only return articles with this doi | [optional] 
**handle** | **String** | Only return articles with this handle | [optional] 
**projectId** | **Number** | Only return articles in this project | [optional] 
**order** | **String** | The field by which to order | [optional] [default to 'created_date']


<a name="OrderEnum"></a>
## Enum: OrderEnum


* `createdDate` (value: `"created_date"`)

* `publishedDate` (value: `"published_date"`)

* `modifiedDate` (value: `"modified_date"`)

* `views` (value: `"views"`)

* `shares` (value: `"shares"`)

* `downloads` (value: `"downloads"`)

* `cites` (value: `"cites"`)




