# FigshareApi.ProjectsSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order** | **String** | The field by which to order. | [optional] [default to 'published_date']


<a name="OrderEnum"></a>
## Enum: OrderEnum


* `publishedDate` (value: `"published_date"`)

* `modifiedDate` (value: `"modified_date"`)

* `views` (value: `"views"`)




