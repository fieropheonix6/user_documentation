# FigshareApi.AuthorComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**institutionId** | **Number** | Institution id | 
**groupId** | **Number** | Group id | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**isPublic** | **Number** | if 1 then the author has published items | 
**jobTitle** | **String** | Job title | 


