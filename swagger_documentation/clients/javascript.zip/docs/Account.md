# FigshareApi.Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Account id | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**usedQuotaPrivate** | **Number** | Account used private quota | 
**modifiedDate** | **String** | Date of last account modification | 
**usedQuota** | **Number** | Account total used quota | 
**createdDate** | **String** | Date when account was created | 
**quota** | **Number** | Account quota | 
**groupId** | **Number** | Account group id | 
**institutionUserId** | **String** | Account institution user id | 
**institutionId** | **Number** | Account institution | 
**email** | **String** | User email | 
**usedQuotaPublic** | **Number** | Account public used quota | 
**pendingQuotaRequest** | **Boolean** | True if a quota request is pending | 
**active** | **Number** | Account activity status | 
**maximumFileSize** | **Number** | Maximum upload size for account | 
**userId** | **Number** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcidId** | **String** | ORCID iD associated to account | 
**symplecticUserId** | **String** | Symplectic ID associated to account | 


