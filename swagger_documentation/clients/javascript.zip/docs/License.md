# FigshareApi.License

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Number** | License value | 
**name** | **String** | License name | 
**url** | **String** | License url | 


