# FigshareApi.ArticleComplete

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**figshareUrl** | **String** | Article public url | 
**downloadDisabled** | **Boolean** | If true, downloading of files for this article is disabled | 
**files** | [**[PublicFile]**](PublicFile.md) | List of up to 10 article files. | 
**folderStructure** | **Object** | Mapping of file ids to folder paths, if folders are used | 
**authors** | [**[Author]**](Author.md) | List of article authors | 
**customFields** | [**[CustomArticleField]**](CustomArticleField.md) | List of custom fields values | 
**embargoOptions** | [**[GroupEmbargoOptions]**](GroupEmbargoOptions.md) | List of embargo options | 
**citation** | **String** | Article citation | 
**confidentialReason** | **String** | Confidentiality reason | 
**isConfidential** | **Boolean** | Article Confidentiality | 
**size** | **Number** | Article size | 
**funding** | **String** | Article funding | 
**fundingList** | [**[FundingInformation]**](FundingInformation.md) | Full Article funding information | 
**tags** | **[String]** | List of article tags. Keywords can be used instead | 
**keywords** | **[String]** | List of article keywords. Tags can be used instead | 
**version** | **Number** | Article version | 
**isMetadataRecord** | **Boolean** | True if article has no files | 
**metadataReason** | **String** | Article metadata reason | 
**status** | **String** | Article status | 
**description** | **String** | Article description | 
**isEmbargoed** | **Boolean** | True if article is embargoed | 
**isPublic** | **Boolean** | True if article is published | 
**createdDate** | **String** | Date when article was created | 
**hasLinkedFile** | **Boolean** | True if any files are linked to the article | 
**categories** | [**[Category]**](Category.md) | List of categories selected for the article | 
**license** | [**License**](License.md) |  | 
**embargoTitle** | **String** | Title for embargo | 
**embargoReason** | **String** | Reason for embargo | 
**references** | **[String]** | List of references | 
**relatedMaterials** | [**[RelatedMaterial]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**id** | **Number** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**urlPublicHtml** | **String** | Public site endpoint for article | 
**urlPublicApi** | **String** | Public Api endpoint for article | 
**urlPrivateHtml** | **String** | Private site endpoint for article | 
**urlPrivateApi** | **String** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) |  | 
**thumb** | **String** | Thumbnail image | 
**definedType** | **Number** | Type of article identifier | 
**definedTypeName** | **String** | Name of the article type identifier | 
**resourceDoi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to &#39;&#39;]
**resourceTitle** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to &#39;&#39;]


