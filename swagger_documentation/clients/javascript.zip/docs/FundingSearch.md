# FigshareApi.FundingSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**searchFor** | **String** | Search term | [optional] 


