# FigshareApi.PrivateProjectArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**files** | [**[PublicFile]**](PublicFile.md) | List of up to 10 article files. | 
**embargoOptions** | [**[GroupEmbargoOptions]**](GroupEmbargoOptions.md) | List of embargo options | 
**customFields** | [**[CustomArticleField]**](CustomArticleField.md) | List of custom fields values | 
**accountId** | **Number** | ID of the account owning the article | 
**downloadDisabled** | **Boolean** | If true, downloading of files for this article is disabled | 
**authors** | [**[Author]**](Author.md) | List of authors | 
**figshareUrl** | **String** | Article public url | 
**curationStatus** | **String** | Curation status of the article | 


