# SymplecticAccountsIds200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstitutionUserId** | Pointer to **string** |  | [optional] 
**ModifiedDate** | Pointer to **time.Time** |  | [optional] 

## Methods

### NewSymplecticAccountsIds200ResponseInner

`func NewSymplecticAccountsIds200ResponseInner() *SymplecticAccountsIds200ResponseInner`

NewSymplecticAccountsIds200ResponseInner instantiates a new SymplecticAccountsIds200ResponseInner object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewSymplecticAccountsIds200ResponseInnerWithDefaults

`func NewSymplecticAccountsIds200ResponseInnerWithDefaults() *SymplecticAccountsIds200ResponseInner`

NewSymplecticAccountsIds200ResponseInnerWithDefaults instantiates a new SymplecticAccountsIds200ResponseInner object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInstitutionUserId

`func (o *SymplecticAccountsIds200ResponseInner) GetInstitutionUserId() string`

GetInstitutionUserId returns the InstitutionUserId field if non-nil, zero value otherwise.

### GetInstitutionUserIdOk

`func (o *SymplecticAccountsIds200ResponseInner) GetInstitutionUserIdOk() (*string, bool)`

GetInstitutionUserIdOk returns a tuple with the InstitutionUserId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstitutionUserId

`func (o *SymplecticAccountsIds200ResponseInner) SetInstitutionUserId(v string)`

SetInstitutionUserId sets InstitutionUserId field to given value.

### HasInstitutionUserId

`func (o *SymplecticAccountsIds200ResponseInner) HasInstitutionUserId() bool`

HasInstitutionUserId returns a boolean if a field has been set.

### GetModifiedDate

`func (o *SymplecticAccountsIds200ResponseInner) GetModifiedDate() time.Time`

GetModifiedDate returns the ModifiedDate field if non-nil, zero value otherwise.

### GetModifiedDateOk

`func (o *SymplecticAccountsIds200ResponseInner) GetModifiedDateOk() (*time.Time, bool)`

GetModifiedDateOk returns a tuple with the ModifiedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModifiedDate

`func (o *SymplecticAccountsIds200ResponseInner) SetModifiedDate(v time.Time)`

SetModifiedDate sets ModifiedDate field to given value.

### HasModifiedDate

`func (o *SymplecticAccountsIds200ResponseInner) HasModifiedDate() bool`

HasModifiedDate returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


