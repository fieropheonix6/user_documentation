# Role

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Role id | [default to null]
**Name** | **string** | Role name | [default to null]
**Category** | **string** | Role category | [default to null]
**Description** | **string** | Role description | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


