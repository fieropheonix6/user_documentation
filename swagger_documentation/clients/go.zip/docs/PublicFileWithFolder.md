# PublicFileWithFolder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Files** | [**[]PublicFile**](PublicFile.md) | List of files with folder information. | [default to null]
**FolderStructure** | **interface{}** | Mapping of file ids to folder paths, if folders are used | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


