# CustomArticleFieldAddValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Methods

### NewCustomArticleFieldAddValue

`func NewCustomArticleFieldAddValue() *CustomArticleFieldAddValue`

NewCustomArticleFieldAddValue instantiates a new CustomArticleFieldAddValue object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCustomArticleFieldAddValueWithDefaults

`func NewCustomArticleFieldAddValueWithDefaults() *CustomArticleFieldAddValue`

NewCustomArticleFieldAddValueWithDefaults instantiates a new CustomArticleFieldAddValue object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


