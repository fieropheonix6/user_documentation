# ArticleVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Version** | **int64** | Version number | [default to null]
**Url** | **string** | Api endpoint for the item version | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


