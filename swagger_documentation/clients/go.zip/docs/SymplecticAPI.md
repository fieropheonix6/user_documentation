# \SymplecticAPI

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SymplecticAccountArticles**](SymplecticAPI.md#SymplecticAccountArticles) | **Get** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account
[**SymplecticAccountsIds**](SymplecticAPI.md#SymplecticAccountsIds) | **Get** /symplectic/accounts | Get changed accounts for Symplectic Elements
[**SymplecticArticle**](SymplecticAPI.md#SymplecticArticle) | **Get** /symplectic/articles/{article_id} | Get article details for Symplectic Elements
[**SymplecticChangedArticles**](SymplecticAPI.md#SymplecticChangedArticles) | **Get** /symplectic/articles | Get changed articles for Symplectic Elements
[**SymplecticUserId**](SymplecticAPI.md#SymplecticUserId) | **Get** /symplectic/users/{user_id} | Get institutional user ID for a user



## SymplecticAccountArticles

> []map[string]interface{} SymplecticAccountArticles(ctx, externalUserId).Offset(offset).Limit(limit).Status(status).IsEmbargoed(isEmbargoed).Execute()

Get articles for a specific account



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	externalUserId := "externalUserId_example" // string | External user ID (symplectic_user_id or institution_user_id)
	offset := int32(56) // int32 | Number of results to skip for pagination (optional) (default to 0)
	limit := int32(56) // int32 | Maximum number of results to return (optional) (default to 10)
	status := "status_example" // string | Filter by article status (optional)
	isEmbargoed := "isEmbargoed_example" // string | Filter by embargo status (optional)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.SymplecticAPI.SymplecticAccountArticles(context.Background(), externalUserId).Offset(offset).Limit(limit).Status(status).IsEmbargoed(isEmbargoed).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `SymplecticAPI.SymplecticAccountArticles``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `SymplecticAccountArticles`: []map[string]interface{}
	fmt.Fprintf(os.Stdout, "Response from `SymplecticAPI.SymplecticAccountArticles`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**externalUserId** | **string** | External user ID (symplectic_user_id or institution_user_id) | 

### Other Parameters

Other parameters are passed through a pointer to a apiSymplecticAccountArticlesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **offset** | **int32** | Number of results to skip for pagination | [default to 0]
 **limit** | **int32** | Maximum number of results to return | [default to 10]
 **status** | **string** | Filter by article status | 
 **isEmbargoed** | **string** | Filter by embargo status | 

### Return type

**[]map[string]interface{}**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SymplecticAccountsIds

> []SymplecticAccountsIds200ResponseInner SymplecticAccountsIds(ctx).Since(since).Execute()

Get changed accounts for Symplectic Elements



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	since := "2015-01-01 00:00:00" // string | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.SymplecticAPI.SymplecticAccountsIds(context.Background()).Since(since).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `SymplecticAPI.SymplecticAccountsIds``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `SymplecticAccountsIds`: []SymplecticAccountsIds200ResponseInner
	fmt.Fprintf(os.Stdout, "Response from `SymplecticAPI.SymplecticAccountsIds`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiSymplecticAccountsIdsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **since** | **string** | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | 

### Return type

[**[]SymplecticAccountsIds200ResponseInner**](SymplecticAccountsIds200ResponseInner.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SymplecticArticle

> map[string]interface{} SymplecticArticle(ctx, articleId).Execute()

Get article details for Symplectic Elements



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	articleId := int32(56) // int32 | Article ID

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.SymplecticAPI.SymplecticArticle(context.Background(), articleId).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `SymplecticAPI.SymplecticArticle``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `SymplecticArticle`: map[string]interface{}
	fmt.Fprintf(os.Stdout, "Response from `SymplecticAPI.SymplecticArticle`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**articleId** | **int32** | Article ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiSymplecticArticleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

**map[string]interface{}**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SymplecticChangedArticles

> []map[string]interface{} SymplecticChangedArticles(ctx).Since(since).Offset(offset).Limit(limit).Status(status).IsEmbargoed(isEmbargoed).Execute()

Get changed articles for Symplectic Elements



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	since := "2015-01-01 00:00:00" // string | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
	offset := int32(56) // int32 | Number of results to skip for pagination (optional) (default to 0)
	limit := int32(56) // int32 | Maximum number of results to return (optional) (default to 10)
	status := "status_example" // string | Filter by article status (optional)
	isEmbargoed := "isEmbargoed_example" // string | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type (optional)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.SymplecticAPI.SymplecticChangedArticles(context.Background()).Since(since).Offset(offset).Limit(limit).Status(status).IsEmbargoed(isEmbargoed).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `SymplecticAPI.SymplecticChangedArticles``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `SymplecticChangedArticles`: []map[string]interface{}
	fmt.Fprintf(os.Stdout, "Response from `SymplecticAPI.SymplecticChangedArticles`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiSymplecticChangedArticlesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **since** | **string** | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | 
 **offset** | **int32** | Number of results to skip for pagination | [default to 0]
 **limit** | **int32** | Maximum number of results to return | [default to 10]
 **status** | **string** | Filter by article status | 
 **isEmbargoed** | **string** | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type | 

### Return type

**[]map[string]interface{}**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SymplecticUserId

> SymplecticUserId200Response SymplecticUserId(ctx, userId).Execute()

Get institutional user ID for a user



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	userId := int32(56) // int32 | User ID

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.SymplecticAPI.SymplecticUserId(context.Background(), userId).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `SymplecticAPI.SymplecticUserId``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `SymplecticUserId`: SymplecticUserId200Response
	fmt.Fprintf(os.Stdout, "Response from `SymplecticAPI.SymplecticUserId`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**userId** | **int32** | User ID | 

### Other Parameters

Other parameters are passed through a pointer to a apiSymplecticUserIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**SymplecticUserId200Response**](SymplecticUserId200Response.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

