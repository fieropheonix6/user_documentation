# ShortCustomField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Custom field id | [default to null]
**Name** | **string** | Custom field name | [default to null]
**FieldType** | **string** | Custom field type | [default to null]
**Settings** | **interface{}** | Settings for the custom field | [optional] [default to null]
**Order** | **int64** | Order of the field in the group | [optional] [default to null]
**IsMandatory** | **bool** | Whether the field is mandatory or not | [optional] [default to null]
**Value** | **interface{}** | Custom metadata value (can be either a string or an array of strings) | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


