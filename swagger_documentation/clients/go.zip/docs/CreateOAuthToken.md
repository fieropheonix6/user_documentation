# CreateOAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClientId** | **string** |  | [default to null]
**ClientSecret** | **string** |  | [default to null]
**GrantType** | **string** |  | [default to null]
**Code** | **string** | Required if grant_type is &#39;authorization_code&#39; | [optional] [default to null]
**RefreshToken** | **string** | Required if grant_type is &#39;refresh_token&#39; | [optional] [default to null]
**Username** | **string** | Required if grant_type is &#39;password&#39; | [optional] [default to null]
**Password** | **string** | Required if grant_type is &#39;password&#39; | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


