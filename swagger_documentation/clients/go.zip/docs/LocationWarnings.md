# LocationWarnings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EntityId** | **int64** | Figshare ID of the entity | [default to null]
**Location** | **string** | Url for entity | [default to null]
**Warnings** | **[]string** | Issues encountered during the operation | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


