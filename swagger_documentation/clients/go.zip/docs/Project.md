# Project

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Url** | **string** | Api endpoint | [default to null]
**Id** | **int64** | Project id | [default to null]
**Title** | **string** | Project title | [default to null]
**CreatedDate** | **string** | Date when project was created | [default to null]
**ModifiedDate** | **string** | Date when project was last modified | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


