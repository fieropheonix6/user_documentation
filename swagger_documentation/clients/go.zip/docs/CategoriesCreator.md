# CategoriesCreator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Categories** | **[]int32** | List of category ids | 

## Methods

### NewCategoriesCreator

`func NewCategoriesCreator(categories []int32, ) *CategoriesCreator`

NewCategoriesCreator instantiates a new CategoriesCreator object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCategoriesCreatorWithDefaults

`func NewCategoriesCreatorWithDefaults() *CategoriesCreator`

NewCategoriesCreatorWithDefaults instantiates a new CategoriesCreator object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCategories

`func (o *CategoriesCreator) GetCategories() []int32`

GetCategories returns the Categories field if non-nil, zero value otherwise.

### GetCategoriesOk

`func (o *CategoriesCreator) GetCategoriesOk() (*[]int32, bool)`

GetCategoriesOk returns a tuple with the Categories field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCategories

`func (o *CategoriesCreator) SetCategories(v []int32)`

SetCategories sets Categories field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


