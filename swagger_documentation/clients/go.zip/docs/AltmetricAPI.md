# \AltmetricAPI

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AltmetricInstitutionsList**](AltmetricAPI.md#AltmetricInstitutionsList) | **Get** /altmetric/institutions | List Altmetric Institutions



## AltmetricInstitutionsList

> []AltmetricInstitution AltmetricInstitutionsList(ctx).Offset(offset).Execute()

List Altmetric Institutions



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	offset := int32(56) // int32 | Where to start the listing. The offset of the first item. (optional) (default to 0)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.AltmetricAPI.AltmetricInstitutionsList(context.Background()).Offset(offset).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `AltmetricAPI.AltmetricInstitutionsList``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `AltmetricInstitutionsList`: []AltmetricInstitution
	fmt.Fprintf(os.Stdout, "Response from `AltmetricAPI.AltmetricInstitutionsList`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiAltmetricInstitutionsListRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **int32** | Where to start the listing. The offset of the first item. | [default to 0]

### Return type

[**[]AltmetricInstitution**](AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

