# OAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessToken** | **string** | The OAuth access token | [default to null]
**Token** | **string** | The OAuth access token | [optional] [default to null]
**TokenType** | **string** | The type of token issued | [default to null]
**ExpiresIn** | **int64** | Token expiration time in seconds | [default to null]
**RefreshToken** | **string** | The refresh token (only provided for certain grant types) | [optional] [default to null]
**Scope** | **string** | The scope of the access token | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


