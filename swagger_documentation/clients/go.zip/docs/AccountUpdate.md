# AccountUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GroupId** | **int64** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [default to null]
**IsActive** | **bool** | Is account active | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


