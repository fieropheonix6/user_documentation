# CollectionComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Collection id | [default to null]
**Title** | **string** | Collection title | [default to null]
**Doi** | **string** | Collection DOI | [default to null]
**Handle** | **string** | Collection Handle | [default to null]
**Url** | **string** | Api endpoint | [default to null]
**Timeline** | [***Timeline**](Timeline.md) | Various timeline dates | [default to null]
**Funding** | [**[]FundingInformation**](FundingInformation.md) | Full Collection funding information | [default to null]
**ResourceId** | **string** | Collection resource id | [default to null]
**ResourceDoi** | **string** | Collection resource doi | [default to null]
**ResourceTitle** | **string** | Collection resource title | [default to null]
**ResourceLink** | **string** | Collection resource link | [default to null]
**ResourceVersion** | **int64** | Collection resource version | [default to null]
**Version** | **int64** | Collection version | [default to null]
**Description** | **string** | Collection description | [default to null]
**Categories** | [**[]Category**](Category.md) | List of collection categories | [default to null]
**References** | **[]string** | List of collection references | [default to null]
**Tags** | **[]string** | List of collection tags | [default to null]
**Authors** | [**[]Author**](Author.md) | List of collection authors | [default to null]
**InstitutionId** | **int64** | Collection institution | [default to null]
**GroupId** | **int64** | Collection group | [default to null]
**ArticlesCount** | **int64** | Number of articles in collection | [default to null]
**Public** | **bool** | True if collection is published | [default to null]
**Citation** | **string** | Collection citation | [default to null]
**CustomFields** | [**[]CustomArticleField**](CustomArticleField.md) | Collection custom fields | [default to null]
**ModifiedDate** | **string** | Date when collection was last modified | [default to null]
**CreatedDate** | **string** | Date when collection was created | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


