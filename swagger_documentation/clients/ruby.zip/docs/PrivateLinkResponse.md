# SwaggerClient::PrivateLinkResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **String** | Url for private link | 
**html_location** | **String** | HTML url for private link | 
**token** | **String** | Token for private link | 


