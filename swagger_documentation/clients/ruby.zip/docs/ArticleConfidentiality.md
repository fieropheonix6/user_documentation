# SwaggerClient::ArticleConfidentiality

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_confidential** | **BOOLEAN** | True if article is confidential | 
**reason** | **String** | Reason for confidentiality | 


