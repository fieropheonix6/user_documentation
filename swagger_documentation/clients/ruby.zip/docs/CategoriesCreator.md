# SwaggerClient::CategoriesCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | **Array&lt;Integer&gt;** | List of category ids | 


