# OpenapiClient::CollectionSearch

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **resource_doi** | **String** | Only return collections with this resource_doi | [optional] |
| **doi** | **String** | Only return collections with this doi | [optional] |
| **handle** | **String** | Only return collections with this handle | [optional] |
| **order** | **String** | The field by which to order. | [optional][default to &#39;created_date&#39;] |
| **search_for** | **String** | Search term | [optional] |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order_direction** | **String** | Direction of ordering | [optional][default to &#39;desc&#39;] |
| **institution** | **Integer** | only return collections from this institution | [optional] |
| **published_since** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **modified_since** | **String** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **group** | **Integer** | only return collections from this group | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CollectionSearch.new(
  resource_doi: 10.6084/m9.figshare.1407024,
  doi: 10.6084/m9.figshare.1407024,
  handle: 10084/figshare.1407024,
  order: published_date,
  search_for: figshare,
  page: 1,
  page_size: 10,
  limit: 10,
  offset: 0,
  order_direction: desc,
  institution: 2000013,
  published_since: 2017-12-22,
  modified_since: 2017-12-22,
  group: 2000013
)
```

