# OpenapiClient::CustomArticleFieldAdd

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** | Custom  metadata name |  |
| **value** | [**CustomArticleFieldAddValue**](CustomArticleFieldAddValue.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CustomArticleFieldAdd.new(
  name: key,
  value: null
)
```

