# SwaggerClient::ArticleVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **Integer** | Version number | 
**url** | **String** | Api endpoint for the item version | 


