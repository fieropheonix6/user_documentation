# OpenapiClient::ProfileUpdateData

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **first_name** | **String** | First name | [optional] |
| **last_name** | **String** | Last Name | [optional] |
| **orcid** | **String** | User ORCID | [optional] |
| **job_title** | **String** | User job title | [optional] |
| **fields_of_interest** | **Array&lt;Integer&gt;** | User fields of interest (category ids) | [optional] |
| **fields_of_interest_by_source_id** | **Array&lt;String&gt;** | User fields of interest (category source IDs), supersedes the fields_of_interest property | [optional] |
| **location** | **String** | User location | [optional] |
| **facebook** | **String** | User facebook URL | [optional] |
| **x** | **String** | User X (twitter) URL | [optional] |
| **linkedin** | **String** | User linkedin URL | [optional] |
| **bio** | **String** | User biographical information | [optional] |
| **personal_profiles** | [**Array&lt;ProfileUpdateDataPersonalProfilesInner&gt;**](ProfileUpdateDataPersonalProfilesInner.md) | Add up to 10 additional personal profile links | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ProfileUpdateData.new(
  first_name: John,
  last_name: Doe,
  orcid: 0000-0001-YYYY-XXXX,
  job_title: Researcher at institution X,
  fields_of_interest: [1,2],
  fields_of_interest_by_source_id: [&quot;3204&quot;,&quot;320401&quot;],
  location: London, UK,
  facebook: https://facebook.com/profile/1,
  x: https://x.com/profile/1,
  linkedin: https://linkedin.com/profile/2,
  bio: Biographical information,
  personal_profiles: [{&quot;label&quot;:&quot;ResearchGate&quot;,&quot;url&quot;:&quot;https://researchgate.net/profile/1&quot;},{&quot;label&quot;:&quot;&quot;,&quot;url&quot;:&quot;https://academia.edu/profile/1&quot;}]
)
```

