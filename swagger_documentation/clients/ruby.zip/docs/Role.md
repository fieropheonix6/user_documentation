# SwaggerClient::Role

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Role id | 
**name** | **String** | Role name | 
**category** | **String** | Role category | 
**description** | **String** | Role description | 


