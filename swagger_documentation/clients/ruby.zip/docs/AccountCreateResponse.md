# SwaggerClient::AccountCreateResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account_id** | **Integer** | ID of created account | 


