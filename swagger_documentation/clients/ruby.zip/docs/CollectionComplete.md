# SwaggerClient::CollectionComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Collection id | 
**title** | **String** | Collection title | 
**doi** | **String** | Collection DOI | 
**handle** | **String** | Collection Handle | 
**url** | **String** | Api endpoint | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**funding** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information | 
**resource_id** | **String** | Collection resource id | 
**resource_doi** | **String** | Collection resource doi | 
**resource_title** | **String** | Collection resource title | 
**resource_link** | **String** | Collection resource link | 
**resource_version** | **Integer** | Collection resource version | 
**version** | **Integer** | Collection version | 
**description** | **String** | Collection description | 
**categories** | [**Array&lt;Category&gt;**](Category.md) | List of collection categories | 
**references** | **Array&lt;String&gt;** | List of collection references | 
**related_materials** | [**Array&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**tags** | **Array&lt;String&gt;** | List of collection tags | 
**authors** | [**Array&lt;Author&gt;**](Author.md) | List of collection authors | 
**institution_id** | **Integer** | Collection institution | 
**group_id** | **Integer** | Collection group | 
**articles_count** | **Integer** | Number of articles in collection | 
**public** | **BOOLEAN** | True if collection is published | 
**citation** | **String** | Collection citation | 
**custom_fields** | [**Array&lt;CustomArticleField&gt;**](CustomArticleField.md) | Collection custom fields | 
**modified_date** | **String** | Date when collection was last modified | 
**created_date** | **String** | Date when collection was created | 


