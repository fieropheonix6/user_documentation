# OpenapiClient::ProjectNote

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Project note id |  |
| **user_id** | **Integer** | User who wrote the note |  |
| **abstract** | **String** | Note Abstract - short/truncated content |  |
| **user_name** | **String** | Username of the one who wrote the note |  |
| **created_date** | **String** | Date when note was created |  |
| **modified_date** | **String** | Date when note was last modified |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ProjectNote.new(
  id: 1,
  user_id: 100008,
  abstract: text,
  user_name: user,
  created_date: 2017-05-16T16:49:11Z,
  modified_date: 2017-05-16T16:49:11Z
)
```

