# OpenapiClient::SymplecticApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
| ------ | ------------ | ----------- |
| [**symplectic_account_articles**](SymplecticApi.md#symplectic_account_articles) | **GET** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account |
| [**symplectic_accounts_ids**](SymplecticApi.md#symplectic_accounts_ids) | **GET** /symplectic/accounts | Get changed accounts for Symplectic Elements |
| [**symplectic_article**](SymplecticApi.md#symplectic_article) | **GET** /symplectic/articles/{article_id} | Get article details for Symplectic Elements |
| [**symplectic_changed_articles**](SymplecticApi.md#symplectic_changed_articles) | **GET** /symplectic/articles | Get changed articles for Symplectic Elements |
| [**symplectic_user_id**](SymplecticApi.md#symplectic_user_id) | **GET** /symplectic/users/{user_id} | Get institutional user ID for a user |


## symplectic_account_articles

> Array&lt;Object&gt; symplectic_account_articles(external_user_id, opts)

Get articles for a specific account

Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::SymplecticApi.new
external_user_id = 'external_user_id_example' # String | External user ID (symplectic_user_id or institution_user_id)
opts = {
  offset: 56, # Integer | Number of results to skip for pagination
  limit: 56, # Integer | Maximum number of results to return
  status: 'public', # String | Filter by article status
  is_embargoed: 'true' # String | Filter by embargo status
}

begin
  # Get articles for a specific account
  result = api_instance.symplectic_account_articles(external_user_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling SymplecticApi->symplectic_account_articles: #{e}"
end
```

#### Using the symplectic_account_articles_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(Array&lt;Object&gt;, Integer, Hash)> symplectic_account_articles_with_http_info(external_user_id, opts)

```ruby
begin
  # Get articles for a specific account
  data, status_code, headers = api_instance.symplectic_account_articles_with_http_info(external_user_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => Array&lt;Object&gt;
rescue OpenapiClient::ApiError => e
  puts "Error when calling SymplecticApi->symplectic_account_articles_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **external_user_id** | **String** | External user ID (symplectic_user_id or institution_user_id) |  |
| **offset** | **Integer** | Number of results to skip for pagination | [optional][default to 0] |
| **limit** | **Integer** | Maximum number of results to return | [optional][default to 10] |
| **status** | **String** | Filter by article status | [optional] |
| **is_embargoed** | **String** | Filter by embargo status | [optional] |

### Return type

**Array&lt;Object&gt;**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## symplectic_accounts_ids

> <Array<SymplecticAccountsIds200ResponseInner>> symplectic_accounts_ids(since)

Get changed accounts for Symplectic Elements

Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::SymplecticApi.new
since = '2015-01-01 00:00:00' # String | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)

begin
  # Get changed accounts for Symplectic Elements
  result = api_instance.symplectic_accounts_ids(since)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling SymplecticApi->symplectic_accounts_ids: #{e}"
end
```

#### Using the symplectic_accounts_ids_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<SymplecticAccountsIds200ResponseInner>>, Integer, Hash)> symplectic_accounts_ids_with_http_info(since)

```ruby
begin
  # Get changed accounts for Symplectic Elements
  data, status_code, headers = api_instance.symplectic_accounts_ids_with_http_info(since)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<SymplecticAccountsIds200ResponseInner>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling SymplecticApi->symplectic_accounts_ids_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **since** | **String** | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) |  |

### Return type

[**Array&lt;SymplecticAccountsIds200ResponseInner&gt;**](SymplecticAccountsIds200ResponseInner.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## symplectic_article

> Object symplectic_article(article_id)

Get article details for Symplectic Elements

Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::SymplecticApi.new
article_id = 56 # Integer | Article ID

begin
  # Get article details for Symplectic Elements
  result = api_instance.symplectic_article(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling SymplecticApi->symplectic_article: #{e}"
end
```

#### Using the symplectic_article_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(Object, Integer, Hash)> symplectic_article_with_http_info(article_id)

```ruby
begin
  # Get article details for Symplectic Elements
  data, status_code, headers = api_instance.symplectic_article_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => Object
rescue OpenapiClient::ApiError => e
  puts "Error when calling SymplecticApi->symplectic_article_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article ID |  |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## symplectic_changed_articles

> Array&lt;Object&gt; symplectic_changed_articles(since, opts)

Get changed articles for Symplectic Elements

Returns a list of articles for Symplectic Elements integration to synchronize article data.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::SymplecticApi.new
since = '2015-01-01 00:00:00' # String | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
opts = {
  offset: 56, # Integer | Number of results to skip for pagination
  limit: 56, # Integer | Maximum number of results to return
  status: 'public', # String | Filter by article status
  is_embargoed: 'true' # String | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type
}

begin
  # Get changed articles for Symplectic Elements
  result = api_instance.symplectic_changed_articles(since, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling SymplecticApi->symplectic_changed_articles: #{e}"
end
```

#### Using the symplectic_changed_articles_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(Array&lt;Object&gt;, Integer, Hash)> symplectic_changed_articles_with_http_info(since, opts)

```ruby
begin
  # Get changed articles for Symplectic Elements
  data, status_code, headers = api_instance.symplectic_changed_articles_with_http_info(since, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => Array&lt;Object&gt;
rescue OpenapiClient::ApiError => e
  puts "Error when calling SymplecticApi->symplectic_changed_articles_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **since** | **String** | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) |  |
| **offset** | **Integer** | Number of results to skip for pagination | [optional][default to 0] |
| **limit** | **Integer** | Maximum number of results to return | [optional][default to 10] |
| **status** | **String** | Filter by article status | [optional] |
| **is_embargoed** | **String** | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type | [optional] |

### Return type

**Array&lt;Object&gt;**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## symplectic_user_id

> <SymplecticUserId200Response> symplectic_user_id(user_id)

Get institutional user ID for a user

Returns the institution user ID for a given user within the authenticated account's institution.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::SymplecticApi.new
user_id = 56 # Integer | User ID

begin
  # Get institutional user ID for a user
  result = api_instance.symplectic_user_id(user_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling SymplecticApi->symplectic_user_id: #{e}"
end
```

#### Using the symplectic_user_id_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<SymplecticUserId200Response>, Integer, Hash)> symplectic_user_id_with_http_info(user_id)

```ruby
begin
  # Get institutional user ID for a user
  data, status_code, headers = api_instance.symplectic_user_id_with_http_info(user_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <SymplecticUserId200Response>
rescue OpenapiClient::ApiError => e
  puts "Error when calling SymplecticApi->symplectic_user_id_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **user_id** | **Integer** | User ID |  |

### Return type

[**SymplecticUserId200Response**](SymplecticUserId200Response.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

