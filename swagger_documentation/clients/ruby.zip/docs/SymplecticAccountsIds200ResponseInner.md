# OpenapiClient::SymplecticAccountsIds200ResponseInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **institution_user_id** | **String** |  | [optional] |
| **modified_date** | **Time** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SymplecticAccountsIds200ResponseInner.new(
  institution_user_id: null,
  modified_date: null
)
```

