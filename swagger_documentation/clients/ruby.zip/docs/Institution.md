# OpenapiClient::Institution

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Institution id |  |
| **name** | **String** | Institution name |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Institution.new(
  id: 0,
  name: Institution
)
```

