# SwaggerClient::ArticleVersionUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supplementary_fields** | **Array&lt;Object&gt;** | List of supplementary fields to be associated with the article version | [optional] 
**internal_metadata** | **Object** | List of supplementary fields to be associated with the article version | [optional] 


