# SwaggerClient::ArticlesCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | **Array&lt;Integer&gt;** | List of article ids | 


