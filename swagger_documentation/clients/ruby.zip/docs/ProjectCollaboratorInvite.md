# OpenapiClient::ProjectCollaboratorInvite

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **role_name** | **String** | Role of the the collaborator inside the project |  |
| **user_id** | **Integer** | User id of the collaborator | [optional] |
| **email** | **String** | Collaborator email | [optional] |
| **comment** | **String** | Text sent when inviting the user to the project | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ProjectCollaboratorInvite.new(
  role_name: viewer,
  user_id: 100008,
  email: user@domain.com,
  comment: hey
)
```

