# SwaggerClient::AuthorComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Author id | 
**full_name** | **String** | Author full name | 
**first_name** | **String** | First Name | 
**last_name** | **String** | Last Name | 
**is_active** | **BOOLEAN** | True if author has published items | 
**url_name** | **String** | Author url name | 
**orcid_id** | **String** | Author Orcid | 
**group_id** | **Integer** | Group id | 
**is_public** | **Integer** | if 1 then the author has published items | 
**institution_id** | **Integer** | Institution id | 
**job_title** | **String** | Job title | 


