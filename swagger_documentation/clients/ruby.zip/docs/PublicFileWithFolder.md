# SwaggerClient::PublicFileWithFolder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**files** | [**Array&lt;PublicFile&gt;**](PublicFile.md) | List of files with folder information. | 
**folder_structure** | **Object** | Mapping of file ids to folder paths, if folders are used | 


