# SwaggerClient::Curation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | The review id | 
**group_id** | **Integer** | The group in which the article is present. | 
**account_id** | **Integer** | The ID of the account of the owner of the article of this review. | 
**assigned_to** | **Integer** | The ID of the account to which this review is assigned. | 
**article_id** | **Integer** | The ID of the article of this review. | 
**version** | **Integer** | The Version number of the article in review. | 
**comments_count** | **Integer** | The number of comments in the review. | 
**status** | **String** | The status of the review. | 
**created_date** | **String** | The creation date of the review. | 
**modified_date** | **String** | The date the review has been modified. | 
**request_number** | **Integer** | The request number of the review. | 
**resolution_comment** | **String** | The resolution comment of the review. | 


