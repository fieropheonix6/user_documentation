# SwaggerClient::ArticleWithProject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**url_public_html** | **String** | Public site endpoint for article | 
**url_public_api** | **String** | Public Api endpoint for article | 
**url_private_html** | **String** | Private site endpoint for article | 
**url_private_api** | **String** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**thumb** | **String** | Thumbnail image | 
**defined_type** | **Integer** | Type of article identifier | 
**defined_type_name** | **String** | Name of the article type identifier | 
**resource_doi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to &#39;&#39;]
**resource_title** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to &#39;&#39;]
**project_id** | **Integer** | Project id for this article. | [default to 0]


