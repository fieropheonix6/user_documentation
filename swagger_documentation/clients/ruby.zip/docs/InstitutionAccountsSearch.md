# OpenapiClient::InstitutionAccountsSearch

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **search_for** | **String** | Search term | [optional] |
| **is_active** | **Integer** | Filter by active status | [optional] |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **institution_user_id** | **String** | filter by institution_user_id | [optional] |
| **email** | **String** | filter by email | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InstitutionAccountsSearch.new(
  search_for: figshare,
  is_active: null,
  page: 1,
  page_size: 10,
  limit: 10,
  offset: 0,
  institution_user_id: alan,
  email: alan@institution.com
)
```

