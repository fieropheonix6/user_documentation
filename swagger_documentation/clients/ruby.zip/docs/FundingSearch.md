# SwaggerClient::FundingSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | **String** | Search term | [optional] 


