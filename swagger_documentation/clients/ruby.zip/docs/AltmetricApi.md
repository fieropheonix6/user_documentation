# OpenapiClient::AltmetricApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
| ------ | ------------ | ----------- |
| [**altmetric_institutions_list**](AltmetricApi.md#altmetric_institutions_list) | **GET** /altmetric/institutions | List Altmetric Institutions |


## altmetric_institutions_list

> <Array<AltmetricInstitution>> altmetric_institutions_list(opts)

List Altmetric Institutions

Returns a list of institutions available for Altmetric reporting

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::AltmetricApi.new
opts = {
  offset: 56 # Integer | Where to start the listing. The offset of the first item.
}

begin
  # List Altmetric Institutions
  result = api_instance.altmetric_institutions_list(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling AltmetricApi->altmetric_institutions_list: #{e}"
end
```

#### Using the altmetric_institutions_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<AltmetricInstitution>>, Integer, Hash)> altmetric_institutions_list_with_http_info(opts)

```ruby
begin
  # List Altmetric Institutions
  data, status_code, headers = api_instance.altmetric_institutions_list_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<AltmetricInstitution>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling AltmetricApi->altmetric_institutions_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **offset** | **Integer** | Where to start the listing. The offset of the first item. | [optional][default to 0] |

### Return type

[**Array&lt;AltmetricInstitution&gt;**](AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

