# SwaggerClient::ProjectArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**url_public_html** | **String** | Public site endpoint for article | 
**url_public_api** | **String** | Public Api endpoint for article | 
**url_private_html** | **String** | Private site endpoint for article | 
**url_private_api** | **String** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**thumb** | **String** | Thumbnail image | 
**defined_type** | **Integer** | Type of article identifier | 
**defined_type_name** | **String** | Name of the article type identifier | 
**resource_doi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to &#39;&#39;]
**resource_title** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to &#39;&#39;]
**created_date** | **String** | Date when article was created | 
**citation** | **String** | Article citation | 
**confidential_reason** | **String** | Confidentiality reason | 
**is_confidential** | **BOOLEAN** | Article Confidentiality | 
**size** | **Integer** | Article size | 
**funding** | **String** | Article funding | 
**funding_list** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Article funding information | 
**tags** | **Array&lt;String&gt;** | List of article tags. Keywords can be used instead | 
**keywords** | **Array&lt;String&gt;** | List of article keywords. Tags can be used instead | 
**version** | **Integer** | Article version | 
**is_metadata_record** | **BOOLEAN** | True if article has no files | 
**metadata_reason** | **String** | Article metadata reason | 
**status** | **String** | Article status | 
**description** | **String** | Article description | 
**is_embargoed** | **BOOLEAN** | True if article is embargoed | 
**is_public** | **BOOLEAN** | True if article is published | 
**has_linked_file** | **BOOLEAN** | True if any files are linked to the article | 
**categories** | [**Array&lt;Category&gt;**](Category.md) | List of categories selected for the article | 
**license** | [**License**](License.md) | Article selected license | 
**embargo_title** | **String** | Title for embargo | 
**embargo_reason** | **String** | Reason for embargo | 
**references** | **Array&lt;String&gt;** | List of references | 
**related_materials** | [**Array&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 


