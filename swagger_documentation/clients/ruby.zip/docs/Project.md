# SwaggerClient::Project

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | Api endpoint | 
**id** | **Integer** | Project id | 
**title** | **String** | Project title | 


