# SwaggerClient::FileId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file_id** | **Integer** | File ID | [optional] 


