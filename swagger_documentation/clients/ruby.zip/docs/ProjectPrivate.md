# SwaggerClient::ProjectPrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | Api endpoint | 
**id** | **Integer** | Project id | 
**title** | **String** | Project title | 
**created_date** | **String** | Date when project was created | 
**modified_date** | **String** | Date when project was last modified | 
**role** | **String** | Role inside this project | 
**storage** | **String** | Project storage type | 


