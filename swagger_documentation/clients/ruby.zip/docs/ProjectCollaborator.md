# SwaggerClient::ProjectCollaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | Status of collaborator invitation | 
**role_name** | **String** | Collaborator role | 
**user_id** | **Integer** | Collaborator id | 
**name** | **String** | Collaborator name | 


