# SwaggerClient::CreateOAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_id** | **String** |  | 
**client_secret** | **String** |  | 
**grant_type** | **String** |  | 
**code** | **String** | Required if grant_type is &#39;authorization_code&#39; | [optional] 
**refresh_token** | **String** | Required if grant_type is &#39;refresh_token&#39; | [optional] 
**username** | **String** | Required if grant_type is &#39;password&#39; | [optional] 
**password** | **String** | Required if grant_type is &#39;password&#39; | [optional] 


