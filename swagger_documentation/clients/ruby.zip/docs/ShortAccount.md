# OpenapiClient::ShortAccount

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Account id |  |
| **first_name** | **String** | First Name |  |
| **last_name** | **String** | Last Name |  |
| **institution_id** | **Integer** | Account institution |  |
| **email** | **String** | User email |  |
| **active** | **Integer** | Account activity status |  |
| **institution_user_id** | **String** | Account institution user id |  |
| **quota** | **Integer** | Total storage available to account, in bytes |  |
| **used_quota** | **Integer** | Storage used by the account, in bytes |  |
| **user_id** | **Integer** | User id associated with account, useful for example for adding the account as an author to an item |  |
| **orcid_id** | **String** | ORCID iD associated to account |  |
| **symplectic_user_id** | **String** | Symplectic ID associated to account |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ShortAccount.new(
  id: 1495682,
  first_name: Doe,
  last_name: John,
  institution_id: 1,
  email: user@domain.com,
  active: 0,
  institution_user_id: 1,
  quota: 1074000000,
  used_quota: 1074000000,
  user_id: 1000001,
  orcid_id: 0000-0001-2345-6789,
  symplectic_user_id: djohn42
)
```

