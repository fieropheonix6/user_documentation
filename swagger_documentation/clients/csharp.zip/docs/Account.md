# Org.OpenAPITools.Model.Account

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | Account id | 
**FirstName** | **string** | First Name | 
**LastName** | **string** | Last Name | 
**UsedQuotaPrivate** | **int** | Account used private quota | 
**ModifiedDate** | **string** | Date of last account modification | 
**UsedQuota** | **int** | Account total used quota | 
**CreatedDate** | **string** | Date when account was created | 
**Quota** | **int** | Account quota | 
**GroupId** | **int** | Account group id | 
**InstitutionUserId** | **string** | Account institution user id | 
**InstitutionId** | **int** | Account institution | 
**Email** | **string** | User email | 
**UsedQuotaPublic** | **int** | Account public used quota | 
**PendingQuotaRequest** | **bool** | True if a quota request is pending | 
**Active** | **int** | Account activity status | 
**MaximumFileSize** | **int** | Maximum upload size for account | 
**UserId** | **int** | User id associated with account, useful for example for adding the account as an author to an item | 
**OrcidId** | **string** | ORCID iD associated to account | 
**SymplecticUserId** | **string** | Symplectic ID associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

