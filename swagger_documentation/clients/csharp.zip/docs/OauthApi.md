# IO.Swagger.Api.OauthApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateToken**](OauthApi.md#createtoken) | **POST** /token | Create OAuth token
[**GetTokenInfo**](OauthApi.md#gettokeninfo) | **GET** /token | Get OAuth token information


<a name="createtoken"></a>
# **CreateToken**
> OAuthToken CreateToken (CreateOAuthToken body = null)

Create OAuth token

Creates OAuth token using various grant types

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CreateTokenExample
    {
        public void main()
        {
            var apiInstance = new OauthApi();
            var body = new CreateOAuthToken(); // CreateOAuthToken | Create OAuth Token Parameters (optional) 

            try
            {
                // Create OAuth token
                OAuthToken result = apiInstance.CreateToken(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OauthApi.CreateToken: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateOAuthToken**](CreateOAuthToken.md)| Create OAuth Token Parameters | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettokeninfo"></a>
# **GetTokenInfo**
> OAuthToken GetTokenInfo (string accessToken = null)

Get OAuth token information

Returns information about the current OAuth token

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTokenInfoExample
    {
        public void main()
        {
            var apiInstance = new OauthApi();
            var accessToken = accessToken_example;  // string | OAuth access token (optional) 

            try
            {
                // Get OAuth token information
                OAuthToken result = apiInstance.GetTokenInfo(accessToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OauthApi.GetTokenInfo: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accessToken** | **string**| OAuth access token | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

