# IO.Swagger.Api.ArticlesApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AccountArticlePublish**](ArticlesApi.md#accountarticlepublish) | **POST** /account/articles/{article_id}/publish | Private Article Publish
[**AccountArticleReport**](ArticlesApi.md#accountarticlereport) | **GET** /account/articles/export | Account Article Report
[**AccountArticleReportGenerate**](ArticlesApi.md#accountarticlereportgenerate) | **POST** /account/articles/export | Initiate a new Report
[**AccountArticleUnpublish**](ArticlesApi.md#accountarticleunpublish) | **POST** /account/articles/{article_id}/unpublish | Public Article Unpublish
[**ArticleDetails**](ArticlesApi.md#articledetails) | **GET** /articles/{article_id} | View article details
[**ArticleFileDetails**](ArticlesApi.md#articlefiledetails) | **GET** /articles/{article_id}/files/{file_id} | Article file details
[**ArticleFiles**](ArticlesApi.md#articlefiles) | **GET** /articles/{article_id}/files | List article files
[**ArticleVersionConfidentiality**](ArticlesApi.md#articleversionconfidentiality) | **GET** /articles/{article_id}/versions/{version_id}/confidentiality | Public Article Confidentiality for article version
[**ArticleVersionDetails**](ArticlesApi.md#articleversiondetails) | **GET** /articles/{article_id}/versions/{version_id} | Article details for version
[**ArticleVersionEmbargo**](ArticlesApi.md#articleversionembargo) | **GET** /articles/{article_id}/versions/{version_id}/embargo | Public Article Embargo for article version
[**ArticleVersionFiles**](ArticlesApi.md#articleversionfiles) | **GET** /articles/{article_id}/versions/{version_id}/files | Article version file details
[**ArticleVersionPartialUpdate**](ArticlesApi.md#articleversionpartialupdate) | **PATCH** /account/articles/{article_id}/versions/{version_id} | Partially update article version
[**ArticleVersionUpdate**](ArticlesApi.md#articleversionupdate) | **PUT** /account/articles/{article_id}/versions/{version_id} | Update article version
[**ArticleVersionUpdateThumb**](ArticlesApi.md#articleversionupdatethumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail
[**ArticleVersions**](ArticlesApi.md#articleversions) | **GET** /articles/{article_id}/versions | List article versions
[**ArticlesList**](ArticlesApi.md#articleslist) | **GET** /articles | Public Articles
[**ArticlesSearch**](ArticlesApi.md#articlessearch) | **POST** /articles/search | Public Articles Search
[**PrivateArticleAuthorDelete**](ArticlesApi.md#privatearticleauthordelete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author
[**PrivateArticleAuthorsAdd**](ArticlesApi.md#privatearticleauthorsadd) | **POST** /account/articles/{article_id}/authors | Add article authors
[**PrivateArticleAuthorsList**](ArticlesApi.md#privatearticleauthorslist) | **GET** /account/articles/{article_id}/authors | List article authors
[**PrivateArticleAuthorsReplace**](ArticlesApi.md#privatearticleauthorsreplace) | **PUT** /account/articles/{article_id}/authors | Replace article authors
[**PrivateArticleCategoriesAdd**](ArticlesApi.md#privatearticlecategoriesadd) | **POST** /account/articles/{article_id}/categories | Add article categories
[**PrivateArticleCategoriesList**](ArticlesApi.md#privatearticlecategorieslist) | **GET** /account/articles/{article_id}/categories | List article categories
[**PrivateArticleCategoriesReplace**](ArticlesApi.md#privatearticlecategoriesreplace) | **PUT** /account/articles/{article_id}/categories | Replace article categories
[**PrivateArticleCategoryDelete**](ArticlesApi.md#privatearticlecategorydelete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category
[**PrivateArticleConfidentialityDelete**](ArticlesApi.md#privatearticleconfidentialitydelete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality
[**PrivateArticleConfidentialityDetails**](ArticlesApi.md#privatearticleconfidentialitydetails) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details
[**PrivateArticleConfidentialityUpdate**](ArticlesApi.md#privatearticleconfidentialityupdate) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality
[**PrivateArticleCreate**](ArticlesApi.md#privatearticlecreate) | **POST** /account/articles | Create new Article
[**PrivateArticleDelete**](ArticlesApi.md#privatearticledelete) | **DELETE** /account/articles/{article_id} | Delete article
[**PrivateArticleDetails**](ArticlesApi.md#privatearticledetails) | **GET** /account/articles/{article_id} | Article details
[**PrivateArticleDownload**](ArticlesApi.md#privatearticledownload) | **GET** /account/articles/{article_id}/download | Private Article Download
[**PrivateArticleEmbargoDelete**](ArticlesApi.md#privatearticleembargodelete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo
[**PrivateArticleEmbargoDetails**](ArticlesApi.md#privatearticleembargodetails) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details
[**PrivateArticleEmbargoUpdate**](ArticlesApi.md#privatearticleembargoupdate) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo
[**PrivateArticleFile**](ArticlesApi.md#privatearticlefile) | **GET** /account/articles/{article_id}/files/{file_id} | Single File
[**PrivateArticleFileDelete**](ArticlesApi.md#privatearticlefiledelete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete
[**PrivateArticleFilesList**](ArticlesApi.md#privatearticlefileslist) | **GET** /account/articles/{article_id}/files | List article files
[**PrivateArticlePartialUpdate**](ArticlesApi.md#privatearticlepartialupdate) | **PATCH** /account/articles/{article_id} | Partially update article
[**PrivateArticlePrivateLink**](ArticlesApi.md#privatearticleprivatelink) | **GET** /account/articles/{article_id}/private_links | List private links
[**PrivateArticlePrivateLinkCreate**](ArticlesApi.md#privatearticleprivatelinkcreate) | **POST** /account/articles/{article_id}/private_links | Create private link
[**PrivateArticlePrivateLinkDelete**](ArticlesApi.md#privatearticleprivatelinkdelete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link
[**PrivateArticlePrivateLinkUpdate**](ArticlesApi.md#privatearticleprivatelinkupdate) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link
[**PrivateArticleReserveDoi**](ArticlesApi.md#privatearticlereservedoi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI
[**PrivateArticleReserveHandle**](ArticlesApi.md#privatearticlereservehandle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle
[**PrivateArticleResource**](ArticlesApi.md#privatearticleresource) | **POST** /account/articles/{article_id}/resource | Private Article Resource
[**PrivateArticleUpdate**](ArticlesApi.md#privatearticleupdate) | **PUT** /account/articles/{article_id} | Update article
[**PrivateArticleUploadComplete**](ArticlesApi.md#privatearticleuploadcomplete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload
[**PrivateArticleUploadInitiate**](ArticlesApi.md#privatearticleuploadinitiate) | **POST** /account/articles/{article_id}/files | Initiate Upload
[**PrivateArticlesList**](ArticlesApi.md#privatearticleslist) | **GET** /account/articles | Private Articles
[**PrivateArticlesSearch**](ArticlesApi.md#privatearticlessearch) | **POST** /account/articles/search | Private Articles search
[**PublicArticleDownload**](ArticlesApi.md#publicarticledownload) | **GET** /articles/{article_id}/download | Public Article Download
[**PublicArticleVersionDownload**](ArticlesApi.md#publicarticleversiondownload) | **GET** /articles/{article_id}/versions/{version_id}/download | Public Article Version Download


<a name="accountarticlepublish"></a>
# **AccountArticlePublish**
> Location AccountArticlePublish (long? articleId)

Private Article Publish

- If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AccountArticlePublishExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // Private Article Publish
                Location result = apiInstance.AccountArticlePublish(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.AccountArticlePublish: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="accountarticlereport"></a>
# **AccountArticleReport**
> List<AccountReport> AccountArticleReport (long? groupId = null)

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AccountArticleReportExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var groupId = 789;  // long? | A group ID to filter by (optional) 

            try
            {
                // Account Article Report
                List&lt;AccountReport&gt; result = apiInstance.AccountArticleReport(groupId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.AccountArticleReport: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **long?**| A group ID to filter by | [optional] 

### Return type

[**List<AccountReport>**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="accountarticlereportgenerate"></a>
# **AccountArticleReportGenerate**
> AccountReport AccountArticleReportGenerate ()

Initiate a new Report

Initiate a new Article Report for this Account. There is a limit of 1 report per day.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AccountArticleReportGenerateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();

            try
            {
                // Initiate a new Report
                AccountReport result = apiInstance.AccountArticleReportGenerate();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.AccountArticleReportGenerate: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="accountarticleunpublish"></a>
# **AccountArticleUnpublish**
> void AccountArticleUnpublish (long? articleId, ArticleUnpublishData reason)

Public Article Unpublish

Allows authorized users to unpublish an article.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AccountArticleUnpublishExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var reason = new ArticleUnpublishData(); // ArticleUnpublishData | Article unpublish data

            try
            {
                // Public Article Unpublish
                apiInstance.AccountArticleUnpublish(articleId, reason);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.AccountArticleUnpublish: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **reason** | [**ArticleUnpublishData**](ArticleUnpublishData.md)| Article unpublish data | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articledetails"></a>
# **ArticleDetails**
> ArticleComplete ArticleDetails (long? articleId)

View article details

View an article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleDetailsExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article Unique identifier

            try
            {
                // View article details
                ArticleComplete result = apiInstance.ArticleDetails(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article Unique identifier | 

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articlefiledetails"></a>
# **ArticleFileDetails**
> PublicFile ArticleFileDetails (long? articleId, long? fileId)

Article file details

File by id

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleFileDetailsExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article Unique identifier
            var fileId = 789;  // long? | File Unique identifier

            try
            {
                // Article file details
                PublicFile result = apiInstance.ArticleFileDetails(articleId, fileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleFileDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article Unique identifier | 
 **fileId** | **long?**| File Unique identifier | 

### Return type

[**PublicFile**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articlefiles"></a>
# **ArticleFiles**
> List<PublicFile> ArticleFiles (long? articleId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

List article files

Files list for article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleFilesExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article Unique identifier
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // List article files
                List&lt;PublicFile&gt; result = apiInstance.ArticleFiles(articleId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleFiles: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article Unique identifier | 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List<PublicFile>**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articleversionconfidentiality"></a>
# **ArticleVersionConfidentiality**
> ArticleConfidentiality ArticleVersionConfidentiality (long? articleId, long? versionId)

Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleVersionConfidentialityExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article Unique identifier
            var versionId = 789;  // long? | Version Number

            try
            {
                // Public Article Confidentiality for article version
                ArticleConfidentiality result = apiInstance.ArticleVersionConfidentiality(articleId, versionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionConfidentiality: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article Unique identifier | 
 **versionId** | **long?**| Version Number | 

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articleversiondetails"></a>
# **ArticleVersionDetails**
> ArticleComplete ArticleVersionDetails (long? articleId, long? versionId)

Article details for version

Article with specified version

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleVersionDetailsExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article Unique identifier
            var versionId = 789;  // long? | Article Version Number

            try
            {
                // Article details for version
                ArticleComplete result = apiInstance.ArticleVersionDetails(articleId, versionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article Unique identifier | 
 **versionId** | **long?**| Article Version Number | 

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articleversionembargo"></a>
# **ArticleVersionEmbargo**
> ArticleEmbargo ArticleVersionEmbargo (long? articleId, long? versionId)

Public Article Embargo for article version

Embargo for article version

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleVersionEmbargoExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article Unique identifier
            var versionId = 789;  // long? | Version Number

            try
            {
                // Public Article Embargo for article version
                ArticleEmbargo result = apiInstance.ArticleVersionEmbargo(articleId, versionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionEmbargo: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article Unique identifier | 
 **versionId** | **long?**| Version Number | 

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articleversionfiles"></a>
# **ArticleVersionFiles**
> List<PublicFile> ArticleVersionFiles (long? articleId, long? versionId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

Article version file details

File by version id

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleVersionFilesExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article Unique identifier
            var versionId = 789;  // long? | Article Version Unique identifier
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Article version file details
                List&lt;PublicFile&gt; result = apiInstance.ArticleVersionFiles(articleId, versionId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionFiles: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article Unique identifier | 
 **versionId** | **long?**| Article Version Unique identifier | 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List<PublicFile>**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articleversionpartialupdate"></a>
# **ArticleVersionPartialUpdate**
> LocationWarningsUpdate ArticleVersionPartialUpdate (long? articleId, long? versionId, ArticleVersionUpdate article)

Partially update article version

Partially updating an article version by passing only the fields to change.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleVersionPartialUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var versionId = 789;  // long? | Article version identifier
            var article = new ArticleVersionUpdate(); // ArticleVersionUpdate | Subset of article version fields to update

            try
            {
                // Partially update article version
                LocationWarningsUpdate result = apiInstance.ArticleVersionPartialUpdate(articleId, versionId, article);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionPartialUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **versionId** | **long?**| Article version identifier | 
 **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md)| Subset of article version fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articleversionupdate"></a>
# **ArticleVersionUpdate**
> LocationWarningsUpdate ArticleVersionUpdate (long? articleId, long? versionId, ArticleVersionUpdate article)

Update article version

Updating an article version by passing body parameters.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleVersionUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var versionId = 789;  // long? | Article version identifier
            var article = new ArticleVersionUpdate(); // ArticleVersionUpdate | Article description

            try
            {
                // Update article version
                LocationWarningsUpdate result = apiInstance.ArticleVersionUpdate(articleId, versionId, article);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **versionId** | **long?**| Article version identifier | 
 **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md)| Article description | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articleversionupdatethumb"></a>
# **ArticleVersionUpdateThumb**
> void ArticleVersionUpdateThumb (long? articleId, long? versionId, FileId fileId)

Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleVersionUpdateThumbExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var versionId = 789;  // long? | Article version identifier
            var fileId = new FileId(); // FileId | File ID

            try
            {
                // Update article version thumbnail
                apiInstance.ArticleVersionUpdateThumb(articleId, versionId, fileId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionUpdateThumb: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **versionId** | **long?**| Article version identifier | 
 **fileId** | [**FileId**](FileId.md)| File ID | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articleversions"></a>
# **ArticleVersions**
> List<ArticleVersions> ArticleVersions (long? articleId)

List article versions

List public article versions

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticleVersionsExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article Unique identifier

            try
            {
                // List article versions
                List&lt;ArticleVersions&gt; result = apiInstance.ArticleVersions(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersions: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article Unique identifier | 

### Return type

[**List<ArticleVersions>**](ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articleslist"></a>
# **ArticlesList**
> List<Article> ArticlesList (Guid? xCursor = null, long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string order = null, string orderDirection = null, long? institution = null, string publishedSince = null, string modifiedSince = null, long? group = null, string resourceDoi = null, long? itemType = null, string doi = null, string handle = null)

Public Articles

Returns a list of public articles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticlesListExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var xCursor = new Guid?(); // Guid? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 
            var order = order_example;  // string | The field by which to order. Default varies by endpoint/resource. (optional)  (default to published_date)
            var orderDirection = orderDirection_example;  // string |  (optional)  (default to desc)
            var institution = 789;  // long? | only return articles from this institution (optional) 
            var publishedSince = publishedSince_example;  // string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional) 
            var modifiedSince = modifiedSince_example;  // string | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional) 
            var group = 789;  // long? | only return articles from this group (optional) 
            var resourceDoi = resourceDoi_example;  // string | Deprecated by related materials. Only return articles with this resource_doi (optional) 
            var itemType = 789;  // long? | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional) 
            var doi = doi_example;  // string | only return articles with this doi (optional) 
            var handle = handle_example;  // string | only return articles with this handle (optional) 

            try
            {
                // Public Articles
                List&lt;Article&gt; result = apiInstance.ArticlesList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, modifiedSince, group, resourceDoi, itemType, doi, handle);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticlesList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | [**Guid?**](Guid?.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **orderDirection** | **string**|  | [optional] [default to desc]
 **institution** | **long?**| only return articles from this institution | [optional] 
 **publishedSince** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **modifiedSince** | **string**| Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **group** | **long?**| only return articles from this group | [optional] 
 **resourceDoi** | **string**| Deprecated by related materials. Only return articles with this resource_doi | [optional] 
 **itemType** | **long?**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
 **doi** | **string**| only return articles with this doi | [optional] 
 **handle** | **string**| only return articles with this handle | [optional] 

### Return type

[**List<Article>**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="articlessearch"></a>
# **ArticlesSearch**
> List<ArticleWithProject> ArticlesSearch (Guid? xCursor = null, ArticleSearch search = null)

Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArticlesSearchExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var xCursor = new Guid?(); // Guid? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var search = new ArticleSearch(); // ArticleSearch | Search Parameters (optional) 

            try
            {
                // Public Articles Search
                List&lt;ArticleWithProject&gt; result = apiInstance.ArticlesSearch(xCursor, search);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticlesSearch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | [**Guid?**](Guid?.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **search** | [**ArticleSearch**](ArticleSearch.md)| Search Parameters | [optional] 

### Return type

[**List<ArticleWithProject>**](ArticleWithProject.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleauthordelete"></a>
# **PrivateArticleAuthorDelete**
> void PrivateArticleAuthorDelete (long? articleId, long? authorId)

Delete article author

De-associate author from article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleAuthorDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var authorId = 789;  // long? | Article Author unique identifier

            try
            {
                // Delete article author
                apiInstance.PrivateArticleAuthorDelete(articleId, authorId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **authorId** | **long?**| Article Author unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleauthorsadd"></a>
# **PrivateArticleAuthorsAdd**
> void PrivateArticleAuthorsAdd (long? articleId, AuthorsCreator authors)

Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleAuthorsAddExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var authors = new AuthorsCreator(); // AuthorsCreator | Authors description

            try
            {
                // Add article authors
                apiInstance.PrivateArticleAuthorsAdd(articleId, authors);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorsAdd: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| Authors description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleauthorslist"></a>
# **PrivateArticleAuthorsList**
> List<Author> PrivateArticleAuthorsList (long? articleId)

List article authors

List article authors

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleAuthorsListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // List article authors
                List&lt;Author&gt; result = apiInstance.PrivateArticleAuthorsList(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

[**List<Author>**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleauthorsreplace"></a>
# **PrivateArticleAuthorsReplace**
> void PrivateArticleAuthorsReplace (long? articleId, AuthorsCreator authors)

Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleAuthorsReplaceExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var authors = new AuthorsCreator(); // AuthorsCreator | Authors description

            try
            {
                // Replace article authors
                apiInstance.PrivateArticleAuthorsReplace(articleId, authors);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorsReplace: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| Authors description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlecategoriesadd"></a>
# **PrivateArticleCategoriesAdd**
> void PrivateArticleCategoriesAdd (long? articleId, CategoriesCreator categories)

Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleCategoriesAddExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var categories = new CategoriesCreator(); // CategoriesCreator | 

            try
            {
                // Add article categories
                apiInstance.PrivateArticleCategoriesAdd(articleId, categories);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoriesAdd: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlecategorieslist"></a>
# **PrivateArticleCategoriesList**
> List<Category> PrivateArticleCategoriesList (long? articleId)

List article categories

List article categories

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleCategoriesListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // List article categories
                List&lt;Category&gt; result = apiInstance.PrivateArticleCategoriesList(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoriesList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

[**List<Category>**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlecategoriesreplace"></a>
# **PrivateArticleCategoriesReplace**
> void PrivateArticleCategoriesReplace (long? articleId, CategoriesCreator categories)

Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleCategoriesReplaceExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var categories = new CategoriesCreator(); // CategoriesCreator | 

            try
            {
                // Replace article categories
                apiInstance.PrivateArticleCategoriesReplace(articleId, categories);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoriesReplace: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlecategorydelete"></a>
# **PrivateArticleCategoryDelete**
> void PrivateArticleCategoryDelete (long? articleId, long? categoryId)

Delete article category

De-associate category from article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleCategoryDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var categoryId = 789;  // long? | Category unique identifier

            try
            {
                // Delete article category
                apiInstance.PrivateArticleCategoryDelete(articleId, categoryId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoryDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **categoryId** | **long?**| Category unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleconfidentialitydelete"></a>
# **PrivateArticleConfidentialityDelete**
> void PrivateArticleConfidentialityDelete (long? articleId)

Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleConfidentialityDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // Delete article confidentiality
                apiInstance.PrivateArticleConfidentialityDelete(articleId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleConfidentialityDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleconfidentialitydetails"></a>
# **PrivateArticleConfidentialityDetails**
> ArticleConfidentiality PrivateArticleConfidentialityDetails (long? articleId)

Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleConfidentialityDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // Article confidentiality details
                ArticleConfidentiality result = apiInstance.PrivateArticleConfidentialityDetails(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleConfidentialityDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleconfidentialityupdate"></a>
# **PrivateArticleConfidentialityUpdate**
> void PrivateArticleConfidentialityUpdate (long? articleId, ConfidentialityCreator reason)

Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleConfidentialityUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var reason = new ConfidentialityCreator(); // ConfidentialityCreator | 

            try
            {
                // Update article confidentiality
                apiInstance.PrivateArticleConfidentialityUpdate(articleId, reason);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleConfidentialityUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **reason** | [**ConfidentialityCreator**](ConfidentialityCreator.md)|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlecreate"></a>
# **PrivateArticleCreate**
> LocationWarnings PrivateArticleCreate (ArticleCreate article)

Create new Article

Create a new Article by sending article information

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleCreateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var article = new ArticleCreate(); // ArticleCreate | Article description

            try
            {
                // Create new Article
                LocationWarnings result = apiInstance.PrivateArticleCreate(article);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article** | [**ArticleCreate**](ArticleCreate.md)| Article description | 

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticledelete"></a>
# **PrivateArticleDelete**
> void PrivateArticleDelete (long? articleId)

Delete article

Delete an article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // Delete article
                apiInstance.PrivateArticleDelete(articleId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticledetails"></a>
# **PrivateArticleDetails**
> ArticleCompletePrivate PrivateArticleDetails (long? articleId)

Article details

View a private article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // Article details
                ArticleCompletePrivate result = apiInstance.PrivateArticleDetails(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticledownload"></a>
# **PrivateArticleDownload**
> void PrivateArticleDownload (long? articleId, string folderPath = null)

Private Article Download

Download files from a private article preserving the folder structure

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleDownloadExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var folderPath = folderPath_example;  // string | Folder path to download. If not provided, all files from the article will be downloaded (optional) 

            try
            {
                // Private Article Download
                apiInstance.PrivateArticleDownload(articleId, folderPath);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleDownload: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **folderPath** | **string**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleembargodelete"></a>
# **PrivateArticleEmbargoDelete**
> void PrivateArticleEmbargoDelete (long? articleId)

Delete Article Embargo

Will lift the embargo for the specified article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleEmbargoDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // Delete Article Embargo
                apiInstance.PrivateArticleEmbargoDelete(articleId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleEmbargoDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleembargodetails"></a>
# **PrivateArticleEmbargoDetails**
> ArticleEmbargo PrivateArticleEmbargoDetails (long? articleId)

Article Embargo Details

View a private article embargo details

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleEmbargoDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // Article Embargo Details
                ArticleEmbargo result = apiInstance.PrivateArticleEmbargoDetails(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleEmbargoDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleembargoupdate"></a>
# **PrivateArticleEmbargoUpdate**
> void PrivateArticleEmbargoUpdate (long? articleId, ArticleEmbargoUpdater embargo)

Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleEmbargoUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var embargo = new ArticleEmbargoUpdater(); // ArticleEmbargoUpdater | Embargo description

            try
            {
                // Update Article Embargo
                apiInstance.PrivateArticleEmbargoUpdate(articleId, embargo);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleEmbargoUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **embargo** | [**ArticleEmbargoUpdater**](ArticleEmbargoUpdater.md)| Embargo description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlefile"></a>
# **PrivateArticleFile**
> PrivateFile PrivateArticleFile (long? articleId, long? fileId)

Single File

View details of file for specified article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleFileExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var fileId = 789;  // long? | File unique identifier

            try
            {
                // Single File
                PrivateFile result = apiInstance.PrivateArticleFile(articleId, fileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleFile: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **fileId** | **long?**| File unique identifier | 

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlefiledelete"></a>
# **PrivateArticleFileDelete**
> void PrivateArticleFileDelete (long? articleId, long? fileId)

File Delete

Complete file upload

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleFileDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var fileId = 789;  // long? | File unique identifier

            try
            {
                // File Delete
                apiInstance.PrivateArticleFileDelete(articleId, fileId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleFileDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **fileId** | **long?**| File unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlefileslist"></a>
# **PrivateArticleFilesList**
> List<PrivateFile> PrivateArticleFilesList (long? articleId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

List article files

List private files

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleFilesListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // List article files
                List&lt;PrivateFile&gt; result = apiInstance.PrivateArticleFilesList(articleId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleFilesList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List<PrivateFile>**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlepartialupdate"></a>
# **PrivateArticlePartialUpdate**
> LocationWarningsUpdate PrivateArticlePartialUpdate (long? articleId, ArticleUpdate article)

Partially update article

Partially update an article by sending only the fields to change.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticlePartialUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var article = new ArticleUpdate(); // ArticleUpdate | Subset of article fields to update

            try
            {
                // Partially update article
                LocationWarningsUpdate result = apiInstance.PrivateArticlePartialUpdate(articleId, article);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlePartialUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **article** | [**ArticleUpdate**](ArticleUpdate.md)| Subset of article fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleprivatelink"></a>
# **PrivateArticlePrivateLink**
> List<PrivateLink> PrivateArticlePrivateLink (long? articleId)

List private links

List private links

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticlePrivateLinkExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // List private links
                List&lt;PrivateLink&gt; result = apiInstance.PrivateArticlePrivateLink(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLink: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

[**List<PrivateLink>**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleprivatelinkcreate"></a>
# **PrivateArticlePrivateLinkCreate**
> PrivateLinkResponse PrivateArticlePrivateLinkCreate (long? articleId, PrivateLinkCreator privateLink = null)

Create private link

Create new private link for this article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticlePrivateLinkCreateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var privateLink = new PrivateLinkCreator(); // PrivateLinkCreator |  (optional) 

            try
            {
                // Create private link
                PrivateLinkResponse result = apiInstance.PrivateArticlePrivateLinkCreate(articleId, privateLink);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLinkCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **privateLink** | [**PrivateLinkCreator**](PrivateLinkCreator.md)|  | [optional] 

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleprivatelinkdelete"></a>
# **PrivateArticlePrivateLinkDelete**
> void PrivateArticlePrivateLinkDelete (long? articleId, string linkId)

Disable private link

Disable/delete private link for this article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticlePrivateLinkDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var linkId = linkId_example;  // string | Private link token

            try
            {
                // Disable private link
                apiInstance.PrivateArticlePrivateLinkDelete(articleId, linkId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLinkDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **linkId** | **string**| Private link token | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleprivatelinkupdate"></a>
# **PrivateArticlePrivateLinkUpdate**
> void PrivateArticlePrivateLinkUpdate (long? articleId, string linkId, PrivateLinkCreator privateLink = null)

Update private link

Update existing private link for this article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticlePrivateLinkUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var linkId = linkId_example;  // string | Private link token
            var privateLink = new PrivateLinkCreator(); // PrivateLinkCreator |  (optional) 

            try
            {
                // Update private link
                apiInstance.PrivateArticlePrivateLinkUpdate(articleId, linkId, privateLink);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLinkUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **linkId** | **string**| Private link token | 
 **privateLink** | [**PrivateLinkCreator**](PrivateLinkCreator.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlereservedoi"></a>
# **PrivateArticleReserveDoi**
> ArticleDOI PrivateArticleReserveDoi (long? articleId)

Private Article Reserve DOI

Reserve DOI for article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleReserveDoiExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // Private Article Reserve DOI
                ArticleDOI result = apiInstance.PrivateArticleReserveDoi(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleReserveDoi: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

[**ArticleDOI**](ArticleDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlereservehandle"></a>
# **PrivateArticleReserveHandle**
> ArticleHandle PrivateArticleReserveHandle (long? articleId)

Private Article Reserve Handle

Reserve Handle for article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleReserveHandleExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier

            try
            {
                // Private Article Reserve Handle
                ArticleHandle result = apiInstance.PrivateArticleReserveHandle(articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleReserveHandle: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 

### Return type

[**ArticleHandle**](ArticleHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleresource"></a>
# **PrivateArticleResource**
> Location PrivateArticleResource (long? articleId, Resource resource)

Private Article Resource

Edit article resource data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleResourceExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var resource = new Resource(); // Resource | Resource data

            try
            {
                // Private Article Resource
                Location result = apiInstance.PrivateArticleResource(articleId, resource);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleResource: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **resource** | [**Resource**](Resource.md)| Resource data | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleupdate"></a>
# **PrivateArticleUpdate**
> LocationWarningsUpdate PrivateArticleUpdate (long? articleId, ArticleUpdate article)

Update article

Update an article by passing full body parameters.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var article = new ArticleUpdate(); // ArticleUpdate | Full article representation

            try
            {
                // Update article
                LocationWarningsUpdate result = apiInstance.PrivateArticleUpdate(articleId, article);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **article** | [**ArticleUpdate**](ArticleUpdate.md)| Full article representation | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleuploadcomplete"></a>
# **PrivateArticleUploadComplete**
> void PrivateArticleUploadComplete (long? articleId, long? fileId)

Complete Upload

Complete file upload

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleUploadCompleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var fileId = 789;  // long? | File unique identifier

            try
            {
                // Complete Upload
                apiInstance.PrivateArticleUploadComplete(articleId, fileId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleUploadComplete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **fileId** | **long?**| File unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleuploadinitiate"></a>
# **PrivateArticleUploadInitiate**
> Location PrivateArticleUploadInitiate (long? articleId, FileCreator _file, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticleUploadInitiateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var _file = new FileCreator(); // FileCreator | 
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Initiate Upload
                Location result = apiInstance.PrivateArticleUploadInitiate(articleId, _file, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleUploadInitiate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **_file** | [**FileCreator**](FileCreator.md)|  | 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticleslist"></a>
# **PrivateArticlesList**
> List<Article> PrivateArticlesList (long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

Private Articles

Get Own Articles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticlesListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Private Articles
                List&lt;Article&gt; result = apiInstance.PrivateArticlesList(page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlesList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List<Article>**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatearticlessearch"></a>
# **PrivateArticlesSearch**
> List<ArticleWithProject> PrivateArticlesSearch (PrivateArticleSearch search)

Private Articles search

Returns a list of private articles filtered by the search parameters

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateArticlesSearchExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi();
            var search = new PrivateArticleSearch(); // PrivateArticleSearch | Search Parameters

            try
            {
                // Private Articles search
                List&lt;ArticleWithProject&gt; result = apiInstance.PrivateArticlesSearch(search);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlesSearch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateArticleSearch**](PrivateArticleSearch.md)| Search Parameters | 

### Return type

[**List<ArticleWithProject>**](ArticleWithProject.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="publicarticledownload"></a>
# **PublicArticleDownload**
> void PublicArticleDownload (long? articleId, string folderPath = null)

Public Article Download

Download files from a public article preserving the folder structure

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PublicArticleDownloadExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var folderPath = folderPath_example;  // string | Folder path to download. If not provided, all files from the article will be downloaded (optional) 

            try
            {
                // Public Article Download
                apiInstance.PublicArticleDownload(articleId, folderPath);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PublicArticleDownload: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **folderPath** | **string**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="publicarticleversiondownload"></a>
# **PublicArticleVersionDownload**
> void PublicArticleVersionDownload (long? articleId, long? versionId, string folderPath = null)

Public Article Version Download

Download files from a certain version of an public article preserving the folder structure

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PublicArticleVersionDownloadExample
    {
        public void main()
        {
            var apiInstance = new ArticlesApi();
            var articleId = 789;  // long? | Article unique identifier
            var versionId = 789;  // long? | Version Number
            var folderPath = folderPath_example;  // string | Folder path to download. If not provided, all files from the article will be downloaded (optional) 

            try
            {
                // Public Article Version Download
                apiInstance.PublicArticleVersionDownload(articleId, versionId, folderPath);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArticlesApi.PublicArticleVersionDownload: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **long?**| Article unique identifier | 
 **versionId** | **long?**| Version Number | 
 **folderPath** | **string**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

