# Org.OpenAPITools.Api.ArticlesApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**AccountArticlePublish**](ArticlesApi.md#accountarticlepublish) | **POST** /account/articles/{article_id}/publish | Private Article Publish |
| [**AccountArticleReport**](ArticlesApi.md#accountarticlereport) | **GET** /account/articles/export | Account Article Report |
| [**AccountArticleReportGenerate**](ArticlesApi.md#accountarticlereportgenerate) | **POST** /account/articles/export | Initiate a new Report |
| [**AccountArticleUnpublish**](ArticlesApi.md#accountarticleunpublish) | **POST** /account/articles/{article_id}/unpublish | Public Article Unpublish |
| [**ArticleDetails**](ArticlesApi.md#articledetails) | **GET** /articles/{article_id} | View article details |
| [**ArticleFileDetails**](ArticlesApi.md#articlefiledetails) | **GET** /articles/{article_id}/files/{file_id} | Article file details |
| [**ArticleFiles**](ArticlesApi.md#articlefiles) | **GET** /articles/{article_id}/files | List article files |
| [**ArticleVersionConfidentiality**](ArticlesApi.md#articleversionconfidentiality) | **GET** /articles/{article_id}/versions/{version_id}/confidentiality | Public Article Confidentiality for article version |
| [**ArticleVersionDetails**](ArticlesApi.md#articleversiondetails) | **GET** /articles/{article_id}/versions/{version_id} | Article details for version |
| [**ArticleVersionEmbargo**](ArticlesApi.md#articleversionembargo) | **GET** /articles/{article_id}/versions/{version_id}/embargo | Public Article Embargo for article version |
| [**ArticleVersionFiles**](ArticlesApi.md#articleversionfiles) | **GET** /articles/{article_id}/versions/{version_id}/files | Public Article version files |
| [**ArticleVersionPartialUpdate**](ArticlesApi.md#articleversionpartialupdate) | **PATCH** /account/articles/{article_id}/versions/{version_id} | Partially update article version |
| [**ArticleVersionUpdate**](ArticlesApi.md#articleversionupdate) | **PUT** /account/articles/{article_id}/versions/{version_id} | Update article version |
| [**ArticleVersionUpdateThumb**](ArticlesApi.md#articleversionupdatethumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail |
| [**ArticleVersions**](ArticlesApi.md#articleversions) | **GET** /articles/{article_id}/versions | List article versions |
| [**ArticlesList**](ArticlesApi.md#articleslist) | **GET** /articles | Public Articles |
| [**ArticlesSearch**](ArticlesApi.md#articlessearch) | **POST** /articles/search | Public Articles Search |
| [**PrivateArticleAuthorDelete**](ArticlesApi.md#privatearticleauthordelete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author |
| [**PrivateArticleAuthorsAdd**](ArticlesApi.md#privatearticleauthorsadd) | **POST** /account/articles/{article_id}/authors | Add article authors |
| [**PrivateArticleAuthorsList**](ArticlesApi.md#privatearticleauthorslist) | **GET** /account/articles/{article_id}/authors | List article authors |
| [**PrivateArticleAuthorsReplace**](ArticlesApi.md#privatearticleauthorsreplace) | **PUT** /account/articles/{article_id}/authors | Replace article authors |
| [**PrivateArticleCategoriesAdd**](ArticlesApi.md#privatearticlecategoriesadd) | **POST** /account/articles/{article_id}/categories | Add article categories |
| [**PrivateArticleCategoriesList**](ArticlesApi.md#privatearticlecategorieslist) | **GET** /account/articles/{article_id}/categories | List article categories |
| [**PrivateArticleCategoriesReplace**](ArticlesApi.md#privatearticlecategoriesreplace) | **PUT** /account/articles/{article_id}/categories | Replace article categories |
| [**PrivateArticleCategoryDelete**](ArticlesApi.md#privatearticlecategorydelete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category |
| [**PrivateArticleConfidentialityDelete**](ArticlesApi.md#privatearticleconfidentialitydelete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality |
| [**PrivateArticleConfidentialityDetails**](ArticlesApi.md#privatearticleconfidentialitydetails) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details |
| [**PrivateArticleConfidentialityUpdate**](ArticlesApi.md#privatearticleconfidentialityupdate) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality |
| [**PrivateArticleCreate**](ArticlesApi.md#privatearticlecreate) | **POST** /account/articles | Create new Article |
| [**PrivateArticleDelete**](ArticlesApi.md#privatearticledelete) | **DELETE** /account/articles/{article_id} | Delete article |
| [**PrivateArticleDetails**](ArticlesApi.md#privatearticledetails) | **GET** /account/articles/{article_id} | Article details |
| [**PrivateArticleDownload**](ArticlesApi.md#privatearticledownload) | **GET** /account/articles/{article_id}/download | Private Article Download |
| [**PrivateArticleEmbargoDelete**](ArticlesApi.md#privatearticleembargodelete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo |
| [**PrivateArticleEmbargoDetails**](ArticlesApi.md#privatearticleembargodetails) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details |
| [**PrivateArticleEmbargoUpdate**](ArticlesApi.md#privatearticleembargoupdate) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo |
| [**PrivateArticleFile**](ArticlesApi.md#privatearticlefile) | **GET** /account/articles/{article_id}/files/{file_id} | Single File |
| [**PrivateArticleFileDelete**](ArticlesApi.md#privatearticlefiledelete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete |
| [**PrivateArticleFilesList**](ArticlesApi.md#privatearticlefileslist) | **GET** /account/articles/{article_id}/files | List article files |
| [**PrivateArticlePartialUpdate**](ArticlesApi.md#privatearticlepartialupdate) | **PATCH** /account/articles/{article_id} | Partially update article |
| [**PrivateArticlePrivateLink**](ArticlesApi.md#privatearticleprivatelink) | **GET** /account/articles/{article_id}/private_links | List private links |
| [**PrivateArticlePrivateLinkCreate**](ArticlesApi.md#privatearticleprivatelinkcreate) | **POST** /account/articles/{article_id}/private_links | Create private link |
| [**PrivateArticlePrivateLinkDelete**](ArticlesApi.md#privatearticleprivatelinkdelete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link |
| [**PrivateArticlePrivateLinkUpdate**](ArticlesApi.md#privatearticleprivatelinkupdate) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link |
| [**PrivateArticleReserveDoi**](ArticlesApi.md#privatearticlereservedoi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI |
| [**PrivateArticleReserveHandle**](ArticlesApi.md#privatearticlereservehandle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle |
| [**PrivateArticleResource**](ArticlesApi.md#privatearticleresource) | **POST** /account/articles/{article_id}/resource | Private Article Resource |
| [**PrivateArticleUpdate**](ArticlesApi.md#privatearticleupdate) | **PUT** /account/articles/{article_id} | Update article |
| [**PrivateArticleUploadComplete**](ArticlesApi.md#privatearticleuploadcomplete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload |
| [**PrivateArticleUploadInitiate**](ArticlesApi.md#privatearticleuploadinitiate) | **POST** /account/articles/{article_id}/files | Initiate Upload |
| [**PrivateArticlesList**](ArticlesApi.md#privatearticleslist) | **GET** /account/articles | Private Articles |
| [**PrivateArticlesSearch**](ArticlesApi.md#privatearticlessearch) | **POST** /account/articles/search | Private Articles search |
| [**PublicArticleDownload**](ArticlesApi.md#publicarticledownload) | **GET** /articles/{article_id}/download | Public Article Download |
| [**PublicArticleVersionDownload**](ArticlesApi.md#publicarticleversiondownload) | **GET** /articles/{article_id}/versions/{version_id}/download | Public Article Version Download |

<a id="accountarticlepublish"></a>
# **AccountArticlePublish**
> Location AccountArticlePublish (int articleId)

Private Article Publish

- If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AccountArticlePublishExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // Private Article Publish
                Location result = apiInstance.AccountArticlePublish(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.AccountArticlePublish: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the AccountArticlePublishWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Article Publish
    ApiResponse<Location> response = apiInstance.AccountArticlePublishWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.AccountArticlePublishWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  * Location - Location of project <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="accountarticlereport"></a>
# **AccountArticleReport**
> List&lt;AccountReport&gt; AccountArticleReport (int? groupId = null)

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AccountArticleReportExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var groupId = 56;  // int? | A group ID to filter by (optional) 

            try
            {
                // Account Article Report
                List<AccountReport> result = apiInstance.AccountArticleReport(groupId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.AccountArticleReport: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the AccountArticleReportWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Account Article Report
    ApiResponse<List<AccountReport>> response = apiInstance.AccountArticleReportWithHttpInfo(groupId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.AccountArticleReportWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **groupId** | **int?** | A group ID to filter by | [optional]  |

### Return type

[**List&lt;AccountReport&gt;**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of account report entries |  -  |
| **400** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="accountarticlereportgenerate"></a>
# **AccountArticleReportGenerate**
> AccountReport AccountArticleReportGenerate ()

Initiate a new Report

Initiate a new Article Report for this Account. There is a limit of 1 report per day.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AccountArticleReportGenerateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);

            try
            {
                // Initiate a new Report
                AccountReport result = apiInstance.AccountArticleReportGenerate();
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.AccountArticleReportGenerate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the AccountArticleReportGenerateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Initiate a new Report
    ApiResponse<AccountReport> response = apiInstance.AccountArticleReportGenerateWithHttpInfo();
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.AccountArticleReportGenerateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters
This endpoint does not need any parameter.
### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. AccountReport created. |  -  |
| **429** | Too Many Requests |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="accountarticleunpublish"></a>
# **AccountArticleUnpublish**
> void AccountArticleUnpublish (int articleId, ArticleUnpublishData reason)

Public Article Unpublish

Allows authorized users to unpublish an article.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AccountArticleUnpublishExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var reason = new ArticleUnpublishData(); // ArticleUnpublishData | Article unpublish data

            try
            {
                // Public Article Unpublish
                apiInstance.AccountArticleUnpublish(articleId, reason);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.AccountArticleUnpublish: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the AccountArticleUnpublishWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Article Unpublish
    apiInstance.AccountArticleUnpublishWithHttpInfo(articleId, reason);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.AccountArticleUnpublishWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **reason** | [**ArticleUnpublishData**](ArticleUnpublishData.md) | Article unpublish data |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articledetails"></a>
# **ArticleDetails**
> ArticleComplete ArticleDetails (int articleId)

View article details

View an article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article Unique identifier

            try
            {
                // View article details
                ArticleComplete result = apiInstance.ArticleDetails(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // View article details
    ApiResponse<ArticleComplete> response = apiInstance.ArticleDetailsWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article Unique identifier |  |

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article representation |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articlefiledetails"></a>
# **ArticleFileDetails**
> PublicFile ArticleFileDetails (int articleId, int fileId)

Article file details

File by id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleFileDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article Unique identifier
            var fileId = 56;  // int | File Unique identifier

            try
            {
                // Article file details
                PublicFile result = apiInstance.ArticleFileDetails(articleId, fileId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleFileDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleFileDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Article file details
    ApiResponse<PublicFile> response = apiInstance.ArticleFileDetailsWithHttpInfo(articleId, fileId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleFileDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article Unique identifier |  |
| **fileId** | **int** | File Unique identifier |  |

### Return type

[**PublicFile**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. File representation |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articlefiles"></a>
# **ArticleFiles**
> List&lt;PublicFile&gt; ArticleFiles (int articleId, int? page = null, int? pageSize = null, int? limit = null, int? offset = null)

List article files

Files list for article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleFilesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article Unique identifier
            var page = 56;  // int? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10;  // int? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 56;  // int? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 56;  // int? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // List article files
                List<PublicFile> result = apiInstance.ArticleFiles(articleId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleFiles: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleFilesWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List article files
    ApiResponse<List<PublicFile>> response = apiInstance.ArticleFilesWithHttpInfo(articleId, page, pageSize, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleFilesWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article Unique identifier |  |
| **page** | **int?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **int?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **int?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**List&lt;PublicFile&gt;**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. List of article files |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articleversionconfidentiality"></a>
# **ArticleVersionConfidentiality**
> ArticleConfidentiality ArticleVersionConfidentiality (int articleId, int versionId)

Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleVersionConfidentialityExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article Unique identifier
            var versionId = 56;  // int | Version Number

            try
            {
                // Public Article Confidentiality for article version
                ArticleConfidentiality result = apiInstance.ArticleVersionConfidentiality(articleId, versionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionConfidentiality: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleVersionConfidentialityWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Article Confidentiality for article version
    ApiResponse<ArticleConfidentiality> response = apiInstance.ArticleVersionConfidentialityWithHttpInfo(articleId, versionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleVersionConfidentialityWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article Unique identifier |  |
| **versionId** | **int** | Version Number |  |

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Confidentiality representation |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articleversiondetails"></a>
# **ArticleVersionDetails**
> ArticleComplete ArticleVersionDetails (int articleId, int versionId)

Article details for version

Article with specified version

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleVersionDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article Unique identifier
            var versionId = 56;  // int | Article Version Number

            try
            {
                // Article details for version
                ArticleComplete result = apiInstance.ArticleVersionDetails(articleId, versionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleVersionDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Article details for version
    ApiResponse<ArticleComplete> response = apiInstance.ArticleVersionDetailsWithHttpInfo(articleId, versionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleVersionDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article Unique identifier |  |
| **versionId** | **int** | Article Version Number |  |

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article representation |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articleversionembargo"></a>
# **ArticleVersionEmbargo**
> ArticleEmbargo ArticleVersionEmbargo (int articleId, int versionId)

Public Article Embargo for article version

Embargo for article version

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleVersionEmbargoExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article Unique identifier
            var versionId = 56;  // int | Version Number

            try
            {
                // Public Article Embargo for article version
                ArticleEmbargo result = apiInstance.ArticleVersionEmbargo(articleId, versionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionEmbargo: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleVersionEmbargoWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Article Embargo for article version
    ApiResponse<ArticleEmbargo> response = apiInstance.ArticleVersionEmbargoWithHttpInfo(articleId, versionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleVersionEmbargoWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article Unique identifier |  |
| **versionId** | **int** | Version Number |  |

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Embargo representation |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articleversionfiles"></a>
# **ArticleVersionFiles**
> List&lt;PublicFile&gt; ArticleVersionFiles (int articleId, int versionId, int? page = null, int? pageSize = null, int? limit = null, int? offset = null)

Public Article version files

Article version file details

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleVersionFilesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article Unique identifier
            var versionId = 56;  // int | Article Version Unique identifier
            var page = 56;  // int? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10;  // int? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 56;  // int? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 56;  // int? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Public Article version files
                List<PublicFile> result = apiInstance.ArticleVersionFiles(articleId, versionId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionFiles: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleVersionFilesWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Article version files
    ApiResponse<List<PublicFile>> response = apiInstance.ArticleVersionFilesWithHttpInfo(articleId, versionId, page, pageSize, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleVersionFilesWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article Unique identifier |  |
| **versionId** | **int** | Article Version Unique identifier |  |
| **page** | **int?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **int?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **int?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**List&lt;PublicFile&gt;**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. List of article files |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articleversionpartialupdate"></a>
# **ArticleVersionPartialUpdate**
> LocationWarningsUpdate ArticleVersionPartialUpdate (int articleId, int versionId, ArticleVersionUpdate article)

Partially update article version

Partially updating an article version by passing only the fields to change.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleVersionPartialUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var versionId = 56;  // int | Article version identifier
            var article = new ArticleVersionUpdate(); // ArticleVersionUpdate | Subset of article version fields to update

            try
            {
                // Partially update article version
                LocationWarningsUpdate result = apiInstance.ArticleVersionPartialUpdate(articleId, versionId, article);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionPartialUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleVersionPartialUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Partially update article version
    ApiResponse<LocationWarningsUpdate> response = apiInstance.ArticleVersionPartialUpdateWithHttpInfo(articleId, versionId, article);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleVersionPartialUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **versionId** | **int** | Article version identifier |  |
| **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md) | Subset of article version fields to update |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articleversionupdate"></a>
# **ArticleVersionUpdate**
> LocationWarningsUpdate ArticleVersionUpdate (int articleId, int versionId, ArticleVersionUpdate article)

Update article version

Updating an article version by passing body parameters.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleVersionUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var versionId = 56;  // int | Article version identifier
            var article = new ArticleVersionUpdate(); // ArticleVersionUpdate | Article description

            try
            {
                // Update article version
                LocationWarningsUpdate result = apiInstance.ArticleVersionUpdate(articleId, versionId, article);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleVersionUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update article version
    ApiResponse<LocationWarningsUpdate> response = apiInstance.ArticleVersionUpdateWithHttpInfo(articleId, versionId, article);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleVersionUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **versionId** | **int** | Article version identifier |  |
| **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md) | Article description |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articleversionupdatethumb"></a>
# **ArticleVersionUpdateThumb**
> void ArticleVersionUpdateThumb (int articleId, int versionId, FileId fileId)

Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleVersionUpdateThumbExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var versionId = 56;  // int | Article version identifier
            var fileId = new FileId(); // FileId | File ID

            try
            {
                // Update article version thumbnail
                apiInstance.ArticleVersionUpdateThumb(articleId, versionId, fileId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersionUpdateThumb: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleVersionUpdateThumbWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update article version thumbnail
    apiInstance.ArticleVersionUpdateThumbWithHttpInfo(articleId, versionId, fileId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleVersionUpdateThumbWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **versionId** | **int** | Article version identifier |  |
| **fileId** | [**FileId**](FileId.md) | File ID |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **422** | Unprocessable Entity |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articleversions"></a>
# **ArticleVersions**
> List&lt;ArticleVersions&gt; ArticleVersions (int articleId)

List article versions

List public article versions

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticleVersionsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article Unique identifier

            try
            {
                // List article versions
                List<ArticleVersions> result = apiInstance.ArticleVersions(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticleVersions: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticleVersionsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List article versions
    ApiResponse<List<ArticleVersions>> response = apiInstance.ArticleVersionsWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticleVersionsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article Unique identifier |  |

### Return type

[**List&lt;ArticleVersions&gt;**](ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article version representations |  -  |
| **400** | Bad Request. Article ID must be an integer and bigger than 0. |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articleslist"></a>
# **ArticlesList**
> List&lt;Article&gt; ArticlesList (string? xCursor = null, int? page = null, int? pageSize = null, int? limit = null, int? offset = null, string? order = null, string? orderDirection = null, int? institution = null, string? publishedSince = null, string? modifiedSince = null, int? group = null, string? resourceDoi = null, int? itemType = null, string? doi = null, string? handle = null)

Public Articles

Returns a list of public articles

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticlesListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var xCursor = "xCursor_example";  // string? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var page = 56;  // int? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10;  // int? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 56;  // int? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 56;  // int? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 
            var order = "published_date";  // string? | The field by which to order. Default varies by endpoint/resource. (optional)  (default to published_date)
            var orderDirection = "asc";  // string? |  (optional)  (default to desc)
            var institution = 56;  // int? | only return articles from this institution (optional) 
            var publishedSince = "publishedSince_example";  // string? | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional) 
            var modifiedSince = "modifiedSince_example";  // string? | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional) 
            var group = 56;  // int? | only return articles from this group (optional) 
            var resourceDoi = "resourceDoi_example";  // string? | Deprecated by related materials. Only return articles with this resource_doi (optional) 
            var itemType = 56;  // int? | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional) 
            var doi = "doi_example";  // string? | only return articles with this doi (optional) 
            var handle = "handle_example";  // string? | only return articles with this handle (optional) 

            try
            {
                // Public Articles
                List<Article> result = apiInstance.ArticlesList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, modifiedSince, group, resourceDoi, itemType, doi, handle);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticlesList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticlesListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Articles
    ApiResponse<List<Article>> response = apiInstance.ArticlesListWithHttpInfo(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, modifiedSince, group, resourceDoi, itemType, doi, handle);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticlesListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **xCursor** | **string?** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional]  |
| **page** | **int?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **int?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **int?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |
| **order** | **string?** | The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date] |
| **orderDirection** | **string?** |  | [optional] [default to desc] |
| **institution** | **int?** | only return articles from this institution | [optional]  |
| **publishedSince** | **string?** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional]  |
| **modifiedSince** | **string?** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional]  |
| **group** | **int?** | only return articles from this group | [optional]  |
| **resourceDoi** | **string?** | Deprecated by related materials. Only return articles with this resource_doi | [optional]  |
| **itemType** | **int?** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional]  |
| **doi** | **string?** | only return articles with this doi | [optional]  |
| **handle** | **string?** | only return articles with this handle | [optional]  |

### Return type

[**List&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of articles |  * X-Cursor - Unique hash used for bypassing the item retrieval limit of 9,000 entities. <br>  |
| **400** | Bad Request |  -  |
| **422** | Unprocessable Entity. Syntax is correct but one of the parameters isn&#39;t correctly processed |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="articlessearch"></a>
# **ArticlesSearch**
> List&lt;ArticleWithProject&gt; ArticlesSearch (string? xCursor = null, ArticleSearch? search = null)

Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ArticlesSearchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var xCursor = "xCursor_example";  // string? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var search = new ArticleSearch?(); // ArticleSearch? | Search Parameters (optional) 

            try
            {
                // Public Articles Search
                List<ArticleWithProject> result = apiInstance.ArticlesSearch(xCursor, search);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.ArticlesSearch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ArticlesSearchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Articles Search
    ApiResponse<List<ArticleWithProject>> response = apiInstance.ArticlesSearchWithHttpInfo(xCursor, search);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.ArticlesSearchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **xCursor** | **string?** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional]  |
| **search** | [**ArticleSearch?**](ArticleSearch?.md) | Search Parameters | [optional]  |

### Return type

[**List&lt;ArticleWithProject&gt;**](ArticleWithProject.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of articles |  * X-Cursor - Unique hash used for bypassing the item retrieval limit of 9,000 entities. <br>  |
| **400** | Bad Request |  -  |
| **422** | Unprocessable Entity. Syntax is correct but one of the parameters isn&#39;t correctly processed |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleauthordelete"></a>
# **PrivateArticleAuthorDelete**
> void PrivateArticleAuthorDelete (int articleId, int authorId)

Delete article author

De-associate author from article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleAuthorDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var authorId = 56;  // int | Article Author unique identifier

            try
            {
                // Delete article author
                apiInstance.PrivateArticleAuthorDelete(articleId, authorId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleAuthorDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete article author
    apiInstance.PrivateArticleAuthorDeleteWithHttpInfo(articleId, authorId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **authorId** | **int** | Article Author unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleauthorsadd"></a>
# **PrivateArticleAuthorsAdd**
> void PrivateArticleAuthorsAdd (int articleId, AuthorsCreator authors)

Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleAuthorsAddExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var authors = new AuthorsCreator(); // AuthorsCreator | Authors description

            try
            {
                // Add article authors
                apiInstance.PrivateArticleAuthorsAdd(articleId, authors);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorsAdd: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleAuthorsAddWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Add article authors
    apiInstance.PrivateArticleAuthorsAddWithHttpInfo(articleId, authors);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorsAddWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md) | Authors description |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleauthorslist"></a>
# **PrivateArticleAuthorsList**
> List&lt;Author&gt; PrivateArticleAuthorsList (int articleId)

List article authors

List article authors

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleAuthorsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // List article authors
                List<Author> result = apiInstance.PrivateArticleAuthorsList(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleAuthorsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List article authors
    ApiResponse<List<Author>> response = apiInstance.PrivateArticleAuthorsListWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

[**List&lt;Author&gt;**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Authors list for article |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleauthorsreplace"></a>
# **PrivateArticleAuthorsReplace**
> void PrivateArticleAuthorsReplace (int articleId, AuthorsCreator authors)

Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleAuthorsReplaceExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var authors = new AuthorsCreator(); // AuthorsCreator | Authors description

            try
            {
                // Replace article authors
                apiInstance.PrivateArticleAuthorsReplace(articleId, authors);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorsReplace: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleAuthorsReplaceWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Replace article authors
    apiInstance.PrivateArticleAuthorsReplaceWithHttpInfo(articleId, authors);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleAuthorsReplaceWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md) | Authors description |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request. Article ID must be an integer and bigger than 0. Author with ID Not Found. |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlecategoriesadd"></a>
# **PrivateArticleCategoriesAdd**
> void PrivateArticleCategoriesAdd (int articleId, CategoriesCreator categories)

Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleCategoriesAddExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var categories = new CategoriesCreator(); // CategoriesCreator | 

            try
            {
                // Add article categories
                apiInstance.PrivateArticleCategoriesAdd(articleId, categories);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoriesAdd: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleCategoriesAddWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Add article categories
    apiInstance.PrivateArticleCategoriesAddWithHttpInfo(articleId, categories);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoriesAddWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md) |  |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlecategorieslist"></a>
# **PrivateArticleCategoriesList**
> List&lt;Category&gt; PrivateArticleCategoriesList (int articleId)

List article categories

List article categories

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleCategoriesListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // List article categories
                List<Category> result = apiInstance.PrivateArticleCategoriesList(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoriesList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleCategoriesListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List article categories
    ApiResponse<List<Category>> response = apiInstance.PrivateArticleCategoriesListWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoriesListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

[**List&lt;Category&gt;**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article categories |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlecategoriesreplace"></a>
# **PrivateArticleCategoriesReplace**
> void PrivateArticleCategoriesReplace (int articleId, CategoriesCreator categories)

Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleCategoriesReplaceExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var categories = new CategoriesCreator(); // CategoriesCreator | 

            try
            {
                // Replace article categories
                apiInstance.PrivateArticleCategoriesReplace(articleId, categories);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoriesReplace: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleCategoriesReplaceWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Replace article categories
    apiInstance.PrivateArticleCategoriesReplaceWithHttpInfo(articleId, categories);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoriesReplaceWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md) |  |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlecategorydelete"></a>
# **PrivateArticleCategoryDelete**
> void PrivateArticleCategoryDelete (int articleId, int categoryId)

Delete article category

De-associate category from article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleCategoryDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var categoryId = 56;  // int | Category unique identifier

            try
            {
                // Delete article category
                apiInstance.PrivateArticleCategoryDelete(articleId, categoryId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoryDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleCategoryDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete article category
    apiInstance.PrivateArticleCategoryDeleteWithHttpInfo(articleId, categoryId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleCategoryDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **categoryId** | **int** | Category unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleconfidentialitydelete"></a>
# **PrivateArticleConfidentialityDelete**
> void PrivateArticleConfidentialityDelete (int articleId)

Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleConfidentialityDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // Delete article confidentiality
                apiInstance.PrivateArticleConfidentialityDelete(articleId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleConfidentialityDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleConfidentialityDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete article confidentiality
    apiInstance.PrivateArticleConfidentialityDeleteWithHttpInfo(articleId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleConfidentialityDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleconfidentialitydetails"></a>
# **PrivateArticleConfidentialityDetails**
> ArticleConfidentiality PrivateArticleConfidentialityDetails (int articleId)

Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleConfidentialityDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // Article confidentiality details
                ArticleConfidentiality result = apiInstance.PrivateArticleConfidentialityDetails(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleConfidentialityDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleConfidentialityDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Article confidentiality details
    ApiResponse<ArticleConfidentiality> response = apiInstance.PrivateArticleConfidentialityDetailsWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleConfidentialityDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article categories |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleconfidentialityupdate"></a>
# **PrivateArticleConfidentialityUpdate**
> void PrivateArticleConfidentialityUpdate (int articleId, ConfidentialityCreator reason)

Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleConfidentialityUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var reason = new ConfidentialityCreator(); // ConfidentialityCreator | 

            try
            {
                // Update article confidentiality
                apiInstance.PrivateArticleConfidentialityUpdate(articleId, reason);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleConfidentialityUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleConfidentialityUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update article confidentiality
    apiInstance.PrivateArticleConfidentialityUpdateWithHttpInfo(articleId, reason);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleConfidentialityUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **reason** | [**ConfidentialityCreator**](ConfidentialityCreator.md) |  |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlecreate"></a>
# **PrivateArticleCreate**
> LocationWarnings PrivateArticleCreate (ArticleCreate article)

Create new Article

Create a new Article by sending article information

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleCreateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var article = new ArticleCreate(); // ArticleCreate | Article description

            try
            {
                // Create new Article
                LocationWarnings result = apiInstance.PrivateArticleCreate(article);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleCreate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleCreateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create new Article
    ApiResponse<LocationWarnings> response = apiInstance.PrivateArticleCreateWithHttpInfo(article);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleCreateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **article** | [**ArticleCreate**](ArticleCreate.md) | Article description |  |

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticledelete"></a>
# **PrivateArticleDelete**
> void PrivateArticleDelete (int articleId)

Delete article

Delete an article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // Delete article
                apiInstance.PrivateArticleDelete(articleId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete article
    apiInstance.PrivateArticleDeleteWithHttpInfo(articleId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticledetails"></a>
# **PrivateArticleDetails**
> ArticleCompletePrivate PrivateArticleDetails (int articleId)

Article details

View a private article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // Article details
                ArticleCompletePrivate result = apiInstance.PrivateArticleDetails(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Article details
    ApiResponse<ArticleCompletePrivate> response = apiInstance.PrivateArticleDetailsWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article representation |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticledownload"></a>
# **PrivateArticleDownload**
> void PrivateArticleDownload (int articleId, string? folderPath = null)

Private Article Download

Download files from a private article preserving the folder structure

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleDownloadExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var folderPath = "folderPath_example";  // string? | Folder path to download. If not provided, all files from the article will be downloaded (optional) 

            try
            {
                // Private Article Download
                apiInstance.PrivateArticleDownload(articleId, folderPath);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleDownload: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleDownloadWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Article Download
    apiInstance.PrivateArticleDownloadWithHttpInfo(articleId, folderPath);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleDownloadWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **folderPath** | **string?** | Folder path to download. If not provided, all files from the article will be downloaded | [optional]  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **403** | Insufficient permissions |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleembargodelete"></a>
# **PrivateArticleEmbargoDelete**
> void PrivateArticleEmbargoDelete (int articleId)

Delete Article Embargo

Will lift the embargo for the specified article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleEmbargoDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // Delete Article Embargo
                apiInstance.PrivateArticleEmbargoDelete(articleId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleEmbargoDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleEmbargoDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete Article Embargo
    apiInstance.PrivateArticleEmbargoDeleteWithHttpInfo(articleId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleEmbargoDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleembargodetails"></a>
# **PrivateArticleEmbargoDetails**
> ArticleEmbargo PrivateArticleEmbargoDetails (int articleId)

Article Embargo Details

View a private article embargo details

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleEmbargoDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // Article Embargo Details
                ArticleEmbargo result = apiInstance.PrivateArticleEmbargoDetails(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleEmbargoDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleEmbargoDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Article Embargo Details
    ApiResponse<ArticleEmbargo> response = apiInstance.PrivateArticleEmbargoDetailsWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleEmbargoDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Embargo for article |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleembargoupdate"></a>
# **PrivateArticleEmbargoUpdate**
> void PrivateArticleEmbargoUpdate (int articleId, ArticleEmbargoUpdater embargo)

Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleEmbargoUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var embargo = new ArticleEmbargoUpdater(); // ArticleEmbargoUpdater | Embargo description

            try
            {
                // Update Article Embargo
                apiInstance.PrivateArticleEmbargoUpdate(articleId, embargo);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleEmbargoUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleEmbargoUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update Article Embargo
    apiInstance.PrivateArticleEmbargoUpdateWithHttpInfo(articleId, embargo);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleEmbargoUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **embargo** | [**ArticleEmbargoUpdater**](ArticleEmbargoUpdater.md) | Embargo description |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlefile"></a>
# **PrivateArticleFile**
> PrivateFile PrivateArticleFile (int articleId, int fileId)

Single File

View details of file for specified article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleFileExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var fileId = 56;  // int | File unique identifier

            try
            {
                // Single File
                PrivateFile result = apiInstance.PrivateArticleFile(articleId, fileId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleFile: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleFileWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Single File
    ApiResponse<PrivateFile> response = apiInstance.PrivateArticleFileWithHttpInfo(articleId, fileId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleFileWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **fileId** | **int** | File unique identifier |  |

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article private file |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlefiledelete"></a>
# **PrivateArticleFileDelete**
> void PrivateArticleFileDelete (int articleId, int fileId)

File Delete

Complete file upload

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleFileDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var fileId = 56;  // int | File unique identifier

            try
            {
                // File Delete
                apiInstance.PrivateArticleFileDelete(articleId, fileId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleFileDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleFileDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // File Delete
    apiInstance.PrivateArticleFileDeleteWithHttpInfo(articleId, fileId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleFileDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **fileId** | **int** | File unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlefileslist"></a>
# **PrivateArticleFilesList**
> List&lt;PrivateFile&gt; PrivateArticleFilesList (int articleId, int? page = null, int? pageSize = null, int? limit = null, int? offset = null)

List article files

List private files

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleFilesListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var page = 56;  // int? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10;  // int? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 56;  // int? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 56;  // int? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // List article files
                List<PrivateFile> result = apiInstance.PrivateArticleFilesList(articleId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleFilesList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleFilesListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List article files
    ApiResponse<List<PrivateFile>> response = apiInstance.PrivateArticleFilesListWithHttpInfo(articleId, page, pageSize, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleFilesListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **page** | **int?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **int?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **int?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**List&lt;PrivateFile&gt;**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article files list |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlepartialupdate"></a>
# **PrivateArticlePartialUpdate**
> LocationWarningsUpdate PrivateArticlePartialUpdate (int articleId, ArticleUpdate article)

Partially update article

Partially update an article by sending only the fields to change.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticlePartialUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var article = new ArticleUpdate(); // ArticleUpdate | Subset of article fields to update

            try
            {
                // Partially update article
                LocationWarningsUpdate result = apiInstance.PrivateArticlePartialUpdate(articleId, article);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlePartialUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticlePartialUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Partially update article
    ApiResponse<LocationWarningsUpdate> response = apiInstance.PrivateArticlePartialUpdateWithHttpInfo(articleId, article);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticlePartialUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **article** | [**ArticleUpdate**](ArticleUpdate.md) | Subset of article fields to update |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleprivatelink"></a>
# **PrivateArticlePrivateLink**
> List&lt;PrivateLink&gt; PrivateArticlePrivateLink (int articleId)

List private links

List private links

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticlePrivateLinkExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // List private links
                List<PrivateLink> result = apiInstance.PrivateArticlePrivateLink(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLink: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticlePrivateLinkWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List private links
    ApiResponse<List<PrivateLink>> response = apiInstance.PrivateArticlePrivateLinkWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLinkWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

[**List&lt;PrivateLink&gt;**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article private links |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleprivatelinkcreate"></a>
# **PrivateArticlePrivateLinkCreate**
> PrivateLinkResponse PrivateArticlePrivateLinkCreate (int articleId, PrivateLinkCreator? privateLink = null)

Create private link

Create new private link for this article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticlePrivateLinkCreateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var privateLink = new PrivateLinkCreator?(); // PrivateLinkCreator? |  (optional) 

            try
            {
                // Create private link
                PrivateLinkResponse result = apiInstance.PrivateArticlePrivateLinkCreate(articleId, privateLink);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLinkCreate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticlePrivateLinkCreateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create private link
    ApiResponse<PrivateLinkResponse> response = apiInstance.PrivateArticlePrivateLinkCreateWithHttpInfo(articleId, privateLink);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLinkCreateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **privateLink** | [**PrivateLinkCreator?**](PrivateLinkCreator?.md) |  | [optional]  |

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **422** | Unprocessable Entity |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleprivatelinkdelete"></a>
# **PrivateArticlePrivateLinkDelete**
> void PrivateArticlePrivateLinkDelete (int articleId, string linkId)

Disable private link

Disable/delete private link for this article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticlePrivateLinkDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var linkId = "linkId_example";  // string | Private link token

            try
            {
                // Disable private link
                apiInstance.PrivateArticlePrivateLinkDelete(articleId, linkId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLinkDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticlePrivateLinkDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Disable private link
    apiInstance.PrivateArticlePrivateLinkDeleteWithHttpInfo(articleId, linkId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLinkDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **linkId** | **string** | Private link token |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleprivatelinkupdate"></a>
# **PrivateArticlePrivateLinkUpdate**
> void PrivateArticlePrivateLinkUpdate (int articleId, string linkId, PrivateLinkCreator? privateLink = null)

Update private link

Update existing private link for this article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticlePrivateLinkUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var linkId = "linkId_example";  // string | Private link token
            var privateLink = new PrivateLinkCreator?(); // PrivateLinkCreator? |  (optional) 

            try
            {
                // Update private link
                apiInstance.PrivateArticlePrivateLinkUpdate(articleId, linkId, privateLink);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLinkUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticlePrivateLinkUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update private link
    apiInstance.PrivateArticlePrivateLinkUpdateWithHttpInfo(articleId, linkId, privateLink);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticlePrivateLinkUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **linkId** | **string** | Private link token |  |
| **privateLink** | [**PrivateLinkCreator?**](PrivateLinkCreator?.md) |  | [optional]  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **422** | Unprocessable Entity |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlereservedoi"></a>
# **PrivateArticleReserveDoi**
> ArticleDOI PrivateArticleReserveDoi (int articleId)

Private Article Reserve DOI

Reserve DOI for article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleReserveDoiExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // Private Article Reserve DOI
                ArticleDOI result = apiInstance.PrivateArticleReserveDoi(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleReserveDoi: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleReserveDoiWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Article Reserve DOI
    ApiResponse<ArticleDOI> response = apiInstance.PrivateArticleReserveDoiWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleReserveDoiWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

[**ArticleDOI**](ArticleDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlereservehandle"></a>
# **PrivateArticleReserveHandle**
> ArticleHandle PrivateArticleReserveHandle (int articleId)

Private Article Reserve Handle

Reserve Handle for article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleReserveHandleExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier

            try
            {
                // Private Article Reserve Handle
                ArticleHandle result = apiInstance.PrivateArticleReserveHandle(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleReserveHandle: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleReserveHandleWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Article Reserve Handle
    ApiResponse<ArticleHandle> response = apiInstance.PrivateArticleReserveHandleWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleReserveHandleWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |

### Return type

[**ArticleHandle**](ArticleHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleresource"></a>
# **PrivateArticleResource**
> Location PrivateArticleResource (int articleId, Resource resource)

Private Article Resource

Edit article resource data.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleResourceExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var resource = new Resource(); // Resource | Resource data

            try
            {
                // Private Article Resource
                Location result = apiInstance.PrivateArticleResource(articleId, resource);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleResource: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleResourceWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Article Resource
    ApiResponse<Location> response = apiInstance.PrivateArticleResourceWithHttpInfo(articleId, resource);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleResourceWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **resource** | [**Resource**](Resource.md) | Resource data |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **422** | Unprocessable Entity |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleupdate"></a>
# **PrivateArticleUpdate**
> LocationWarningsUpdate PrivateArticleUpdate (int articleId, ArticleUpdate article)

Update article

Update an article by passing full body parameters.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var article = new ArticleUpdate(); // ArticleUpdate | Full article representation

            try
            {
                // Update article
                LocationWarningsUpdate result = apiInstance.PrivateArticleUpdate(articleId, article);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update article
    ApiResponse<LocationWarningsUpdate> response = apiInstance.PrivateArticleUpdateWithHttpInfo(articleId, article);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **article** | [**ArticleUpdate**](ArticleUpdate.md) | Full article representation |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleuploadcomplete"></a>
# **PrivateArticleUploadComplete**
> void PrivateArticleUploadComplete (int articleId, int fileId)

Complete Upload

Complete file upload

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleUploadCompleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var fileId = 56;  // int | File unique identifier

            try
            {
                // Complete Upload
                apiInstance.PrivateArticleUploadComplete(articleId, fileId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleUploadComplete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleUploadCompleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Complete Upload
    apiInstance.PrivateArticleUploadCompleteWithHttpInfo(articleId, fileId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleUploadCompleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **fileId** | **int** | File unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **202** | Accepted |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleuploadinitiate"></a>
# **PrivateArticleUploadInitiate**
> Location PrivateArticleUploadInitiate (int articleId, FileCreator file, int? page = null, int? pageSize = null, int? limit = null, int? offset = null)

Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticleUploadInitiateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var file = new FileCreator(); // FileCreator | 
            var page = 56;  // int? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10;  // int? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 56;  // int? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 56;  // int? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Initiate Upload
                Location result = apiInstance.PrivateArticleUploadInitiate(articleId, file, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticleUploadInitiate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticleUploadInitiateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Initiate Upload
    ApiResponse<Location> response = apiInstance.PrivateArticleUploadInitiateWithHttpInfo(articleId, file, page, pageSize, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticleUploadInitiateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **file** | [**FileCreator**](FileCreator.md) |  |  |
| **page** | **int?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **int?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **int?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **422** | Unprocessable Entity. Parameters missing or incorrect |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticleslist"></a>
# **PrivateArticlesList**
> List&lt;Article&gt; PrivateArticlesList (int? page = null, int? pageSize = null, int? limit = null, int? offset = null)

Private Articles

Get Own Articles

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticlesListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var page = 56;  // int? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10;  // int? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 56;  // int? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 56;  // int? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Private Articles
                List<Article> result = apiInstance.PrivateArticlesList(page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlesList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticlesListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Articles
    ApiResponse<List<Article>> response = apiInstance.PrivateArticlesListWithHttpInfo(page, pageSize, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticlesListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **page** | **int?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **int?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **int?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**List&lt;Article&gt;**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of articles belonging to the account |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatearticlessearch"></a>
# **PrivateArticlesSearch**
> List&lt;ArticleWithProject&gt; PrivateArticlesSearch (PrivateArticleSearch search)

Private Articles search

Returns a list of private articles filtered by the search parameters

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateArticlesSearchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ArticlesApi(config);
            var search = new PrivateArticleSearch(); // PrivateArticleSearch | Search Parameters

            try
            {
                // Private Articles search
                List<ArticleWithProject> result = apiInstance.PrivateArticlesSearch(search);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PrivateArticlesSearch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateArticlesSearchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Articles search
    ApiResponse<List<ArticleWithProject>> response = apiInstance.PrivateArticlesSearchWithHttpInfo(search);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PrivateArticlesSearchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **search** | [**PrivateArticleSearch**](PrivateArticleSearch.md) | Search Parameters |  |

### Return type

[**List&lt;ArticleWithProject&gt;**](ArticleWithProject.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of articles |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="publicarticledownload"></a>
# **PublicArticleDownload**
> void PublicArticleDownload (int articleId, string? folderPath = null)

Public Article Download

Download files from a public article preserving the folder structure

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PublicArticleDownloadExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var folderPath = "folderPath_example";  // string? | Folder path to download. If not provided, all files from the article will be downloaded (optional) 

            try
            {
                // Public Article Download
                apiInstance.PublicArticleDownload(articleId, folderPath);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PublicArticleDownload: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PublicArticleDownloadWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Article Download
    apiInstance.PublicArticleDownloadWithHttpInfo(articleId, folderPath);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PublicArticleDownloadWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **folderPath** | **string?** | Folder path to download. If not provided, all files from the article will be downloaded | [optional]  |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="publicarticleversiondownload"></a>
# **PublicArticleVersionDownload**
> void PublicArticleVersionDownload (int articleId, int versionId, string? folderPath = null)

Public Article Version Download

Download files from a certain version of an public article preserving the folder structure

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PublicArticleVersionDownloadExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new ArticlesApi(config);
            var articleId = 56;  // int | Article unique identifier
            var versionId = 56;  // int | Version Number
            var folderPath = "folderPath_example";  // string? | Folder path to download. If not provided, all files from the article will be downloaded (optional) 

            try
            {
                // Public Article Version Download
                apiInstance.PublicArticleVersionDownload(articleId, versionId, folderPath);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ArticlesApi.PublicArticleVersionDownload: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PublicArticleVersionDownloadWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Article Version Download
    apiInstance.PublicArticleVersionDownloadWithHttpInfo(articleId, versionId, folderPath);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ArticlesApi.PublicArticleVersionDownloadWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article unique identifier |  |
| **versionId** | **int** | Version Number |  |
| **folderPath** | **string?** | Folder path to download. If not provided, all files from the article will be downloaded | [optional]  |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

