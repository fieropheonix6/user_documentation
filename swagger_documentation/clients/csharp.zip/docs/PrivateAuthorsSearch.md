# IO.Swagger.Model.PrivateAuthorsSearch
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SearchFor** | **string** | Search term | [optional] 
**Page** | **long?** | Page number. Used for pagination with page_size | [optional] 
**PageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**Limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional] 
**Offset** | **long?** | Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
**InstitutionId** | **long?** | Return only authors associated to this institution | [optional] 
**Orcid** | **string** | Orcid of author | [optional] 
**GroupId** | **long?** | Return only authors in this group or subgroups of the group | [optional] 
**IsActive** | **bool?** | Return only active authors if True | [optional] 
**IsPublic** | **bool?** | Return only authors that have published items if True | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

