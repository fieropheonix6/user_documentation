# IO.Swagger.Model.PublicFileWithFolder
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Files** | [**List&lt;PublicFile&gt;**](PublicFile.md) | List of files with folder information. | 
**FolderStructure** | **Object** | Mapping of file ids to folder paths, if folders are used | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

