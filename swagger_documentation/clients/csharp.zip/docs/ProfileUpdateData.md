# IO.Swagger.Model.ProfileUpdateData
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstName** | **string** | First name | [optional] 
**LastName** | **string** | Last Name | [optional] 
**Orcid** | **string** | User ORCID | [optional] 
**JobTitle** | **string** | User job title | [optional] 
**FieldsOfInterest** | **List&lt;long?&gt;** | User fields of interest (category ids) | [optional] 
**FieldsOfInterestBySourceId** | **List&lt;string&gt;** | User fields of interest (category source IDs), supersedes the fields_of_interest property | [optional] 
**Location** | **string** | User location | [optional] 
**Facebook** | **string** | User facebook URL | [optional] 
**X** | **string** | User X (twitter) URL | [optional] 
**Linkedin** | **string** | User linkedin URL | [optional] 
**Bio** | **string** | User biographical information | [optional] 
**PersonalProfiles** | [**List&lt;ProfileUpdateDataPersonalProfiles&gt;**](ProfileUpdateDataPersonalProfiles.md) | Add up to 10 additional personal profile links | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

