# IO.Swagger.Api.ProfilesApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**UpdateUserProfile**](ProfilesApi.md#updateuserprofile) | **PUT** /account/profile | Update public profile
[**UpdateUserProfilePicture**](ProfilesApi.md#updateuserprofilepicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture


<a name="updateuserprofile"></a>
# **UpdateUserProfile**
> Object UpdateUserProfile (ProfileUpdateData userProfileData, long? userId = null, string institutionUserId = null)

Update public profile

Updates the fields of the user's public profile.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateUserProfileExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProfilesApi();
            var userProfileData = new ProfileUpdateData(); // ProfileUpdateData | 
            var userId = 789;  // long? | User ID (optional) 
            var institutionUserId = institutionUserId_example;  // string | Institutional user ID (optional) 

            try
            {
                // Update public profile
                Object result = apiInstance.UpdateUserProfile(userProfileData, userId, institutionUserId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProfilesApi.UpdateUserProfile: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userProfileData** | [**ProfileUpdateData**](ProfileUpdateData.md)|  | 
 **userId** | **long?**| User ID | [optional] 
 **institutionUserId** | **string**| Institutional user ID | [optional] 

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="updateuserprofilepicture"></a>
# **UpdateUserProfilePicture**
> Object UpdateUserProfilePicture (long? userId, System.IO.Stream profilePicture)

Update public profile picture

Updates the profile picture of the user's public profile.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateUserProfilePictureExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProfilesApi();
            var userId = 789;  // long? | User ID
            var profilePicture = new System.IO.Stream(); // System.IO.Stream | User profile picture

            try
            {
                // Update public profile picture
                Object result = apiInstance.UpdateUserProfilePicture(userId, profilePicture);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProfilesApi.UpdateUserProfilePicture: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **long?**| User ID | 
 **profilePicture** | **System.IO.Stream**| User profile picture | 

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

