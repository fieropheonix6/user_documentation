# IO.Swagger.Model.CurationDetail
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Status** | **string** | The status of the review. | 
**Id** | **long?** | The review id | 
**GroupId** | **long?** | The group in which the article is present. | 
**AccountId** | **long?** | The ID of the account of the owner of the article of this review. | 
**AssignedTo** | **long?** | The ID of the account to which this review is assigned. | 
**ArticleId** | **long?** | The ID of the article of this review. | 
**Version** | **long?** | The Version number of the article in review. | 
**CommentsCount** | **long?** | The number of comments in the review. | 
**CreatedDate** | **string** | The creation date of the review. | 
**ModifiedDate** | **string** | The date the review has been modified. | 
**RequestNumber** | **long?** | The request number of the review. | 
**ResolutionComment** | **string** | The resolution comment of the review. | 
**Item** | [**ArticleComplete**](ArticleComplete.md) | Article details | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

