# IO.Swagger.Model.CreateOAuthToken
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClientId** | **string** |  | 
**ClientSecret** | **string** |  | 
**GrantType** | **string** |  | 
**Code** | **string** | Required if grant_type is &#39;authorization_code&#39; | [optional] 
**RefreshToken** | **string** | Required if grant_type is &#39;refresh_token&#39; | [optional] 
**Username** | **string** | Required if grant_type is &#39;password&#39; | [optional] 
**Password** | **string** | Required if grant_type is &#39;password&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

