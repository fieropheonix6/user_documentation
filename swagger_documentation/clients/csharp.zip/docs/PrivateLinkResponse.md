# IO.Swagger.Model.PrivateLinkResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Location** | **string** | Url for private link | 
**HtmlLocation** | **string** | HTML url for private link | 
**Token** | **string** | Token for private link | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

