# Org.OpenAPITools.Model.UploadFilePart

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PartNo** | **int** | File part id | [optional] 
**StartOffset** | **int** | Indexes on byte range. zero-based and inclusive | [optional] 
**EndOffset** | **int** | Indexes on byte range. zero-based and inclusive | [optional] 
**Status** | **string** | part status | [optional] 
**Locked** | **bool** | When a part is being uploaded it is being locked, by setting the locked flag to true. No changes/uploads can happen on this part from other requests. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

