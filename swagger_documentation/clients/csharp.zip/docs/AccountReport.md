# Org.OpenAPITools.Model.AccountReport

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | A unique ID for the AccountRecord | 
**AccountId** | **int** | The ID of the account which generated this report. | 
**CreatedDate** | **string** | Date when the AccountReport was requested | 
**Status** | **string** | Status of the report | 
**DownloadUrl** | **string** | The download link for the generated XLSX | 
**GroupId** | **int** | The group ID that was used to filter the report, if any. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

