# Org.OpenAPITools.Model.ProjectComplete

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Funding** | **string** | Project funding | 
**FundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information | 
**Description** | **string** | Project description | 
**Collaborators** | [**List&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators | 
**CustomFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | Project custom fields | 
**ModifiedDate** | **string** | Date when project was last modified | 
**CreatedDate** | **string** | Date when project was created | 
**Url** | **string** | Api endpoint | 
**Id** | **int** | Project id | 
**Title** | **string** | Project title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

