# IO.Swagger.Api.AuthorsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PrivateAuthorDetails**](AuthorsApi.md#privateauthordetails) | **GET** /account/authors/{author_id} | Author details
[**PrivateAuthorsSearch**](AuthorsApi.md#privateauthorssearch) | **POST** /account/authors/search | Search Authors


<a name="privateauthordetails"></a>
# **PrivateAuthorDetails**
> AuthorComplete PrivateAuthorDetails (long? authorId)

Author details

View author details

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateAuthorDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new AuthorsApi();
            var authorId = 789;  // long? | Author unique identifier

            try
            {
                // Author details
                AuthorComplete result = apiInstance.PrivateAuthorDetails(authorId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthorsApi.PrivateAuthorDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorId** | **long?**| Author unique identifier | 

### Return type

[**AuthorComplete**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateauthorssearch"></a>
# **PrivateAuthorsSearch**
> List<AuthorComplete> PrivateAuthorsSearch (PrivateAuthorsSearch search = null)

Search Authors

Search for authors

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateAuthorsSearchExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new AuthorsApi();
            var search = new PrivateAuthorsSearch(); // PrivateAuthorsSearch | Search Parameters (optional) 

            try
            {
                // Search Authors
                List&lt;AuthorComplete&gt; result = apiInstance.PrivateAuthorsSearch(search);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthorsApi.PrivateAuthorsSearch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateAuthorsSearch**](PrivateAuthorsSearch.md)| Search Parameters | [optional] 

### Return type

[**List<AuthorComplete>**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

