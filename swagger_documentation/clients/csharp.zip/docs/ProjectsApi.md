# IO.Swagger.Api.ProjectsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PrivateProjectArticleDelete**](ProjectsApi.md#privateprojectarticledelete) | **DELETE** /account/projects/{project_id}/articles/{article_id} | Delete project article
[**PrivateProjectArticleDetails**](ProjectsApi.md#privateprojectarticledetails) | **GET** /account/projects/{project_id}/articles/{article_id} | Project article details
[**PrivateProjectArticleFile**](ProjectsApi.md#privateprojectarticlefile) | **GET** /account/projects/{project_id}/articles/{article_id}/files/{file_id} | Project article file details
[**PrivateProjectArticleFiles**](ProjectsApi.md#privateprojectarticlefiles) | **GET** /account/projects/{project_id}/articles/{article_id}/files | Project article list files
[**PrivateProjectArticlesCreate**](ProjectsApi.md#privateprojectarticlescreate) | **POST** /account/projects/{project_id}/articles | Create project article
[**PrivateProjectArticlesList**](ProjectsApi.md#privateprojectarticleslist) | **GET** /account/projects/{project_id}/articles | List project articles
[**PrivateProjectCollaboratorDelete**](ProjectsApi.md#privateprojectcollaboratordelete) | **DELETE** /account/projects/{project_id}/collaborators/{user_id} | Remove project collaborator
[**PrivateProjectCollaboratorsInvite**](ProjectsApi.md#privateprojectcollaboratorsinvite) | **POST** /account/projects/{project_id}/collaborators | Invite project collaborators
[**PrivateProjectCollaboratorsList**](ProjectsApi.md#privateprojectcollaboratorslist) | **GET** /account/projects/{project_id}/collaborators | List project collaborators
[**PrivateProjectCreate**](ProjectsApi.md#privateprojectcreate) | **POST** /account/projects | Create project
[**PrivateProjectDelete**](ProjectsApi.md#privateprojectdelete) | **DELETE** /account/projects/{project_id} | Delete project
[**PrivateProjectDetails**](ProjectsApi.md#privateprojectdetails) | **GET** /account/projects/{project_id} | View project details
[**PrivateProjectLeave**](ProjectsApi.md#privateprojectleave) | **POST** /account/projects/{project_id}/leave | Private Project Leave
[**PrivateProjectNote**](ProjectsApi.md#privateprojectnote) | **GET** /account/projects/{project_id}/notes/{note_id} | Project note details
[**PrivateProjectNoteDelete**](ProjectsApi.md#privateprojectnotedelete) | **DELETE** /account/projects/{project_id}/notes/{note_id} | Delete project note
[**PrivateProjectNoteUpdate**](ProjectsApi.md#privateprojectnoteupdate) | **PUT** /account/projects/{project_id}/notes/{note_id} | Update project note
[**PrivateProjectNotesCreate**](ProjectsApi.md#privateprojectnotescreate) | **POST** /account/projects/{project_id}/notes | Create project note
[**PrivateProjectNotesList**](ProjectsApi.md#privateprojectnoteslist) | **GET** /account/projects/{project_id}/notes | List project notes
[**PrivateProjectPublish**](ProjectsApi.md#privateprojectpublish) | **POST** /account/projects/{project_id}/publish | Private Project Publish
[**PrivateProjectUpdate**](ProjectsApi.md#privateprojectupdate) | **PUT** /account/projects/{project_id} | Update project
[**PrivateProjectsList**](ProjectsApi.md#privateprojectslist) | **GET** /account/projects | Private Projects
[**PrivateProjectsSearch**](ProjectsApi.md#privateprojectssearch) | **POST** /account/projects/search | Private Projects search
[**ProjectArticles**](ProjectsApi.md#projectarticles) | **GET** /projects/{project_id}/articles | Public Project Articles
[**ProjectDetails**](ProjectsApi.md#projectdetails) | **GET** /projects/{project_id} | Public Project
[**ProjectsList**](ProjectsApi.md#projectslist) | **GET** /projects | Public Projects
[**ProjectsSearch**](ProjectsApi.md#projectssearch) | **POST** /projects/search | Public Projects Search


<a name="privateprojectarticledelete"></a>
# **PrivateProjectArticleDelete**
> void PrivateProjectArticleDelete (long? projectId, long? articleId)

Delete project article

Delete project article

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectArticleDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var articleId = 789;  // long? | Project Article unique identifier

            try
            {
                // Delete project article
                apiInstance.PrivateProjectArticleDelete(projectId, articleId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **articleId** | **long?**| Project Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectarticledetails"></a>
# **PrivateProjectArticleDetails**
> ProjectArticle PrivateProjectArticleDetails (long? projectId, long? articleId)

Project article details

Project article details

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectArticleDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var articleId = 789;  // long? | Project Article unique identifier

            try
            {
                // Project article details
                ProjectArticle result = apiInstance.PrivateProjectArticleDetails(projectId, articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **articleId** | **long?**| Project Article unique identifier | 

### Return type

[**ProjectArticle**](ProjectArticle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectarticlefile"></a>
# **PrivateProjectArticleFile**
> PrivateFile PrivateProjectArticleFile (long? projectId, long? articleId, long? fileId)

Project article file details

Project article file details

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectArticleFileExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var articleId = 789;  // long? | Project Article unique identifier
            var fileId = 789;  // long? | File unique identifier

            try
            {
                // Project article file details
                PrivateFile result = apiInstance.PrivateProjectArticleFile(projectId, articleId, fileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleFile: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **articleId** | **long?**| Project Article unique identifier | 
 **fileId** | **long?**| File unique identifier | 

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectarticlefiles"></a>
# **PrivateProjectArticleFiles**
> List<PrivateFile> PrivateProjectArticleFiles (long? projectId, long? articleId)

Project article list files

List article files

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectArticleFilesExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var articleId = 789;  // long? | Project Article unique identifier

            try
            {
                // Project article list files
                List&lt;PrivateFile&gt; result = apiInstance.PrivateProjectArticleFiles(projectId, articleId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleFiles: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **articleId** | **long?**| Project Article unique identifier | 

### Return type

[**List<PrivateFile>**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectarticlescreate"></a>
# **PrivateProjectArticlesCreate**
> Location PrivateProjectArticlesCreate (long? projectId, ArticleProjectCreate article)

Create project article

Create a new Article and associate it with this project

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectArticlesCreateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var article = new ArticleProjectCreate(); // ArticleProjectCreate | Article description

            try
            {
                // Create project article
                Location result = apiInstance.PrivateProjectArticlesCreate(projectId, article);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticlesCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **article** | [**ArticleProjectCreate**](ArticleProjectCreate.md)| Article description | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectarticleslist"></a>
# **PrivateProjectArticlesList**
> List<PrivateProjectArticle> PrivateProjectArticlesList (long? projectId)

List project articles

List project articles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectArticlesListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier

            try
            {
                // List project articles
                List&lt;PrivateProjectArticle&gt; result = apiInstance.PrivateProjectArticlesList(projectId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticlesList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 

### Return type

[**List<PrivateProjectArticle>**](PrivateProjectArticle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectcollaboratordelete"></a>
# **PrivateProjectCollaboratorDelete**
> void PrivateProjectCollaboratorDelete (long? projectId, long? userId)

Remove project collaborator

Remove project collaborator

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectCollaboratorDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var userId = 789;  // long? | User unique identifier

            try
            {
                // Remove project collaborator
                apiInstance.PrivateProjectCollaboratorDelete(projectId, userId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectCollaboratorDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **userId** | **long?**| User unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectcollaboratorsinvite"></a>
# **PrivateProjectCollaboratorsInvite**
> ResponseMessage PrivateProjectCollaboratorsInvite (long? projectId, ProjectCollaboratorInvite collaborator)

Invite project collaborators

Invite users to collaborate on project or view the project

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectCollaboratorsInviteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var collaborator = new ProjectCollaboratorInvite(); // ProjectCollaboratorInvite | viewer or collaborator role. User user_id or email of user

            try
            {
                // Invite project collaborators
                ResponseMessage result = apiInstance.PrivateProjectCollaboratorsInvite(projectId, collaborator);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectCollaboratorsInvite: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **collaborator** | [**ProjectCollaboratorInvite**](ProjectCollaboratorInvite.md)| viewer or collaborator role. User user_id or email of user | 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectcollaboratorslist"></a>
# **PrivateProjectCollaboratorsList**
> List<ProjectCollaborator> PrivateProjectCollaboratorsList (long? projectId)

List project collaborators

List Project collaborators and invited users

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectCollaboratorsListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier

            try
            {
                // List project collaborators
                List&lt;ProjectCollaborator&gt; result = apiInstance.PrivateProjectCollaboratorsList(projectId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectCollaboratorsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 

### Return type

[**List<ProjectCollaborator>**](ProjectCollaborator.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectcreate"></a>
# **PrivateProjectCreate**
> CreateProjectResponse PrivateProjectCreate (ProjectCreate project)

Create project

Create a new project

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectCreateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var project = new ProjectCreate(); // ProjectCreate | Project  description

            try
            {
                // Create project
                CreateProjectResponse result = apiInstance.PrivateProjectCreate(project);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project** | [**ProjectCreate**](ProjectCreate.md)| Project  description | 

### Return type

[**CreateProjectResponse**](CreateProjectResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectdelete"></a>
# **PrivateProjectDelete**
> void PrivateProjectDelete (long? projectId)

Delete project

A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier

            try
            {
                // Delete project
                apiInstance.PrivateProjectDelete(projectId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectdetails"></a>
# **PrivateProjectDetails**
> ProjectCompletePrivate PrivateProjectDetails (long? projectId)

View project details

View a private project

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier

            try
            {
                // View project details
                ProjectCompletePrivate result = apiInstance.PrivateProjectDetails(projectId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 

### Return type

[**ProjectCompletePrivate**](ProjectCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectleave"></a>
# **PrivateProjectLeave**
> void PrivateProjectLeave (long? projectId)

Private Project Leave

Please note: project's owner cannot leave the project.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectLeaveExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier

            try
            {
                // Private Project Leave
                apiInstance.PrivateProjectLeave(projectId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectLeave: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectnote"></a>
# **PrivateProjectNote**
> ProjectNotePrivate PrivateProjectNote (long? projectId, long? noteId)

Project note details

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectNoteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var noteId = 789;  // long? | Note unique identifier

            try
            {
                // Project note details
                ProjectNotePrivate result = apiInstance.PrivateProjectNote(projectId, noteId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectNote: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **noteId** | **long?**| Note unique identifier | 

### Return type

[**ProjectNotePrivate**](ProjectNotePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectnotedelete"></a>
# **PrivateProjectNoteDelete**
> void PrivateProjectNoteDelete (long? projectId, long? noteId)

Delete project note

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectNoteDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var noteId = 789;  // long? | Note unique identifier

            try
            {
                // Delete project note
                apiInstance.PrivateProjectNoteDelete(projectId, noteId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectNoteDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **noteId** | **long?**| Note unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectnoteupdate"></a>
# **PrivateProjectNoteUpdate**
> void PrivateProjectNoteUpdate (long? projectId, long? noteId, ProjectNoteCreate note)

Update project note

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectNoteUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var noteId = 789;  // long? | Note unique identifier
            var note = new ProjectNoteCreate(); // ProjectNoteCreate | Note message

            try
            {
                // Update project note
                apiInstance.PrivateProjectNoteUpdate(projectId, noteId, note);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectNoteUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **noteId** | **long?**| Note unique identifier | 
 **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md)| Note message | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectnotescreate"></a>
# **PrivateProjectNotesCreate**
> Location PrivateProjectNotesCreate (long? projectId, ProjectNoteCreate note)

Create project note

Create a new project note

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectNotesCreateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var note = new ProjectNoteCreate(); // ProjectNoteCreate | Note message

            try
            {
                // Create project note
                Location result = apiInstance.PrivateProjectNotesCreate(projectId, note);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectNotesCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md)| Note message | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectnoteslist"></a>
# **PrivateProjectNotesList**
> List<ProjectNote> PrivateProjectNotesList (long? projectId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

List project notes

List project notes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectNotesListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing(the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // List project notes
                List&lt;ProjectNote&gt; result = apiInstance.PrivateProjectNotesList(projectId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectNotesList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List<ProjectNote>**](ProjectNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectpublish"></a>
# **PrivateProjectPublish**
> ResponseMessage PrivateProjectPublish (long? projectId)

Private Project Publish

Publish a project. Possible after all items inside it are public

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectPublishExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier

            try
            {
                // Private Project Publish
                ResponseMessage result = apiInstance.PrivateProjectPublish(projectId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectPublish: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectupdate"></a>
# **PrivateProjectUpdate**
> void PrivateProjectUpdate (long? projectId, ProjectUpdate project)

Update project

Updating an project by passing body parameters; request can also be made with the PATCH method.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project unique identifier
            var project = new ProjectUpdate(); // ProjectUpdate | Project description

            try
            {
                // Update project
                apiInstance.PrivateProjectUpdate(projectId, project);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project unique identifier | 
 **project** | [**ProjectUpdate**](ProjectUpdate.md)| Project description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectslist"></a>
# **PrivateProjectsList**
> List<ProjectPrivate> PrivateProjectsList (long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string order = null, string orderDirection = null, string storage = null, string roles = null)

Private Projects

List private projects

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectsListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi();
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing(the offset of the first result). Used for pagination with limit (optional) 
            var order = order_example;  // string | The field by which to order. (optional)  (default to published_date)
            var orderDirection = orderDirection_example;  // string |  (optional)  (default to desc)
            var storage = storage_example;  // string | only return collections from this institution (optional) 
            var roles = roles_example;  // string | Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\". (optional) 

            try
            {
                // Private Projects
                List&lt;ProjectPrivate&gt; result = apiInstance.PrivateProjectsList(page, pageSize, limit, offset, order, orderDirection, storage, roles);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. | [optional] [default to published_date]
 **orderDirection** | **string**|  | [optional] [default to desc]
 **storage** | **string**| only return collections from this institution | [optional] 
 **roles** | **string**| Any combination of owner, collaborator, viewer separated by comma. Examples: \&quot;owner\&quot; or \&quot;owner,collaborator\&quot;. | [optional] 

### Return type

[**List<ProjectPrivate>**](ProjectPrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateprojectssearch"></a>
# **PrivateProjectsSearch**
> List<ProjectPrivate> PrivateProjectsSearch (ProjectsSearch search = null)

Private Projects search

Search inside the private projects

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateProjectsSearchExample
    {
        public void main()
        {
            var apiInstance = new ProjectsApi();
            var search = new ProjectsSearch(); // ProjectsSearch | Search Parameters (optional) 

            try
            {
                // Private Projects search
                List&lt;ProjectPrivate&gt; result = apiInstance.PrivateProjectsSearch(search);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectsSearch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**ProjectsSearch**](ProjectsSearch.md)| Search Parameters | [optional] 

### Return type

[**List<ProjectPrivate>**](ProjectPrivate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="projectarticles"></a>
# **ProjectArticles**
> List<Article> ProjectArticles (long? projectId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

Public Project Articles

List articles in project

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProjectArticlesExample
    {
        public void main()
        {
            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project Unique identifier
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing(the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Public Project Articles
                List&lt;Article&gt; result = apiInstance.ProjectArticles(projectId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.ProjectArticles: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project Unique identifier | 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List<Article>**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="projectdetails"></a>
# **ProjectDetails**
> ProjectComplete ProjectDetails (long? projectId)

Public Project

View a project

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProjectDetailsExample
    {
        public void main()
        {
            var apiInstance = new ProjectsApi();
            var projectId = 789;  // long? | Project Unique identifier

            try
            {
                // Public Project
                ProjectComplete result = apiInstance.ProjectDetails(projectId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.ProjectDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **long?**| Project Unique identifier | 

### Return type

[**ProjectComplete**](ProjectComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="projectslist"></a>
# **ProjectsList**
> List<Project> ProjectsList (Guid? xCursor = null, long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string order = null, string orderDirection = null, long? institution = null, string publishedSince = null, long? group = null)

Public Projects

Returns a list of public projects

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProjectsListExample
    {
        public void main()
        {
            var apiInstance = new ProjectsApi();
            var xCursor = new Guid?(); // Guid? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing(the offset of the first result). Used for pagination with limit (optional) 
            var order = order_example;  // string | The field by which to order. Default varies by endpoint/resource. (optional)  (default to published_date)
            var orderDirection = orderDirection_example;  // string |  (optional)  (default to desc)
            var institution = 789;  // long? | only return collections from this institution (optional) 
            var publishedSince = publishedSince_example;  // string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional) 
            var group = 789;  // long? | only return collections from this group (optional) 

            try
            {
                // Public Projects
                List&lt;Project&gt; result = apiInstance.ProjectsList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, group);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.ProjectsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | [**Guid?**](Guid?.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **orderDirection** | **string**|  | [optional] [default to desc]
 **institution** | **long?**| only return collections from this institution | [optional] 
 **publishedSince** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **group** | **long?**| only return collections from this group | [optional] 

### Return type

[**List<Project>**](Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="projectssearch"></a>
# **ProjectsSearch**
> List<Project> ProjectsSearch (Guid? xCursor = null, ProjectsSearch search = null)

Public Projects Search

Returns a list of public articles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProjectsSearchExample
    {
        public void main()
        {
            var apiInstance = new ProjectsApi();
            var xCursor = new Guid?(); // Guid? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var search = new ProjectsSearch(); // ProjectsSearch | Search Parameters (optional) 

            try
            {
                // Public Projects Search
                List&lt;Project&gt; result = apiInstance.ProjectsSearch(xCursor, search);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProjectsApi.ProjectsSearch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | [**Guid?**](Guid?.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **search** | [**ProjectsSearch**](ProjectsSearch.md)| Search Parameters | [optional] 

### Return type

[**List<Project>**](Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

