# Org.OpenAPITools.Model.SymplecticAccountsIds200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstitutionUserId** | **string** |  | [optional] 
**ModifiedDate** | **DateTime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

