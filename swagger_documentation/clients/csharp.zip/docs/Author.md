# IO.Swagger.Model.Author
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Author id | 
**FullName** | **string** | Author full name | 
**FirstName** | **string** | Author first name | 
**LastName** | **string** | Author last name | 
**IsActive** | **bool?** | True if author has published items | 
**UrlName** | **string** | Author url name | 
**OrcidId** | **string** | Author Orcid | 
**GroupId** | **long?** | Author group id | 
**IsPublic** | **bool?** | True if author is public | 
**InstitutionId** | **long?** | Institution id | 
**JobTitle** | **string** | Job title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

