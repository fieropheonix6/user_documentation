# IO.Swagger.Model.PrivateProjectArticles
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Unique identifier for article | 
**Title** | **string** | Title of article | 
**Doi** | **string** | DOI | 
**Handle** | **string** | Handle | 
**Url** | **string** | Api endpoint for article | 
**UrlPublicHtml** | **string** | Public site endpoint for article | 
**UrlPublicApi** | **string** | Public Api endpoint for article | 
**UrlPrivateHtml** | **string** | Private site endpoint for article | 
**UrlPrivateApi** | **string** | Private Api endpoint for article | 
**Timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**Thumb** | **string** | Thumbnail image | 
**DefinedType** | **long?** | Type of article identifier | 
**DefinedTypeName** | **string** | Name of the article type identifier | 
**ResourceDoi** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to ""]
**ResourceTitle** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to ""]
**CreatedDate** | **string** | Date when article was created | 
**Files** | [**List&lt;PublicFile&gt;**](PublicFile.md) | List of up to 10 article files. | 
**EmbargoOptions** | [**List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md) | List of embargo options | 
**CustomFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | List of custom fields values | 
**AccountId** | **long?** | ID of the account owning the article | 
**DownloadDisabled** | **bool?** | If true, downloading of files for this article is disabled | 
**Authors** | [**List&lt;Author&gt;**](Author.md) | List of authors | 
**FigshareUrl** | **string** | Article public url | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

