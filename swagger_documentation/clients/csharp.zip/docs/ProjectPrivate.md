# IO.Swagger.Model.ProjectPrivate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Url** | **string** | Api endpoint | 
**Id** | **long?** | Project id | 
**Title** | **string** | Project title | 
**CreatedDate** | **string** | Date when project was created | 
**ModifiedDate** | **string** | Date when project was last modified | 
**Role** | **string** | Role inside this project | 
**Storage** | **string** | Project storage type | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

