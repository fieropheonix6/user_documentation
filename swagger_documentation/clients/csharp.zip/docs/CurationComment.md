# IO.Swagger.Model.CurationComment
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | The ID of the comment. | 
**AccountId** | **long?** | The ID of the account which generated this comment. | 
**Type** | **string** | The ID of the account which generated this comment. | 
**Text** | **string** | The value/content of the comment. | 
**CreatedDate** | **string** | The creation date of the comment. | 
**ModifiedDate** | **string** | The date the comment has been modified. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

