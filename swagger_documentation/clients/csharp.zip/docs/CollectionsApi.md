# IO.Swagger.Api.CollectionsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CollectionArticles**](CollectionsApi.md#collectionarticles) | **GET** /collections/{collection_id}/articles | Public Collection Articles
[**CollectionDetails**](CollectionsApi.md#collectiondetails) | **GET** /collections/{collection_id} | Collection details
[**CollectionVersionDetails**](CollectionsApi.md#collectionversiondetails) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details
[**CollectionVersions**](CollectionsApi.md#collectionversions) | **GET** /collections/{collection_id}/versions | Collection Versions list
[**CollectionsList**](CollectionsApi.md#collectionslist) | **GET** /collections | Public Collections
[**CollectionsSearch**](CollectionsApi.md#collectionssearch) | **POST** /collections/search | Public Collections Search
[**PrivateCollectionArticleDelete**](CollectionsApi.md#privatecollectionarticledelete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article
[**PrivateCollectionArticlesAdd**](CollectionsApi.md#privatecollectionarticlesadd) | **POST** /account/collections/{collection_id}/articles | Add collection articles
[**PrivateCollectionArticlesList**](CollectionsApi.md#privatecollectionarticleslist) | **GET** /account/collections/{collection_id}/articles | List collection articles
[**PrivateCollectionArticlesReplace**](CollectionsApi.md#privatecollectionarticlesreplace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles
[**PrivateCollectionAuthorDelete**](CollectionsApi.md#privatecollectionauthordelete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author
[**PrivateCollectionAuthorsAdd**](CollectionsApi.md#privatecollectionauthorsadd) | **POST** /account/collections/{collection_id}/authors | Add collection authors
[**PrivateCollectionAuthorsList**](CollectionsApi.md#privatecollectionauthorslist) | **GET** /account/collections/{collection_id}/authors | List collection authors
[**PrivateCollectionAuthorsReplace**](CollectionsApi.md#privatecollectionauthorsreplace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors
[**PrivateCollectionCategoriesAdd**](CollectionsApi.md#privatecollectioncategoriesadd) | **POST** /account/collections/{collection_id}/categories | Add collection categories
[**PrivateCollectionCategoriesList**](CollectionsApi.md#privatecollectioncategorieslist) | **GET** /account/collections/{collection_id}/categories | List collection categories
[**PrivateCollectionCategoriesReplace**](CollectionsApi.md#privatecollectioncategoriesreplace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories
[**PrivateCollectionCategoryDelete**](CollectionsApi.md#privatecollectioncategorydelete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category
[**PrivateCollectionCreate**](CollectionsApi.md#privatecollectioncreate) | **POST** /account/collections | Create collection
[**PrivateCollectionDelete**](CollectionsApi.md#privatecollectiondelete) | **DELETE** /account/collections/{collection_id} | Delete collection
[**PrivateCollectionDetails**](CollectionsApi.md#privatecollectiondetails) | **GET** /account/collections/{collection_id} | Collection details
[**PrivateCollectionPatch**](CollectionsApi.md#privatecollectionpatch) | **PATCH** /account/collections/{collection_id} | Partially update collection
[**PrivateCollectionPrivateLinkCreate**](CollectionsApi.md#privatecollectionprivatelinkcreate) | **POST** /account/collections/{collection_id}/private_links | Create collection private link
[**PrivateCollectionPrivateLinkDelete**](CollectionsApi.md#privatecollectionprivatelinkdelete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link
[**PrivateCollectionPrivateLinkDetails**](CollectionsApi.md#privatecollectionprivatelinkdetails) | **GET** /account/collections/{collection_id}/private_links/{link_id} | View collection private link
[**PrivateCollectionPrivateLinkUpdate**](CollectionsApi.md#privatecollectionprivatelinkupdate) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link
[**PrivateCollectionPrivateLinksList**](CollectionsApi.md#privatecollectionprivatelinkslist) | **GET** /account/collections/{collection_id}/private_links | List collection private links
[**PrivateCollectionPublish**](CollectionsApi.md#privatecollectionpublish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish
[**PrivateCollectionReserveDoi**](CollectionsApi.md#privatecollectionreservedoi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI
[**PrivateCollectionReserveHandle**](CollectionsApi.md#privatecollectionreservehandle) | **POST** /account/collections/{collection_id}/reserve_handle | Private Collection Reserve Handle
[**PrivateCollectionResource**](CollectionsApi.md#privatecollectionresource) | **POST** /account/collections/{collection_id}/resource | Private Collection Resource
[**PrivateCollectionUpdate**](CollectionsApi.md#privatecollectionupdate) | **PUT** /account/collections/{collection_id} | Update collection
[**PrivateCollectionsList**](CollectionsApi.md#privatecollectionslist) | **GET** /account/collections | Private Collections List
[**PrivateCollectionsSearch**](CollectionsApi.md#privatecollectionssearch) | **POST** /account/collections/search | Private Collections Search


<a name="collectionarticles"></a>
# **CollectionArticles**
> List<Article> CollectionArticles (long? collectionId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

Public Collection Articles

Returns a list of public collection articles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CollectionArticlesExample
    {
        public void main()
        {
            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing(the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Public Collection Articles
                List&lt;Article&gt; result = apiInstance.CollectionArticles(collectionId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionArticles: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List<Article>**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="collectiondetails"></a>
# **CollectionDetails**
> CollectionComplete CollectionDetails (long? collectionId)

Collection details

View a collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CollectionDetailsExample
    {
        public void main()
        {
            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier

            try
            {
                // Collection details
                CollectionComplete result = apiInstance.CollectionDetails(collectionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="collectionversiondetails"></a>
# **CollectionVersionDetails**
> CollectionComplete CollectionVersionDetails (long? collectionId, long? versionId)

Collection Version details

View details for a certain version of a collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CollectionVersionDetailsExample
    {
        public void main()
        {
            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier
            var versionId = 789;  // long? | Version Number

            try
            {
                // Collection Version details
                CollectionComplete result = apiInstance.CollectionVersionDetails(collectionId, versionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionVersionDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 
 **versionId** | **long?**| Version Number | 

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="collectionversions"></a>
# **CollectionVersions**
> List<CollectionVersions> CollectionVersions (long? collectionId)

Collection Versions list

Returns a list of public collection Versions

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CollectionVersionsExample
    {
        public void main()
        {
            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier

            try
            {
                // Collection Versions list
                List&lt;CollectionVersions&gt; result = apiInstance.CollectionVersions(collectionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionVersions: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 

### Return type

[**List<CollectionVersions>**](CollectionVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="collectionslist"></a>
# **CollectionsList**
> List<Collection> CollectionsList (Guid? xCursor = null, long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string order = null, string orderDirection = null, long? institution = null, string publishedSince = null, string modifiedSince = null, long? group = null, string resourceDoi = null, string doi = null, string handle = null)

Public Collections

Returns a list of public collections

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CollectionsListExample
    {
        public void main()
        {
            var apiInstance = new CollectionsApi();
            var xCursor = new Guid?(); // Guid? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing(the offset of the first result). Used for pagination with limit (optional) 
            var order = order_example;  // string | The field by which to order. Default varies by endpoint/resource. (optional)  (default to published_date)
            var orderDirection = orderDirection_example;  // string |  (optional)  (default to desc)
            var institution = 789;  // long? | only return collections from this institution (optional) 
            var publishedSince = publishedSince_example;  // string | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD (optional) 
            var modifiedSince = modifiedSince_example;  // string | Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD (optional) 
            var group = 789;  // long? | only return collections from this group (optional) 
            var resourceDoi = resourceDoi_example;  // string | only return collections with this resource_doi (optional) 
            var doi = doi_example;  // string | only return collections with this doi (optional) 
            var handle = handle_example;  // string | only return collections with this handle (optional) 

            try
            {
                // Public Collections
                List&lt;Collection&gt; result = apiInstance.CollectionsList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, modifiedSince, group, resourceDoi, doi, handle);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | [**Guid?**](Guid?.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **orderDirection** | **string**|  | [optional] [default to desc]
 **institution** | **long?**| only return collections from this institution | [optional] 
 **publishedSince** | **string**| Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **modifiedSince** | **string**| Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **group** | **long?**| only return collections from this group | [optional] 
 **resourceDoi** | **string**| only return collections with this resource_doi | [optional] 
 **doi** | **string**| only return collections with this doi | [optional] 
 **handle** | **string**| only return collections with this handle | [optional] 

### Return type

**List<Collection>**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="collectionssearch"></a>
# **CollectionsSearch**
> List<Collection> CollectionsSearch (Guid? xCursor = null, CollectionSearch search = null)

Public Collections Search

Returns a list of public collections

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CollectionsSearchExample
    {
        public void main()
        {
            var apiInstance = new CollectionsApi();
            var xCursor = new Guid?(); // Guid? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var search = new CollectionSearch(); // CollectionSearch | Search Parameters (optional) 

            try
            {
                // Public Collections Search
                List&lt;Collection&gt; result = apiInstance.CollectionsSearch(xCursor, search);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionsSearch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | [**Guid?**](Guid?.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **search** | [**CollectionSearch**](CollectionSearch.md)| Search Parameters | [optional] 

### Return type

**List<Collection>**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionarticledelete"></a>
# **PrivateCollectionArticleDelete**
> void PrivateCollectionArticleDelete (long? collectionId, long? articleId)

Delete collection article

De-associate article from collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionArticleDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var articleId = 789;  // long? | Collection article unique identifier

            try
            {
                // Delete collection article
                apiInstance.PrivateCollectionArticleDelete(collectionId, articleId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticleDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **articleId** | **long?**| Collection article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionarticlesadd"></a>
# **PrivateCollectionArticlesAdd**
> Location PrivateCollectionArticlesAdd (long? collectionId, ArticlesCreator articles)

Add collection articles

Associate new articles with the collection. This will add new articles to the list of already associated articles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionArticlesAddExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var articles = new ArticlesCreator(); // ArticlesCreator | Articles list

            try
            {
                // Add collection articles
                Location result = apiInstance.PrivateCollectionArticlesAdd(collectionId, articles);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticlesAdd: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **articles** | [**ArticlesCreator**](ArticlesCreator.md)| Articles list | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionarticleslist"></a>
# **PrivateCollectionArticlesList**
> List<Article> PrivateCollectionArticlesList (long? collectionId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

List collection articles

List collection articles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionArticlesListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing(the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // List collection articles
                List&lt;Article&gt; result = apiInstance.PrivateCollectionArticlesList(collectionId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticlesList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List<Article>**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionarticlesreplace"></a>
# **PrivateCollectionArticlesReplace**
> void PrivateCollectionArticlesReplace (long? collectionId, ArticlesCreator articles)

Replace collection articles

Associate new articles with the collection. This will remove all already associated articles and add these new ones

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionArticlesReplaceExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var articles = new ArticlesCreator(); // ArticlesCreator | Articles List

            try
            {
                // Replace collection articles
                apiInstance.PrivateCollectionArticlesReplace(collectionId, articles);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticlesReplace: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **articles** | [**ArticlesCreator**](ArticlesCreator.md)| Articles List | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionauthordelete"></a>
# **PrivateCollectionAuthorDelete**
> void PrivateCollectionAuthorDelete (long? collectionId, long? authorId)

Delete collection author

Delete collection author

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionAuthorDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var authorId = 789;  // long? | Collection Author unique identifier

            try
            {
                // Delete collection author
                apiInstance.PrivateCollectionAuthorDelete(collectionId, authorId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **authorId** | **long?**| Collection Author unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionauthorsadd"></a>
# **PrivateCollectionAuthorsAdd**
> Location PrivateCollectionAuthorsAdd (long? collectionId, AuthorsCreator authors)

Add collection authors

Associate new authors with the collection. This will add new authors to the list of already associated authors

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionAuthorsAddExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var authors = new AuthorsCreator(); // AuthorsCreator | List of authors

            try
            {
                // Add collection authors
                Location result = apiInstance.PrivateCollectionAuthorsAdd(collectionId, authors);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorsAdd: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| List of authors | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionauthorslist"></a>
# **PrivateCollectionAuthorsList**
> List<Author> PrivateCollectionAuthorsList (long? collectionId)

List collection authors

List collection authors

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionAuthorsListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier

            try
            {
                // List collection authors
                List&lt;Author&gt; result = apiInstance.PrivateCollectionAuthorsList(collectionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 

### Return type

[**List<Author>**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionauthorsreplace"></a>
# **PrivateCollectionAuthorsReplace**
> void PrivateCollectionAuthorsReplace (long? collectionId, AuthorsCreator authors)

Replace collection authors

Associate new authors with the collection. This will remove all already associated authors and add these new ones

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionAuthorsReplaceExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var authors = new AuthorsCreator(); // AuthorsCreator | List of authors

            try
            {
                // Replace collection authors
                apiInstance.PrivateCollectionAuthorsReplace(collectionId, authors);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorsReplace: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| List of authors | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectioncategoriesadd"></a>
# **PrivateCollectionCategoriesAdd**
> Location PrivateCollectionCategoriesAdd (long? collectionId, CategoriesCreator categories)

Add collection categories

Associate new categories with the collection. This will add new categories to the list of already associated categories

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionCategoriesAddExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var categories = new CategoriesCreator(); // CategoriesCreator | Categories list

            try
            {
                // Add collection categories
                Location result = apiInstance.PrivateCollectionCategoriesAdd(collectionId, categories);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoriesAdd: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)| Categories list | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectioncategorieslist"></a>
# **PrivateCollectionCategoriesList**
> List<Category> PrivateCollectionCategoriesList (long? collectionId)

List collection categories

List collection categories

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionCategoriesListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier

            try
            {
                // List collection categories
                List&lt;Category&gt; result = apiInstance.PrivateCollectionCategoriesList(collectionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoriesList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 

### Return type

[**List<Category>**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectioncategoriesreplace"></a>
# **PrivateCollectionCategoriesReplace**
> void PrivateCollectionCategoriesReplace (long? collectionId, CategoriesCreator categories)

Replace collection categories

Associate new categories with the collection. This will remove all already associated categories and add these new ones

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionCategoriesReplaceExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var categories = new CategoriesCreator(); // CategoriesCreator | Categories list

            try
            {
                // Replace collection categories
                apiInstance.PrivateCollectionCategoriesReplace(collectionId, categories);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoriesReplace: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)| Categories list | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectioncategorydelete"></a>
# **PrivateCollectionCategoryDelete**
> void PrivateCollectionCategoryDelete (long? collectionId, long? categoryId)

Delete collection category

De-associate category from collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionCategoryDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var categoryId = 789;  // long? | Collection category unique identifier

            try
            {
                // Delete collection category
                apiInstance.PrivateCollectionCategoryDelete(collectionId, categoryId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoryDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **categoryId** | **long?**| Collection category unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectioncreate"></a>
# **PrivateCollectionCreate**
> LocationWarnings PrivateCollectionCreate (CollectionCreate collection)

Create collection

Create a new Collection by sending collection information

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionCreateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collection = new CollectionCreate(); // CollectionCreate | Collection description

            try
            {
                // Create collection
                LocationWarnings result = apiInstance.PrivateCollectionCreate(collection);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection** | [**CollectionCreate**](CollectionCreate.md)| Collection description | 

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectiondelete"></a>
# **PrivateCollectionDelete**
> void PrivateCollectionDelete (long? collectionId)

Delete collection

Delete n collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier

            try
            {
                // Delete collection
                apiInstance.PrivateCollectionDelete(collectionId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectiondetails"></a>
# **PrivateCollectionDetails**
> CollectionCompletePrivate PrivateCollectionDetails (long? collectionId)

Collection details

View a collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier

            try
            {
                // Collection details
                CollectionCompletePrivate result = apiInstance.PrivateCollectionDetails(collectionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 

### Return type

[**CollectionCompletePrivate**](CollectionCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionpatch"></a>
# **PrivateCollectionPatch**
> LocationWarningsUpdate PrivateCollectionPatch (long? collectionId, CollectionUpdate collection)

Partially update collection

Partially update a collection by sending only the fields to change.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionPatchExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier
            var collection = new CollectionUpdate(); // CollectionUpdate | Subset of collection fields to update

            try
            {
                // Partially update collection
                LocationWarningsUpdate result = apiInstance.PrivateCollectionPatch(collectionId, collection);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPatch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 
 **collection** | [**CollectionUpdate**](CollectionUpdate.md)| Subset of collection fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionprivatelinkcreate"></a>
# **PrivateCollectionPrivateLinkCreate**
> PrivateLinkResponse PrivateCollectionPrivateLinkCreate (long? collectionId, CollectionPrivateLinkCreator privateLink = null)

Create collection private link

Create new private link

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionPrivateLinkCreateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var privateLink = new CollectionPrivateLinkCreator(); // CollectionPrivateLinkCreator |  (optional) 

            try
            {
                // Create collection private link
                PrivateLinkResponse result = apiInstance.PrivateCollectionPrivateLinkCreate(collectionId, privateLink);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **privateLink** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md)|  | [optional] 

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionprivatelinkdelete"></a>
# **PrivateCollectionPrivateLinkDelete**
> void PrivateCollectionPrivateLinkDelete (long? collectionId, string linkId)

Disable private link

Disable/delete private link for this collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionPrivateLinkDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var linkId = linkId_example;  // string | Private link token

            try
            {
                // Disable private link
                apiInstance.PrivateCollectionPrivateLinkDelete(collectionId, linkId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **linkId** | **string**| Private link token | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionprivatelinkdetails"></a>
# **PrivateCollectionPrivateLinkDetails**
> PrivateLink PrivateCollectionPrivateLinkDetails (long? collectionId, string linkId)

View collection private link

View existing private link for this collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionPrivateLinkDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var linkId = linkId_example;  // string | Private link token

            try
            {
                // View collection private link
                PrivateLink result = apiInstance.PrivateCollectionPrivateLinkDetails(collectionId, linkId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **linkId** | **string**| Private link token | 

### Return type

[**PrivateLink**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionprivatelinkupdate"></a>
# **PrivateCollectionPrivateLinkUpdate**
> void PrivateCollectionPrivateLinkUpdate (long? collectionId, string linkId, CollectionPrivateLinkCreator privateLink = null)

Update collection private link

Update existing private link for this collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionPrivateLinkUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var linkId = linkId_example;  // string | Private link token
            var privateLink = new CollectionPrivateLinkCreator(); // CollectionPrivateLinkCreator |  (optional) 

            try
            {
                // Update collection private link
                apiInstance.PrivateCollectionPrivateLinkUpdate(collectionId, linkId, privateLink);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **linkId** | **string**| Private link token | 
 **privateLink** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionprivatelinkslist"></a>
# **PrivateCollectionPrivateLinksList**
> List<PrivateLink> PrivateCollectionPrivateLinksList (long? collectionId)

List collection private links

List article private links

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionPrivateLinksListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier

            try
            {
                // List collection private links
                List&lt;PrivateLink&gt; result = apiInstance.PrivateCollectionPrivateLinksList(collectionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinksList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 

### Return type

[**List<PrivateLink>**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionpublish"></a>
# **PrivateCollectionPublish**
> Location PrivateCollectionPublish (long? collectionId)

Private Collection Publish

When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionPublishExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier

            try
            {
                // Private Collection Publish
                Location result = apiInstance.PrivateCollectionPublish(collectionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPublish: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionreservedoi"></a>
# **PrivateCollectionReserveDoi**
> CollectionDOI PrivateCollectionReserveDoi (long? collectionId)

Private Collection Reserve DOI

Reserve DOI for collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionReserveDoiExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier

            try
            {
                // Private Collection Reserve DOI
                CollectionDOI result = apiInstance.PrivateCollectionReserveDoi(collectionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionReserveDoi: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 

### Return type

[**CollectionDOI**](CollectionDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionreservehandle"></a>
# **PrivateCollectionReserveHandle**
> CollectionHandle PrivateCollectionReserveHandle (long? collectionId)

Private Collection Reserve Handle

Reserve Handle for collection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionReserveHandleExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier

            try
            {
                // Private Collection Reserve Handle
                CollectionHandle result = apiInstance.PrivateCollectionReserveHandle(collectionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionReserveHandle: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 

### Return type

[**CollectionHandle**](CollectionHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionresource"></a>
# **PrivateCollectionResource**
> Location PrivateCollectionResource (long? collectionId, Resource resource)

Private Collection Resource

Edit collection resource data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionResourceExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection unique identifier
            var resource = new Resource(); // Resource | Resource data

            try
            {
                // Private Collection Resource
                Location result = apiInstance.PrivateCollectionResource(collectionId, resource);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionResource: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection unique identifier | 
 **resource** | [**Resource**](Resource.md)| Resource data | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionupdate"></a>
# **PrivateCollectionUpdate**
> LocationWarningsUpdate PrivateCollectionUpdate (long? collectionId, CollectionUpdate collection)

Update collection

Update a collection by passing full body parameters.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var collectionId = 789;  // long? | Collection Unique identifier
            var collection = new CollectionUpdate(); // CollectionUpdate | Collection description

            try
            {
                // Update collection
                LocationWarningsUpdate result = apiInstance.PrivateCollectionUpdate(collectionId, collection);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **long?**| Collection Unique identifier | 
 **collection** | [**CollectionUpdate**](CollectionUpdate.md)| Collection description | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionslist"></a>
# **PrivateCollectionsList**
> List<Collection> PrivateCollectionsList (long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string order = null, string orderDirection = null)

Private Collections List

List private collections

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionsListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing(the offset of the first result). Used for pagination with limit (optional) 
            var order = order_example;  // string | The field by which to order. Default varies by endpoint/resource. (optional)  (default to published_date)
            var orderDirection = orderDirection_example;  // string |  (optional)  (default to desc)

            try
            {
                // Private Collections List
                List&lt;Collection&gt; result = apiInstance.PrivateCollectionsList(page, pageSize, limit, offset, order, orderDirection);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **orderDirection** | **string**|  | [optional] [default to desc]

### Return type

**List<Collection>**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecollectionssearch"></a>
# **PrivateCollectionsSearch**
> List<Collection> PrivateCollectionsSearch (PrivateCollectionSearch search)

Private Collections Search

Returns a list of private Collections

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCollectionsSearchExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi();
            var search = new PrivateCollectionSearch(); // PrivateCollectionSearch | Search Parameters

            try
            {
                // Private Collections Search
                List&lt;Collection&gt; result = apiInstance.PrivateCollectionsSearch(search);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionsSearch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateCollectionSearch**](PrivateCollectionSearch.md)| Search Parameters | 

### Return type

**List<Collection>**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

