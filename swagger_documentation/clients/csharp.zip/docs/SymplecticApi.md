# Org.OpenAPITools.Api.SymplecticApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**SymplecticAccountArticles**](SymplecticApi.md#symplecticaccountarticles) | **GET** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account |
| [**SymplecticAccountsIds**](SymplecticApi.md#symplecticaccountsids) | **GET** /symplectic/accounts | Get changed accounts for Symplectic Elements |
| [**SymplecticArticle**](SymplecticApi.md#symplecticarticle) | **GET** /symplectic/articles/{article_id} | Get article details for Symplectic Elements |
| [**SymplecticChangedArticles**](SymplecticApi.md#symplecticchangedarticles) | **GET** /symplectic/articles | Get changed articles for Symplectic Elements |
| [**SymplecticUserId**](SymplecticApi.md#symplecticuserid) | **GET** /symplectic/users/{user_id} | Get institutional user ID for a user |

<a id="symplecticaccountarticles"></a>
# **SymplecticAccountArticles**
> List&lt;Object&gt; SymplecticAccountArticles (string externalUserId, int? offset = null, int? limit = null, string? status = null, string? isEmbargoed = null)

Get articles for a specific account

Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class SymplecticAccountArticlesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SymplecticApi(config);
            var externalUserId = "externalUserId_example";  // string | External user ID (symplectic_user_id or institution_user_id)
            var offset = 0;  // int? | Number of results to skip for pagination (optional)  (default to 0)
            var limit = 10;  // int? | Maximum number of results to return (optional)  (default to 10)
            var status = "public";  // string? | Filter by article status (optional) 
            var isEmbargoed = "true";  // string? | Filter by embargo status (optional) 

            try
            {
                // Get articles for a specific account
                List<Object> result = apiInstance.SymplecticAccountArticles(externalUserId, offset, limit, status, isEmbargoed);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling SymplecticApi.SymplecticAccountArticles: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the SymplecticAccountArticlesWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get articles for a specific account
    ApiResponse<List<Object>> response = apiInstance.SymplecticAccountArticlesWithHttpInfo(externalUserId, offset, limit, status, isEmbargoed);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling SymplecticApi.SymplecticAccountArticlesWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **externalUserId** | **string** | External user ID (symplectic_user_id or institution_user_id) |  |
| **offset** | **int?** | Number of results to skip for pagination | [optional] [default to 0] |
| **limit** | **int?** | Maximum number of results to return | [optional] [default to 10] |
| **status** | **string?** | Filter by article status | [optional]  |
| **isEmbargoed** | **string?** | Filter by embargo status | [optional]  |

### Return type

**List<Object>**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Returns a list of articles for the specified account |  * ETag - Hash of the returned accounts for caching purposes <br>  |
| **401** | Unauthorized - Missing or invalid OAuth token |  -  |
| **403** | Forbidden - Insufficient permissions |  -  |
| **404** | Not Found - Account not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="symplecticaccountsids"></a>
# **SymplecticAccountsIds**
> List&lt;SymplecticAccountsIds200ResponseInner&gt; SymplecticAccountsIds (string since)

Get changed accounts for Symplectic Elements

Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class SymplecticAccountsIdsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SymplecticApi(config);
            var since = 2015-01-01 00:00:00;  // string | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)

            try
            {
                // Get changed accounts for Symplectic Elements
                List<SymplecticAccountsIds200ResponseInner> result = apiInstance.SymplecticAccountsIds(since);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling SymplecticApi.SymplecticAccountsIds: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the SymplecticAccountsIdsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get changed accounts for Symplectic Elements
    ApiResponse<List<SymplecticAccountsIds200ResponseInner>> response = apiInstance.SymplecticAccountsIdsWithHttpInfo(since);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling SymplecticApi.SymplecticAccountsIdsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **since** | **string** | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) |  |

### Return type

[**List&lt;SymplecticAccountsIds200ResponseInner&gt;**](SymplecticAccountsIds200ResponseInner.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Returns a list of modified accounts |  * ETag - Hash of the returned accounts for caching purposes <br>  |
| **400** | Bad Request - Missing or invalid parameters |  -  |
| **401** | Unauthorized - Missing or invalid OAuth token |  -  |
| **403** | Forbidden - Insufficient permissions |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="symplecticarticle"></a>
# **SymplecticArticle**
> Object SymplecticArticle (int articleId)

Get article details for Symplectic Elements

Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class SymplecticArticleExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SymplecticApi(config);
            var articleId = 56;  // int | Article ID

            try
            {
                // Get article details for Symplectic Elements
                Object result = apiInstance.SymplecticArticle(articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling SymplecticApi.SymplecticArticle: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the SymplecticArticleWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get article details for Symplectic Elements
    ApiResponse<Object> response = apiInstance.SymplecticArticleWithHttpInfo(articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling SymplecticApi.SymplecticArticleWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **articleId** | **int** | Article ID |  |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Returns the article details with full metadata |  * ETag - Hash of the returned accounts for caching purposes <br>  |
| **401** | Unauthorized - Missing or invalid OAuth token |  -  |
| **403** | Forbidden - Insufficient permissions |  -  |
| **404** | Not Found - Article not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="symplecticchangedarticles"></a>
# **SymplecticChangedArticles**
> List&lt;Object&gt; SymplecticChangedArticles (string since, int? offset = null, int? limit = null, string? status = null, string? isEmbargoed = null)

Get changed articles for Symplectic Elements

Returns a list of articles for Symplectic Elements integration to synchronize article data.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class SymplecticChangedArticlesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SymplecticApi(config);
            var since = 2015-01-01 00:00:00;  // string | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
            var offset = 0;  // int? | Number of results to skip for pagination (optional)  (default to 0)
            var limit = 10;  // int? | Maximum number of results to return (optional)  (default to 10)
            var status = "public";  // string? | Filter by article status (optional) 
            var isEmbargoed = "true";  // string? | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type (optional) 

            try
            {
                // Get changed articles for Symplectic Elements
                List<Object> result = apiInstance.SymplecticChangedArticles(since, offset, limit, status, isEmbargoed);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling SymplecticApi.SymplecticChangedArticles: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the SymplecticChangedArticlesWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get changed articles for Symplectic Elements
    ApiResponse<List<Object>> response = apiInstance.SymplecticChangedArticlesWithHttpInfo(since, offset, limit, status, isEmbargoed);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling SymplecticApi.SymplecticChangedArticlesWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **since** | **string** | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) |  |
| **offset** | **int?** | Number of results to skip for pagination | [optional] [default to 0] |
| **limit** | **int?** | Maximum number of results to return | [optional] [default to 10] |
| **status** | **string?** | Filter by article status | [optional]  |
| **isEmbargoed** | **string?** | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type | [optional]  |

### Return type

**List<Object>**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Returns a list of symplectic articles |  * ETag - Hash of the returned accounts for caching purposes <br>  |
| **400** | Bad Request - Missing or invalid parameters |  -  |
| **401** | Unauthorized - Missing or invalid OAuth token |  -  |
| **403** | Forbidden - Insufficient permissions |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="symplecticuserid"></a>
# **SymplecticUserId**
> SymplecticUserId200Response SymplecticUserId (int userId)

Get institutional user ID for a user

Returns the institution user ID for a given user within the authenticated account's institution.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class SymplecticUserIdExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SymplecticApi(config);
            var userId = 56;  // int | User ID

            try
            {
                // Get institutional user ID for a user
                SymplecticUserId200Response result = apiInstance.SymplecticUserId(userId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling SymplecticApi.SymplecticUserId: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the SymplecticUserIdWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get institutional user ID for a user
    ApiResponse<SymplecticUserId200Response> response = apiInstance.SymplecticUserIdWithHttpInfo(userId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling SymplecticApi.SymplecticUserIdWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **userId** | **int** | User ID |  |

### Return type

[**SymplecticUserId200Response**](SymplecticUserId200Response.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Returns the institutional user ID |  -  |
| **401** | Unauthorized - Missing or invalid OAuth token |  -  |
| **403** | Forbidden - Insufficient permissions |  -  |
| **404** | Not Found - User not found or user has no account in this institution |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

