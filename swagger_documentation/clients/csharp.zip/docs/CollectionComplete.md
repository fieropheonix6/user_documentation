# Org.OpenAPITools.Model.CollectionComplete

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Funding** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information | 
**ResourceId** | **string** | Collection resource id | 
**ResourceDoi** | **string** | Collection resource doi | 
**ResourceTitle** | **string** | Collection resource title | 
**ResourceLink** | **string** | Collection resource link | 
**ResourceVersion** | **int** | Collection resource version | 
**VarVersion** | **int** | Collection version | 
**Description** | **string** | Collection description | 
**Categories** | [**List&lt;Category&gt;**](Category.md) | List of collection categories | 
**References** | **List&lt;string&gt;** | List of collection references | 
**RelatedMaterials** | [**List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | 
**Tags** | **List&lt;string&gt;** | List of collection tags. Keywords can be used instead | 
**Keywords** | **List&lt;string&gt;** | List of collection keywords. Tags can be used instead | 
**Authors** | [**List&lt;Author&gt;**](Author.md) | List of collection authors | 
**InstitutionId** | **int** | Collection institution | 
**GroupId** | **int** | Collection group | 
**ArticlesCount** | **int** | Number of articles in collection | 
**Public** | **bool** | True if collection is published | 
**Citation** | **string** | Collection citation | 
**CustomFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | Collection custom fields | 
**ModifiedDate** | **string** | Date when collection was last modified | 
**CreatedDate** | **string** | Date when collection was created | 
**Timeline** | [**Timeline**](Timeline.md) |  | 
**Id** | **int** | Collection id | 
**Title** | **string** | Collection title | 
**Doi** | **string** | Collection DOI | 
**Handle** | **string** | Collection Handle | 
**Url** | **string** | Api endpoint | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

