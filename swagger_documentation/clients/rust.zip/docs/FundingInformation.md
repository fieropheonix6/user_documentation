# FundingInformation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** | Funding id | 
**title** | **String** | The funding name | 
**grant_code** | **String** | The grant code | 
**funder_name** | **String** | Funder's name | 
**is_user_defined** | **i32** | Return 1 whether the grant has been introduced manually, 0 otherwise | 
**url** | **String** | The grant url | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


