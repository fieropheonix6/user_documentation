# AccountCreate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** | Email of account | 
**first_name** | Option<**String**> | First Name | [optional][default to ]
**last_name** | **String** | Last Name | [default to ]
**group_id** | Option<**i32**> | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional]
**institution_user_id** | Option<**String**> | Institution user id | [optional][default to ]
**symplectic_user_id** | Option<**String**> | Symplectic user id | [optional][default to ]
**quota** | Option<**i32**> | Account quota | [optional]
**is_active** | Option<**bool**> | Is account active | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


