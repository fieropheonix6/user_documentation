# ItemType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** | The ID of the item type. | 
**name** | **String** | The name of the item type | 
**string_id** | **String** | The string identifier of the item type. | 
**icon** | **String** | The string identifying the icon of the item type. | 
**public_description** | **String** | The description of the item type. | 
**is_selectable** | **bool** | The selectable status | 
**url_name** | **String** | The URL name of the item type. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


