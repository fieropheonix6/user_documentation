# AccountReport

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** | A unique ID for the AccountRecord | 
**account_id** | **i32** | The ID of the account which generated this report. | 
**created_date** | **String** | Date when the AccountReport was requested | 
**status** | **String** | Status of the report | 
**download_url** | **String** | The download link for the generated XLSX | 
**group_id** | **i32** | The group ID that was used to filter the report, if any. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


