# CustomArticleField

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Custom  metadata name | 
**value** | [**serde_json::Value**](.md) | Custom metadata value (can be either a string or an array of strings) | 
**field_type** | **String** | Custom field type | 
**settings** | [**serde_json::Value**](.md) | Settings for the custom field | 
**order** | **i32** | Order of the custom field | 
**is_mandatory** | **bool** | Whether the field is mandatory or not | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


