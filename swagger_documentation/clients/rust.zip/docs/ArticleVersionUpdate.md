# ArticleVersionUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supplementary_fields** | Option<[**Vec<serde_json::Value>**](serde_json::Value.md)> | List of supplementary fields to be associated with the article version | [optional]
**internal_metadata** | Option<[**serde_json::Value**](.md)> | List of supplementary fields to be associated with the article version | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


