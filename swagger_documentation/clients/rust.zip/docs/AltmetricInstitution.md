# AltmetricInstitution

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** | Institution id | 
**name** | **String** | Institution name | 
**custom_domain** | Option<**String**> | Custom domain for the institution | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


