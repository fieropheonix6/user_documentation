# UploadFilePart

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**part_no** | Option<**i32**> | File part id | [optional]
**start_offset** | Option<**i32**> | Indexes on byte range. zero-based and inclusive | [optional]
**end_offset** | Option<**i32**> | Indexes on byte range. zero-based and inclusive | [optional]
**status** | Option<**String**> | part status | [optional]
**locked** | Option<**bool**> | When a part is being uploaded it is being locked, by setting the locked flag to true. No changes/uploads can happen on this part from other requests. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


