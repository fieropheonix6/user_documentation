# CategoriesCreator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | **Vec<i32>** | List of category ids | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


