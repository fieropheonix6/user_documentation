# ShortCustomField

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** | Custom field id | 
**name** | **String** | Custom field name | 
**field_type** | **String** | Custom field type | 
**settings** | Option<[**serde_json::Value**](.md)> | Settings for the custom field | [optional]
**order** | Option<**i32**> | Order of the field in the group | [optional]
**is_mandatory** | Option<**bool**> | Whether the field is mandatory or not | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


