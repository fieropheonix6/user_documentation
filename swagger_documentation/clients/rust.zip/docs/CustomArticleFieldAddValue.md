# CustomArticleFieldAddValue

## Enum Variants

| Name | Description |
|---- | -----|
| String | Custom metadata value (can be either a string, an array of strings, or empty) |
| Vec<String> | Custom metadata value (can be either a string, an array of strings, or empty) |
| serde_json::Value | Custom metadata value (can be either a string, an array of strings, or empty) |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


