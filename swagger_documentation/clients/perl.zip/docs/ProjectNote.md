# WWW::OpenAPIClient::Object::ProjectNote

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ProjectNote;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Project note id | 
**user_id** | **int** | User who wrote the note | 
**abstract** | **string** | Note Abstract - short/truncated content | 
**user_name** | **string** | Username of the one who wrote the note | 
**created_date** | **string** | Date when note was created | 
**modified_date** | **string** | Date when note was last modified | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


