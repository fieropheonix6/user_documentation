# WWW::OpenAPIClient::Object::ProjectComplete

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ProjectComplete;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **string** | Project funding | 
**funding_list** | [**ARRAY[FundingInformation]**](FundingInformation.md) | Full Project funding information | 
**description** | **string** | Project description | 
**collaborators** | [**ARRAY[Collaborator]**](Collaborator.md) | List of project collaborators | 
**custom_fields** | [**ARRAY[CustomArticleField]**](CustomArticleField.md) | Project custom fields | 
**modified_date** | **string** | Date when project was last modified | 
**created_date** | **string** | Date when project was created | 
**url** | **string** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **string** | Project title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


