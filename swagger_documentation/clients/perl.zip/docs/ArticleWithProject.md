# WWW::SwaggerClient::Object::ArticleWithProject

## Load the model package
```perl
use WWW::SwaggerClient::Object::ArticleWithProject;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique identifier for article | 
**title** | **string** | Title of article | 
**doi** | **string** | DOI | 
**handle** | **string** | Handle | 
**url** | **string** | Api endpoint for article | 
**url_public_html** | **string** | Public site endpoint for article | 
**url_public_api** | **string** | Public Api endpoint for article | 
**url_private_html** | **string** | Private site endpoint for article | 
**url_private_api** | **string** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**thumb** | **string** | Thumbnail image | 
**defined_type** | **int** | Type of article identifier | 
**defined_type_name** | **string** | Name of the article type identifier | 
**resource_doi** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to &#39;&#39;]
**resource_title** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to &#39;&#39;]
**created_date** | **string** | Date when article was created | 
**project_id** | **int** | Project id for this article. | [default to 0]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


