# WWW::OpenAPIClient::Object::CustomArticleFieldAdd

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CustomArticleFieldAdd;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Custom  metadata name | 
**value** | [**CustomArticleFieldAddValue**](CustomArticleFieldAddValue.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


