# WWW::OpenAPIClient::SymplecticApi

## Load the API package
```perl
use WWW::OpenAPIClient::Object::SymplecticApi;
```

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**symplectic_account_articles**](SymplecticApi.md#symplectic_account_articles) | **GET** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account
[**symplectic_accounts_ids**](SymplecticApi.md#symplectic_accounts_ids) | **GET** /symplectic/accounts | Get changed accounts for Symplectic Elements
[**symplectic_article**](SymplecticApi.md#symplectic_article) | **GET** /symplectic/articles/{article_id} | Get article details for Symplectic Elements
[**symplectic_changed_articles**](SymplecticApi.md#symplectic_changed_articles) | **GET** /symplectic/articles | Get changed articles for Symplectic Elements
[**symplectic_user_id**](SymplecticApi.md#symplectic_user_id) | **GET** /symplectic/users/{user_id} | Get institutional user ID for a user


# **symplectic_account_articles**
> ARRAY[object] symplectic_account_articles(external_user_id => $external_user_id, offset => $offset, limit => $limit, status => $status, is_embargoed => $is_embargoed)

Get articles for a specific account

Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::SymplecticApi;
my $api_instance = WWW::OpenAPIClient::SymplecticApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $external_user_id = "external_user_id_example"; # string | External user ID (symplectic_user_id or institution_user_id)
my $offset = 0; # int | Number of results to skip for pagination
my $limit = 10; # int | Maximum number of results to return
my $status = "status_example"; # string | Filter by article status
my $is_embargoed = "is_embargoed_example"; # string | Filter by embargo status

eval {
    my $result = $api_instance->symplectic_account_articles(external_user_id => $external_user_id, offset => $offset, limit => $limit, status => $status, is_embargoed => $is_embargoed);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SymplecticApi->symplectic_account_articles: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **external_user_id** | **string**| External user ID (symplectic_user_id or institution_user_id) | 
 **offset** | **int**| Number of results to skip for pagination | [optional] [default to 0]
 **limit** | **int**| Maximum number of results to return | [optional] [default to 10]
 **status** | **string**| Filter by article status | [optional] 
 **is_embargoed** | **string**| Filter by embargo status | [optional] 

### Return type

**ARRAY[object]**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplectic_accounts_ids**
> ARRAY[SymplecticAccountsIds200ResponseInner] symplectic_accounts_ids(since => $since)

Get changed accounts for Symplectic Elements

Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::SymplecticApi;
my $api_instance = WWW::OpenAPIClient::SymplecticApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $since = 2015-01-01 00:00:00; # string | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)

eval {
    my $result = $api_instance->symplectic_accounts_ids(since => $since);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SymplecticApi->symplectic_accounts_ids: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **since** | **string**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | 

### Return type

[**ARRAY[SymplecticAccountsIds200ResponseInner]**](SymplecticAccountsIds200ResponseInner.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplectic_article**
> object symplectic_article(article_id => $article_id)

Get article details for Symplectic Elements

Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::SymplecticApi;
my $api_instance = WWW::OpenAPIClient::SymplecticApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $article_id = 56; # int | Article ID

eval {
    my $result = $api_instance->symplectic_article(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SymplecticApi->symplectic_article: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article ID | 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplectic_changed_articles**
> ARRAY[object] symplectic_changed_articles(since => $since, offset => $offset, limit => $limit, status => $status, is_embargoed => $is_embargoed)

Get changed articles for Symplectic Elements

Returns a list of articles for Symplectic Elements integration to synchronize article data.

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::SymplecticApi;
my $api_instance = WWW::OpenAPIClient::SymplecticApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $since = 2015-01-01 00:00:00; # string | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
my $offset = 0; # int | Number of results to skip for pagination
my $limit = 10; # int | Maximum number of results to return
my $status = "status_example"; # string | Filter by article status
my $is_embargoed = "is_embargoed_example"; # string | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type

eval {
    my $result = $api_instance->symplectic_changed_articles(since => $since, offset => $offset, limit => $limit, status => $status, is_embargoed => $is_embargoed);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SymplecticApi->symplectic_changed_articles: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **since** | **string**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | 
 **offset** | **int**| Number of results to skip for pagination | [optional] [default to 0]
 **limit** | **int**| Maximum number of results to return | [optional] [default to 10]
 **status** | **string**| Filter by article status | [optional] 
 **is_embargoed** | **string**| Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type | [optional] 

### Return type

**ARRAY[object]**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplectic_user_id**
> SymplecticUserId200Response symplectic_user_id(user_id => $user_id)

Get institutional user ID for a user

Returns the institution user ID for a given user within the authenticated account's institution.

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::SymplecticApi;
my $api_instance = WWW::OpenAPIClient::SymplecticApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $user_id = 56; # int | User ID

eval {
    my $result = $api_instance->symplectic_user_id(user_id => $user_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SymplecticApi->symplectic_user_id: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**| User ID | 

### Return type

[**SymplecticUserId200Response**](SymplecticUserId200Response.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

