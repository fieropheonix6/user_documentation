# WWW::OpenAPIClient::Object::FundingInformation

## Load the model package
```perl
use WWW::OpenAPIClient::Object::FundingInformation;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Funding id | 
**title** | **string** | The funding name | 
**grant_code** | **string** | The grant code | 
**funder_name** | **string** | Funder&#39;s name | 
**is_user_defined** | **int** | Return 1 whether the grant has been introduced manually, 0 otherwise | 
**url** | **string** | The grant url | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


