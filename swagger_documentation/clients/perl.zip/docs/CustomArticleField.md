# WWW::OpenAPIClient::Object::CustomArticleField

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CustomArticleField;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Custom  metadata name | 
**value** | **object** | Custom metadata value (can be either a string or an array of strings) | 
**field_type** | **string** | Custom field type | 
**settings** | **object** | Settings for the custom field | 
**order** | **int** | Order of the custom field | 
**is_mandatory** | **boolean** | Whether the field is mandatory or not | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


