# WWW::SwaggerClient::Object::FundingSearch

## Load the model package
```perl
use WWW::SwaggerClient::Object::FundingSearch;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | **string** | Search term | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


