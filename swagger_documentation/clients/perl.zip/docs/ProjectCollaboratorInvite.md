# WWW::OpenAPIClient::Object::ProjectCollaboratorInvite

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ProjectCollaboratorInvite;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_name** | **string** | Role of the the collaborator inside the project | 
**user_id** | **int** | User id of the collaborator | [optional] 
**email** | **string** | Collaborator email | [optional] 
**comment** | **string** | Text sent when inviting the user to the project | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


