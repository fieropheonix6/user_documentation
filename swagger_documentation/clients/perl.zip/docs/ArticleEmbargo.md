# WWW::SwaggerClient::Object::ArticleEmbargo

## Load the model package
```perl
use WWW::SwaggerClient::Object::ArticleEmbargo;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_embargoed** | **boolean** | True if embargoed | 
**embargo_title** | **string** | Title for embargo | 
**embargo_reason** | **string** | Reason for embargo | 
**embargo_options** | **ARRAY[object]** | List of embargo permissions that are associated with the article. If the type is logged_in and the group_ids list is empty, then the whole institution can see the article; if there are multiple group_ids, then only users that are under those groups can see the article. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


