# WWW::SwaggerClient::InstitutionsApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::InstitutionsApi;
```

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**account_institution_curation**](InstitutionsApi.md#account_institution_curation) | **GET** /account/institution/review/{curation_id} | Institution Curation Review
[**account_institution_curations**](InstitutionsApi.md#account_institution_curations) | **GET** /account/institution/reviews | Institution Curation Reviews
[**custom_fields_list**](InstitutionsApi.md#custom_fields_list) | **GET** /account/institution/custom_fields | Private account institution group custom fields
[**custom_fields_upload**](InstitutionsApi.md#custom_fields_upload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload
[**get_account_institution_curation_comments**](InstitutionsApi.md#get_account_institution_curation_comments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments
[**institution_articles**](InstitutionsApi.md#institution_articles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Institution Articles
[**institution_hrfeed_upload**](InstitutionsApi.md#institution_hrfeed_upload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload
[**post_account_institution_curation_comments**](InstitutionsApi.md#post_account_institution_curation_comments) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment
[**private_account_institution_user**](InstitutionsApi.md#private_account_institution_user) | **GET** /account/institution/users/{account_id} | Private Account Institution User
[**private_categories_list**](InstitutionsApi.md#private_categories_list) | **GET** /account/categories | Private Account Categories
[**private_group_embargo_options_details**](InstitutionsApi.md#private_group_embargo_options_details) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options
[**private_institution_account_group_role_delete**](InstitutionsApi.md#private_institution_account_group_role_delete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role
[**private_institution_account_group_roles**](InstitutionsApi.md#private_institution_account_group_roles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles
[**private_institution_account_group_roles_create**](InstitutionsApi.md#private_institution_account_group_roles_create) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles
[**private_institution_accounts_create**](InstitutionsApi.md#private_institution_accounts_create) | **POST** /account/institution/accounts | Create new Institution Account
[**private_institution_accounts_list**](InstitutionsApi.md#private_institution_accounts_list) | **GET** /account/institution/accounts | Private Account Institution Accounts
[**private_institution_accounts_search**](InstitutionsApi.md#private_institution_accounts_search) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search
[**private_institution_accounts_update**](InstitutionsApi.md#private_institution_accounts_update) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account
[**private_institution_articles**](InstitutionsApi.md#private_institution_articles) | **GET** /account/institution/articles | Private Institution Articles
[**private_institution_details**](InstitutionsApi.md#private_institution_details) | **GET** /account/institution | Private Account Institutions
[**private_institution_embargo_options_details**](InstitutionsApi.md#private_institution_embargo_options_details) | **GET** /account/institution/embargo_options | Private Account Institution embargo options
[**private_institution_groups_list**](InstitutionsApi.md#private_institution_groups_list) | **GET** /account/institution/groups | Private Account Institution Groups
[**private_institution_roles_list**](InstitutionsApi.md#private_institution_roles_list) | **GET** /account/institution/roles | Private Account Institution Roles


# **account_institution_curation**
> CurationDetail account_institution_curation(curation_id => $curation_id)

Institution Curation Review

Retrieve a certain curation review by its ID

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $curation_id = 789; # int | ID of the curation

eval { 
    my $result = $api_instance->account_institution_curation(curation_id => $curation_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->account_institution_curation: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curation_id** | **int**| ID of the curation | 

### Return type

[**CurationDetail**](CurationDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **account_institution_curations**
> Curation account_institution_curations(group_id => $group_id, article_id => $article_id, status => $status, limit => $limit, offset => $offset)

Institution Curation Reviews

Retrieve a list of curation reviews for this institution

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $group_id = 789; # int | Filter by the group ID
my $article_id = 789; # int | Retrieve the reviews for this article
my $status = 'status_example'; # string | Filter by the status of the review
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing(the offset of the first result). Used for pagination with limit

eval { 
    my $result = $api_instance->account_institution_curations(group_id => $group_id, article_id => $article_id, status => $status, limit => $limit, offset => $offset);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->account_institution_curations: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Filter by the group ID | [optional] 
 **article_id** | **int**| Retrieve the reviews for this article | [optional] 
 **status** | **string**| Filter by the status of the review | [optional] 
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**Curation**](Curation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **custom_fields_list**
> ARRAY[ShortCustomField] custom_fields_list(group_id => $group_id)

Private account institution group custom fields

Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $group_id = 789; # int | Group_id

eval { 
    my $result = $api_instance->custom_fields_list(group_id => $group_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->custom_fields_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Group_id | [optional] 

### Return type

[**ARRAY[ShortCustomField]**](ShortCustomField.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **custom_fields_upload**
> object custom_fields_upload(custom_field_id => $custom_field_id, external_file => $external_file)

Custom fields values files upload

Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $custom_field_id = 789; # int | Custom field identifier
my $external_file = '/path/to/file.txt'; # File | CSV file to be uploaded

eval { 
    my $result = $api_instance->custom_fields_upload(custom_field_id => $custom_field_id, external_file => $external_file);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->custom_fields_upload: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **custom_field_id** | **int**| Custom field identifier | 
 **external_file** | **File**| CSV file to be uploaded | [optional] 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_account_institution_curation_comments**
> CurationComment get_account_institution_curation_comments(curation_id => $curation_id, limit => $limit, offset => $offset)

Institution Curation Review Comments

Retrieve a certain curation review's comments.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $curation_id = 789; # int | ID of the curation
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing(the offset of the first result). Used for pagination with limit

eval { 
    my $result = $api_instance->get_account_institution_curation_comments(curation_id => $curation_id, limit => $limit, offset => $offset);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->get_account_institution_curation_comments: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curation_id** | **int**| ID of the curation | 
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**CurationComment**](CurationComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **institution_articles**
> ARRAY[Article] institution_articles(institution_string_id => $institution_string_id, resource_id => $resource_id, filename => $filename)

Public Institution Articles

Returns a list of articles belonging to the institution

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(
);

my $institution_string_id = 'institution_string_id_example'; # string | 
my $resource_id = 'resource_id_example'; # string | 
my $filename = 'filename_example'; # string | 

eval { 
    my $result = $api_instance->institution_articles(institution_string_id => $institution_string_id, resource_id => $resource_id, filename => $filename);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->institution_articles: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **institution_string_id** | **string**|  | 
 **resource_id** | **string**|  | 
 **filename** | **string**|  | 

### Return type

[**ARRAY[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **institution_hrfeed_upload**
> ResponseMessage institution_hrfeed_upload(hrfeed => $hrfeed)

Private Institution HRfeed Upload

More info in the <a href=\"#hr_feed\">HR Feed section</a>

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $hrfeed = '/path/to/file.txt'; # File | You can find an example in the Hr Feed section

eval { 
    my $result = $api_instance->institution_hrfeed_upload(hrfeed => $hrfeed);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->institution_hrfeed_upload: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hrfeed** | **File**| You can find an example in the Hr Feed section | [optional] 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_account_institution_curation_comments**
> post_account_institution_curation_comments(curation_id => $curation_id, curation_comment => $curation_comment)

POST Institution Curation Review Comment

Add a new comment to the review.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $curation_id = 789; # int | ID of the curation
my $curation_comment = WWW::SwaggerClient::Object::CurationCommentCreate->new(); # CurationCommentCreate | The content/value of the comment.

eval { 
    $api_instance->post_account_institution_curation_comments(curation_id => $curation_id, curation_comment => $curation_comment);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->post_account_institution_curation_comments: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curation_id** | **int**| ID of the curation | 
 **curation_comment** | [**CurationCommentCreate**](CurationCommentCreate.md)| The content/value of the comment. | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_account_institution_user**
> User private_account_institution_user(account_id => $account_id)

Private Account Institution User

Retrieve institution user information using the account_id

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $account_id = 789; # int | Account identifier the user is associated to

eval { 
    my $result = $api_instance->private_account_institution_user(account_id => $account_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_account_institution_user: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to | 

### Return type

[**User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_categories_list**
> ARRAY[CategoryList] private_categories_list()

Private Account Categories

List institution categories (including parent Categories)

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);


eval { 
    my $result = $api_instance->private_categories_list();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_categories_list: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ARRAY[CategoryList]**](CategoryList.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_group_embargo_options_details**
> ARRAY[GroupEmbargoOptions] private_group_embargo_options_details(group_id => $group_id)

Private Account Institution Group Embargo Options

Account institution group embargo options details

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $group_id = 789; # int | Group identifier

eval { 
    my $result = $api_instance->private_group_embargo_options_details(group_id => $group_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_group_embargo_options_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Group identifier | 

### Return type

[**ARRAY[GroupEmbargoOptions]**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_account_group_role_delete**
> private_institution_account_group_role_delete(account_id => $account_id, group_id => $group_id, role_id => $role_id)

Delete Institution Account Group Role

Delete Institution Account Group Role

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $account_id = 789; # int | Account identifier for which to remove the role
my $group_id = 789; # int | Group identifier for which to remove the role
my $role_id = 789; # int | Role identifier

eval { 
    $api_instance->private_institution_account_group_role_delete(account_id => $account_id, group_id => $group_id, role_id => $role_id);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_account_group_role_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier for which to remove the role | 
 **group_id** | **int**| Group identifier for which to remove the role | 
 **role_id** | **int**| Role identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_account_group_roles**
> AccountGroupRoles private_institution_account_group_roles(account_id => $account_id)

List Institution Account Group Roles

List Institution Account Group Roles

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $account_id = 789; # int | Account identifier the user is associated to

eval { 
    my $result = $api_instance->private_institution_account_group_roles(account_id => $account_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_account_group_roles: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to | 

### Return type

[**AccountGroupRoles**](AccountGroupRoles.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_account_group_roles_create**
> private_institution_account_group_roles_create(account_id => $account_id, account => $account)

Add Institution Account Group Roles

Add Institution Account Group Roles

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $account_id = 789; # int | Account identifier the user is associated to
my $account = WWW::SwaggerClient::Object::AccountGroupRolesCreate->new(); # AccountGroupRolesCreate | Account description

eval { 
    $api_instance->private_institution_account_group_roles_create(account_id => $account_id, account => $account);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_account_group_roles_create: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to | 
 **account** | [**AccountGroupRolesCreate**](AccountGroupRolesCreate.md)| Account description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_accounts_create**
> AccountCreateResponse private_institution_accounts_create(account => $account)

Create new Institution Account

Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $account = WWW::SwaggerClient::Object::AccountCreate->new(); # AccountCreate | Account description

eval { 
    my $result = $api_instance->private_institution_accounts_create(account => $account);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_accounts_create: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account** | [**AccountCreate**](AccountCreate.md)| Account description | 

### Return type

[**AccountCreateResponse**](AccountCreateResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_accounts_list**
> ARRAY[ShortAccount] private_institution_accounts_list(page => $page, page_size => $page_size, limit => $limit, offset => $offset, is_active => $is_active, institution_user_id => $institution_user_id, email => $email, id_lte => $id_lte, id_gte => $id_gte)

Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 789; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing(the offset of the first result). Used for pagination with limit
my $is_active = 789; # int | Filter by active status
my $institution_user_id = 'institution_user_id_example'; # string | Filter by institution_user_id
my $email = 'email_example'; # string | Filter by email
my $id_lte = 789; # int | Retrieve accounts with an ID lower or equal to the specified value
my $id_gte = 789; # int | Retrieve accounts with an ID greater or equal to the specified value

eval { 
    my $result = $api_instance->private_institution_accounts_list(page => $page, page_size => $page_size, limit => $limit, offset => $offset, is_active => $is_active, institution_user_id => $institution_user_id, email => $email, id_lte => $id_lte, id_gte => $id_gte);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_accounts_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **is_active** | **int**| Filter by active status | [optional] 
 **institution_user_id** | **string**| Filter by institution_user_id | [optional] 
 **email** | **string**| Filter by email | [optional] 
 **id_lte** | **int**| Retrieve accounts with an ID lower or equal to the specified value | [optional] 
 **id_gte** | **int**| Retrieve accounts with an ID greater or equal to the specified value | [optional] 

### Return type

[**ARRAY[ShortAccount]**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_accounts_search**
> ARRAY[ShortAccount] private_institution_accounts_search(search => $search)

Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $search = WWW::SwaggerClient::Object::InstitutionAccountsSearch->new(); # InstitutionAccountsSearch | Search Parameters

eval { 
    my $result = $api_instance->private_institution_accounts_search(search => $search);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_accounts_search: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**InstitutionAccountsSearch**](InstitutionAccountsSearch.md)| Search Parameters | 

### Return type

[**ARRAY[ShortAccount]**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_accounts_update**
> private_institution_accounts_update(account_id => $account_id, account => $account)

Update Institution Account

Update Institution Account

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $account_id = 789; # int | Account identifier the user is associated to
my $account = WWW::SwaggerClient::Object::AccountUpdate->new(); # AccountUpdate | Account description

eval { 
    $api_instance->private_institution_accounts_update(account_id => $account_id, account => $account);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_accounts_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to | 
 **account** | [**AccountUpdate**](AccountUpdate.md)| Account description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_articles**
> ARRAY[Article] private_institution_articles(page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction, published_since => $published_since, modified_since => $modified_since, status => $status, resource_doi => $resource_doi, item_type => $item_type, group => $group)

Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 789; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing(the offset of the first result). Used for pagination with limit
my $order = 'order_example'; # string | The field by which to order. Default varies by endpoint/resource.
my $order_direction = 'order_direction_example'; # string | 
my $published_since = 'published_since_example'; # string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
my $modified_since = 'modified_since_example'; # string | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
my $status = 789; # int | only return collections with this status
my $resource_doi = 'resource_doi_example'; # string | only return collections with this resource_doi
my $item_type = 789; # int | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
my $group = 789; # int | only return articles from this group

eval { 
    my $result = $api_instance->private_institution_articles(page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction, published_since => $published_since, modified_since => $modified_since, status => $status, resource_doi => $resource_doi, item_type => $item_type, group => $group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_articles: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **string**|  | [optional] [default to desc]
 **published_since** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **modified_since** | **string**| Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **status** | **int**| only return collections with this status | [optional] 
 **resource_doi** | **string**| only return collections with this resource_doi | [optional] 
 **item_type** | **int**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
 **group** | **int**| only return articles from this group | [optional] 

### Return type

[**ARRAY[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_details**
> Institution private_institution_details()

Private Account Institutions

Account institution details

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);


eval { 
    my $result = $api_instance->private_institution_details();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_details: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Institution**](Institution.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_embargo_options_details**
> ARRAY[GroupEmbargoOptions] private_institution_embargo_options_details()

Private Account Institution embargo options

Account institution embargo options details

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);


eval { 
    my $result = $api_instance->private_institution_embargo_options_details();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_embargo_options_details: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ARRAY[GroupEmbargoOptions]**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_groups_list**
> ARRAY[Group] private_institution_groups_list()

Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);


eval { 
    my $result = $api_instance->private_institution_groups_list();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_groups_list: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ARRAY[Group]**](Group.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_roles_list**
> ARRAY[Role] private_institution_roles_list()

Private Account Institution Roles

Returns the roles available for groups and the institution group.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstitutionsApi;
my $api_instance = WWW::SwaggerClient::InstitutionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);


eval { 
    my $result = $api_instance->private_institution_roles_list();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstitutionsApi->private_institution_roles_list: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ARRAY[Role]**](Role.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

