# WWW::SwaggerClient::Object::CreateOAuthToken

## Load the model package
```perl
use WWW::SwaggerClient::Object::CreateOAuthToken;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_id** | **string** |  | 
**client_secret** | **string** |  | 
**grant_type** | **string** |  | 
**code** | **string** | Required if grant_type is &#39;authorization_code&#39; | [optional] 
**refresh_token** | **string** | Required if grant_type is &#39;refresh_token&#39; | [optional] 
**username** | **string** | Required if grant_type is &#39;password&#39; | [optional] 
**password** | **string** | Required if grant_type is &#39;password&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


