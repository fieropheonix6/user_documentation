# WWW::OpenAPIClient::Object::CollectionVersions

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CollectionVersions;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **int** | Version number | 
**url** | **string** | Api endpoint for the collection version | 
**funding** | [**ARRAY[FundingInformation]**](FundingInformation.md) | Full Collection funding information | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


