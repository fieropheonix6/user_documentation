# WWW::OpenAPIClient::Object::CustomArticleFieldAddValue

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CustomArticleFieldAddValue;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


