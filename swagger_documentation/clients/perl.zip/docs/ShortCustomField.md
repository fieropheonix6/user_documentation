# WWW::OpenAPIClient::Object::ShortCustomField

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ShortCustomField;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Custom field id | 
**name** | **string** | Custom field name | 
**field_type** | **string** | Custom field type | 
**settings** | **object** | Settings for the custom field | [optional] 
**order** | **int** | Order of the field in the group | [optional] 
**is_mandatory** | **boolean** | Whether the field is mandatory or not | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


