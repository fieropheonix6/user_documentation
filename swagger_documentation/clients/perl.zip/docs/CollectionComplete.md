# WWW::OpenAPIClient::Object::CollectionComplete

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CollectionComplete;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | [**ARRAY[FundingInformation]**](FundingInformation.md) | Full Collection funding information | 
**resource_id** | **string** | Collection resource id | 
**resource_doi** | **string** | Collection resource doi | 
**resource_title** | **string** | Collection resource title | 
**resource_link** | **string** | Collection resource link | 
**resource_version** | **int** | Collection resource version | 
**version** | **int** | Collection version | 
**description** | **string** | Collection description | 
**categories** | [**ARRAY[Category]**](Category.md) | List of collection categories | 
**references** | **ARRAY[string]** | List of collection references | 
**related_materials** | [**ARRAY[RelatedMaterial]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | 
**tags** | **ARRAY[string]** | List of collection tags. Keywords can be used instead | 
**keywords** | **ARRAY[string]** | List of collection keywords. Tags can be used instead | 
**authors** | [**ARRAY[Author]**](Author.md) | List of collection authors | 
**institution_id** | **int** | Collection institution | 
**group_id** | **int** | Collection group | 
**articles_count** | **int** | Number of articles in collection | 
**public** | **boolean** | True if collection is published | 
**citation** | **string** | Collection citation | 
**custom_fields** | [**ARRAY[CustomArticleField]**](CustomArticleField.md) | Collection custom fields | 
**modified_date** | **string** | Date when collection was last modified | 
**created_date** | **string** | Date when collection was created | 
**timeline** | [**Timeline**](Timeline.md) |  | 
**id** | **int** | Collection id | 
**title** | **string** | Collection title | 
**doi** | **string** | Collection DOI | 
**handle** | **string** | Collection Handle | 
**url** | **string** | Api endpoint | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


