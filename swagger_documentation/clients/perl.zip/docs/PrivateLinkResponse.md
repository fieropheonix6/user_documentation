# WWW::OpenAPIClient::Object::PrivateLinkResponse

## Load the model package
```perl
use WWW::OpenAPIClient::Object::PrivateLinkResponse;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **string** | Url for private link | 
**html_location** | **string** | HTML url for private link | 
**token** | **string** | Token for private link | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


