# WWW::OpenAPIClient::Object::Resource

## Load the model package
```perl
use WWW::OpenAPIClient::Object::Resource;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | ID of resource item | [optional] [default to &#39;&#39;]
**title** | **string** | Title of resource item | [optional] [default to &#39;&#39;]
**doi** | **string** | DOI of resource item | [optional] [default to &#39;&#39;]
**link** | **string** | Link of resource item | [optional] [default to &#39;&#39;]
**status** | **string** | Status of resource item | [optional] [default to &#39;&#39;]
**version** | **int** | Version of resource item | [optional] [default to 0]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


