# WWW::SwaggerClient::Object::PrivateLink

## Load the model package
```perl
use WWW::SwaggerClient::Object::PrivateLink;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | Private link id | 
**is_active** | **boolean** | True if private link is active | 
**expires_date** | **string** | Date when link will expire | 
**html_location** | **string** | HTML url for private link | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


