# WWW::OpenAPIClient::Object::AltmetricInstitution

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AltmetricInstitution;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Institution id | 
**name** | **string** | Institution name | 
**custom_domain** | **string** | Custom domain for the institution | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


