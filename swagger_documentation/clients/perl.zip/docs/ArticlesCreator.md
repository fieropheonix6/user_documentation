# WWW::SwaggerClient::Object::ArticlesCreator

## Load the model package
```perl
use WWW::SwaggerClient::Object::ArticlesCreator;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | **ARRAY[int]** | List of article ids | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


