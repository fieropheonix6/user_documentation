# WWW::OpenAPIClient::Object::Institution

## Load the model package
```perl
use WWW::OpenAPIClient::Object::Institution;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Institution id | 
**name** | **string** | Institution name | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


