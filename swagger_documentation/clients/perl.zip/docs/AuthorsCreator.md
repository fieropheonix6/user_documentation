# WWW::OpenAPIClient::Object::AuthorsCreator

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AuthorsCreator;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authors** | **ARRAY[object]** | List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


