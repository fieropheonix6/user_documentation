# WWW::OpenAPIClient::Object::CreateProjectResponse

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CreateProjectResponse;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entity_id** | **int** | Figshare ID of the entity | 
**location** | **string** | Url for entity | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


