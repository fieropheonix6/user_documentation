# WWW::SwaggerClient::OauthApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::OauthApi;
```

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_token**](OauthApi.md#create_token) | **POST** /token | Create OAuth token
[**get_token_info**](OauthApi.md#get_token_info) | **GET** /token | Get OAuth token information


# **create_token**
> OAuthToken create_token(body => $body)

Create OAuth token

Creates OAuth token using various grant types

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OauthApi;
my $api_instance = WWW::SwaggerClient::OauthApi->new(
);

my $body = WWW::SwaggerClient::Object::CreateOAuthToken->new(); # CreateOAuthToken | Create OAuth Token Parameters

eval { 
    my $result = $api_instance->create_token(body => $body);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OauthApi->create_token: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateOAuthToken**](CreateOAuthToken.md)| Create OAuth Token Parameters | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_info**
> OAuthToken get_token_info(access_token => $access_token)

Get OAuth token information

Returns information about the current OAuth token

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OauthApi;
my $api_instance = WWW::SwaggerClient::OauthApi->new(
);

my $access_token = 'access_token_example'; # string | OAuth access token

eval { 
    my $result = $api_instance->get_token_info(access_token => $access_token);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OauthApi->get_token_info: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **access_token** | **string**| OAuth access token | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

