# WWW::OpenAPIClient::Object::ProfileUpdateDataPersonalProfilesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ProfileUpdateDataPersonalProfilesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **string** | Label for the personal profile link | [optional] 
**url** | **string** | URL for the personal profile link | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


