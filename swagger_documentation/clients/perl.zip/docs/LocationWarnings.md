# WWW::OpenAPIClient::Object::LocationWarnings

## Load the model package
```perl
use WWW::OpenAPIClient::Object::LocationWarnings;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entity_id** | **int** | Figshare ID of the entity | 
**location** | **string** | Url for entity | 
**warnings** | **ARRAY[string]** | Issues encountered during the operation | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


