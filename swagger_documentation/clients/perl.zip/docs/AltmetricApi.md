# WWW::OpenAPIClient::AltmetricApi

## Load the API package
```perl
use WWW::OpenAPIClient::Object::AltmetricApi;
```

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**altmetric_institutions_list**](AltmetricApi.md#altmetric_institutions_list) | **GET** /altmetric/institutions | List Altmetric Institutions


# **altmetric_institutions_list**
> ARRAY[AltmetricInstitution] altmetric_institutions_list(offset => $offset)

List Altmetric Institutions

Returns a list of institutions available for Altmetric reporting

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::AltmetricApi;
my $api_instance = WWW::OpenAPIClient::AltmetricApi->new(
);

my $offset = 0; # int | Where to start the listing. The offset of the first item.

eval {
    my $result = $api_instance->altmetric_institutions_list(offset => $offset);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling AltmetricApi->altmetric_institutions_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **int**| Where to start the listing. The offset of the first item. | [optional] [default to 0]

### Return type

[**ARRAY[AltmetricInstitution]**](AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

