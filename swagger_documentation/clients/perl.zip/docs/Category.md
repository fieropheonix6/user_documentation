# WWW::OpenAPIClient::Object::Category

## Load the model package
```perl
use WWW::OpenAPIClient::Object::Category;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_id** | **int** | Parent category | 
**id** | **int** | Category id | 
**title** | **string** | Category title | 
**path** | **string** | Path to all ancestor ids | 
**source_id** | **string** | ID in original standard taxonomy | 
**taxonomy_id** | **int** | Internal id of taxonomy the category is part of | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


