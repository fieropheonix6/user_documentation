'use strict';


/**
 * Delete project article
 * Delete project article
 *
 * project_id Long Project unique identifier
 * article_id Long Project Article unique identifier
 * no response value expected for this operation
 **/
exports.private_project_article_delete = function(project_id,article_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Project article details
 * Project article details
 *
 * project_id Long Project unique identifier
 * article_id Long Project Article unique identifier
 * returns PrivateProjectArticle
 **/
exports.private_project_article_details = function(project_id,article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Project article file details
 * Project article file details
 *
 * project_id Long Project unique identifier
 * article_id Long Project Article unique identifier
 * file_id Long File unique identifier
 * returns PrivateFile
 **/
exports.private_project_article_file = function(project_id,article_id,file_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Project article list files
 * List article files
 *
 * project_id Long Project unique identifier
 * article_id Long Project Article unique identifier
 * returns List
 **/
exports.private_project_article_files = function(project_id,article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create project article
 * Create a new Article and associate it with this project
 *
 * project_id Long Project unique identifier
 * article ArticleProjectCreate Article description
 * returns Location
 **/
exports.private_project_articles_create = function(project_id,article) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List project articles
 * List project articles
 *
 * project_id Long Project unique identifier
 * returns List
 **/
exports.private_project_articles_list = function(project_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Remove project collaborator
 * Remove project collaborator
 *
 * project_id Long Project unique identifier
 * user_id Long User unique identifier
 * no response value expected for this operation
 **/
exports.private_project_collaborator__Delete = function(project_id,user_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Invite project collaborators
 * Invite users to collaborate on project or view the project
 *
 * project_id Long Project unique identifier
 * collaborator ProjectCollaboratorInvite viewer or collaborator role. User user_id or email of user
 * returns ResponseMessage
 **/
exports.private_project_collaborators_invite = function(project_id,collaborator) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List project collaborators
 * List Project collaborators and invited users
 *
 * project_id Long Project unique identifier
 * returns List
 **/
exports.private_project_collaborators_list = function(project_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create project
 * Create a new project
 *
 * project ProjectCreate Project  description
 * returns CreateProjectResponse
 **/
exports.private_project_create = function(project) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete project
 * A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 
 *
 * project_id Long Project unique identifier
 * no response value expected for this operation
 **/
exports.private_project_delete = function(project_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * View project details
 * View a private project
 *
 * project_id Long Project unique identifier
 * returns ProjectCompletePrivate
 **/
exports.private_project_details = function(project_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Project Leave
 * Please note: project's owner cannot leave the project.
 *
 * project_id Long Project unique identifier
 * no response value expected for this operation
 **/
exports.private_project_leave = function(project_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Project note details
 *
 * project_id Long Project unique identifier
 * note_id Long Note unique identifier
 * returns ProjectNotePrivate
 **/
exports.private_project_note = function(project_id,note_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete project note
 *
 * project_id Long Project unique identifier
 * note_id Long Note unique identifier
 * no response value expected for this operation
 **/
exports.private_project_note_delete = function(project_id,note_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update project note
 *
 * project_id Long Project unique identifier
 * note_id Long Note unique identifier
 * note ProjectNoteCreate Note message
 * no response value expected for this operation
 **/
exports.private_project_note_update = function(project_id,note_id,note) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create project note
 * Create a new project note
 *
 * project_id Long Project unique identifier
 * note ProjectNoteCreate Note message
 * returns Location
 **/
exports.private_project_notes_create = function(project_id,note) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List project notes
 * List project notes
 *
 * project_id Long Project unique identifier
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * returns List
 **/
exports.private_project_notes_list = function(project_id,page,page_size,limit,offset) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Project Publish
 * Publish a project. Possible after all items inside it are public
 *
 * project_id Long Project unique identifier
 * returns ResponseMessage
 **/
exports.private_project_publish = function(project_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update project
 * Updating an project by passing body parameters; request can also be made with the PATCH method.
 *
 * project_id Long Project unique identifier
 * project ProjectUpdate Project description
 * no response value expected for this operation
 **/
exports.private_project_update = function(project_id,project) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Private Projects
 * List private projects
 *
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * order String The field by which to order. (optional)
 * order_direction String  (optional)
 * storage String only return collections from this institution (optional)
 * roles String Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\". (optional)
 * returns List
 **/
exports.private_projects_list = function(page,page_size,limit,offset,order,order_direction,storage,roles) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Projects search
 * Search inside the private projects
 *
 * search ProjectsSearch Search Parameters (optional)
 * returns List
 **/
exports.private_projects_search = function(search) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Project Articles
 * List articles in project
 *
 * project_id Long Project Unique identifier
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * returns List
 **/
exports.project_articles = function(project_id,page,page_size,limit,offset) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Project
 * View a project
 *
 * project_id Long Project Unique identifier
 * returns ProjectComplete
 **/
exports.project_details = function(project_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Projects
 * Returns a list of public projects
 *
 * xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * order String The field by which to order. Default varies by endpoint/resource. (optional)
 * order_direction String  (optional)
 * institution Long only return collections from this institution (optional)
 * published_since String Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
 * group Long only return collections from this group (optional)
 * returns List
 **/
exports.projects_list = function(xCursor,page,page_size,limit,offset,order,order_direction,institution,published_since,group) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Projects Search
 * Returns a list of public articles
 *
 * xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
 * search ProjectsSearch Search Parameters (optional)
 * returns List
 **/
exports.projects_search = function(xCursor,search) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

