'use strict';


/**
 * Public Collection Articles
 * Returns a list of public collection articles
 *
 * collection_id Long Collection Unique identifier
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * returns List
 **/
exports.collection_articles = function(collection_id,page,page_size,limit,offset) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Collection details
 * View a collection
 *
 * collection_id Long Collection Unique identifier
 * returns CollectionComplete
 **/
exports.collection_details = function(collection_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Collection Version details
 * View details for a certain version of a collection
 *
 * collection_id Long Collection Unique identifier
 * version_id Long Version Number
 * returns CollectionComplete
 **/
exports.collection_version_details = function(collection_id,version_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Collection Versions list
 * Returns a list of public collection Versions
 *
 * collection_id Long Collection Unique identifier
 * returns List
 **/
exports.collection_versions = function(collection_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Collections
 * Returns a list of public collections
 *
 * xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * order String The field by which to order. Default varies by endpoint/resource. (optional)
 * order_direction String  (optional)
 * institution Long only return collections from this institution (optional)
 * published_since String Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD (optional)
 * modified_since String Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD (optional)
 * group Long only return collections from this group (optional)
 * resource_doi String only return collections with this resource_doi (optional)
 * doi String only return collections with this doi (optional)
 * handle String only return collections with this handle (optional)
 * returns List
 **/
exports.collections_list = function(xCursor,page,page_size,limit,offset,order,order_direction,institution,published_since,modified_since,group,resource_doi,doi,handle) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Collections Search
 * Returns a list of public collections
 *
 * xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
 * search CollectionSearch Search Parameters (optional)
 * returns List
 **/
exports.collections_search = function(xCursor,search) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete collection article
 * De-associate article from collection
 *
 * collection_id Long Collection unique identifier
 * article_id Long Collection article unique identifier
 * no response value expected for this operation
 **/
exports.private_collection_article_delete = function(collection_id,article_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Add collection articles
 * Associate new articles with the collection. This will add new articles to the list of already associated articles
 *
 * collection_id Long Collection unique identifier
 * articles ArticlesCreator Articles list
 * returns Location
 **/
exports.private_collection_articles_add = function(collection_id,articles) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List collection articles
 * List collection articles
 *
 * collection_id Long Collection unique identifier
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * returns List
 **/
exports.private_collection_articles_list = function(collection_id,page,page_size,limit,offset) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Replace collection articles
 * Associate new articles with the collection. This will remove all already associated articles and add these new ones
 *
 * collection_id Long Collection unique identifier
 * articles ArticlesCreator Articles List
 * no response value expected for this operation
 **/
exports.private_collection_articles_replace = function(collection_id,articles) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete collection author
 * Delete collection author
 *
 * collection_id Long Collection unique identifier
 * author_id Long Collection Author unique identifier
 * no response value expected for this operation
 **/
exports.private_collection_author_delete = function(collection_id,author_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Add collection authors
 * Associate new authors with the collection. This will add new authors to the list of already associated authors
 *
 * collection_id Long Collection unique identifier
 * authors AuthorsCreator List of authors
 * returns Location
 **/
exports.private_collection_authors_add = function(collection_id,authors) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List collection authors
 * List collection authors
 *
 * collection_id Long Collection unique identifier
 * returns List
 **/
exports.private_collection_authors_list = function(collection_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Replace collection authors
 * Associate new authors with the collection. This will remove all already associated authors and add these new ones
 *
 * collection_id Long Collection unique identifier
 * authors AuthorsCreator List of authors
 * no response value expected for this operation
 **/
exports.private_collection_authors_replace = function(collection_id,authors) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Add collection categories
 * Associate new categories with the collection. This will add new categories to the list of already associated categories
 *
 * collection_id Long Collection unique identifier
 * categories CategoriesCreator Categories list
 * returns Location
 **/
exports.private_collection_categories_add = function(collection_id,categories) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List collection categories
 * List collection categories
 *
 * collection_id Long Collection unique identifier
 * returns List
 **/
exports.private_collection_categories_list = function(collection_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Replace collection categories
 * Associate new categories with the collection. This will remove all already associated categories and add these new ones
 *
 * collection_id Long Collection unique identifier
 * categories CategoriesCreator Categories list
 * no response value expected for this operation
 **/
exports.private_collection_categories_replace = function(collection_id,categories) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete collection category
 * De-associate category from collection
 *
 * collection_id Long Collection unique identifier
 * category_id Long Collection category unique identifier
 * no response value expected for this operation
 **/
exports.private_collection_category_delete = function(collection_id,category_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create collection
 * Create a new Collection by sending collection information
 *
 * collection CollectionCreate Collection description
 * returns LocationWarnings
 **/
exports.private_collection_create = function(collection) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete collection
 * Delete n collection
 *
 * collection_id Long Collection Unique identifier
 * no response value expected for this operation
 **/
exports.private_collection_delete = function(collection_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Collection details
 * View a collection
 *
 * collection_id Long Collection Unique identifier
 * returns CollectionCompletePrivate
 **/
exports.private_collection_details = function(collection_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create collection private link
 * Create new private link
 *
 * collection_id Long Collection unique identifier
 * private_link CollectionPrivateLinkCreator  (optional)
 * returns PrivateLinkResponse
 **/
exports.private_collection_private_link_create = function(collection_id,private_link) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Disable private link
 * Disable/delete private link for this collection
 *
 * collection_id Long Collection unique identifier
 * link_id String Private link token
 * no response value expected for this operation
 **/
exports.private_collection_private_link_delete = function(collection_id,link_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update collection private link
 * Update existing private link for this collection
 *
 * collection_id Long Collection unique identifier
 * link_id String Private link token
 * private_link CollectionPrivateLinkCreator  (optional)
 * no response value expected for this operation
 **/
exports.private_collection_private_link_update = function(collection_id,link_id,private_link) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * List collection private links
 * List article private links
 *
 * collection_id Long Collection unique identifier
 * returns List
 **/
exports.private_collection_private_links_list = function(collection_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Collection Publish
 * When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.
 *
 * collection_id Long Collection Unique identifier
 * returns Location
 **/
exports.private_collection_publish = function(collection_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Collection Reserve DOI
 * Reserve DOI for collection
 *
 * collection_id Long Collection Unique identifier
 * returns CollectionDOI
 **/
exports.private_collection_reserve_doi = function(collection_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Collection Reserve Handle
 * Reserve Handle for collection
 *
 * collection_id Long Collection Unique identifier
 * returns CollectionHandle
 **/
exports.private_collection_reserve_handle = function(collection_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Collection Resource
 * Edit collection resource data.
 *
 * collection_id Long Collection unique identifier
 * resource Resource Resource data
 * returns Location
 **/
exports.private_collection_resource = function(collection_id,resource) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update collection
 * Update collection details; request can also be made with the PATCH method.
 *
 * collection_id Long Collection Unique identifier
 * collection CollectionUpdate Collection description
 * returns LocationWarningsUpdate
 **/
exports.private_collection_update = function(collection_id,collection) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Collections List
 * List private collections
 *
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * order String The field by which to order. Default varies by endpoint/resource. (optional)
 * order_direction String  (optional)
 * returns List
 **/
exports.private_collections_list = function(page,page_size,limit,offset,order,order_direction) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Collections Search
 * Returns a list of private Collections
 *
 * search PrivateCollectionSearch Search Parameters
 * returns List
 **/
exports.private_collections_search = function(search) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

