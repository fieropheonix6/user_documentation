'use strict';

var utils = require('../utils/writer.js');
var Oauth = require('../service/OauthService');

module.exports.create_token = function create_token (req, res, next) {
  var body = req.swagger.params['body'].value;
  Oauth.create_token(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_token_info = function get_token_info (req, res, next) {
  var access_token = req.swagger.params['access_token'].value;
  Oauth.get_token_info(access_token)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
