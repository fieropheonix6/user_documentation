'use strict';

var utils = require('../utils/writer.js');
var Projects = require('../service/ProjectsService');

module.exports.private_project_article_delete = function private_project_article_delete (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var article_id = req.swagger.params['article_id'].value;
  Projects.private_project_article_delete(project_id,article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_article_details = function private_project_article_details (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var article_id = req.swagger.params['article_id'].value;
  Projects.private_project_article_details(project_id,article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_article_file = function private_project_article_file (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var article_id = req.swagger.params['article_id'].value;
  var file_id = req.swagger.params['file_id'].value;
  Projects.private_project_article_file(project_id,article_id,file_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_article_files = function private_project_article_files (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var article_id = req.swagger.params['article_id'].value;
  Projects.private_project_article_files(project_id,article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_articles_create = function private_project_articles_create (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var article = req.swagger.params['Article'].value;
  Projects.private_project_articles_create(project_id,article)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_articles_list = function private_project_articles_list (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  Projects.private_project_articles_list(project_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_collaborator__Delete = function private_project_collaborator__Delete (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var user_id = req.swagger.params['user_id'].value;
  Projects.private_project_collaborator__Delete(project_id,user_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_collaborators_invite = function private_project_collaborators_invite (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var collaborator = req.swagger.params['Collaborator'].value;
  Projects.private_project_collaborators_invite(project_id,collaborator)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_collaborators_list = function private_project_collaborators_list (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  Projects.private_project_collaborators_list(project_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_create = function private_project_create (req, res, next) {
  var project = req.swagger.params['Project'].value;
  Projects.private_project_create(project)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_delete = function private_project_delete (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  Projects.private_project_delete(project_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_details = function private_project_details (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  Projects.private_project_details(project_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_leave = function private_project_leave (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  Projects.private_project_leave(project_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_note = function private_project_note (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var note_id = req.swagger.params['note_id'].value;
  Projects.private_project_note(project_id,note_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_note_delete = function private_project_note_delete (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var note_id = req.swagger.params['note_id'].value;
  Projects.private_project_note_delete(project_id,note_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_note_update = function private_project_note_update (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var note_id = req.swagger.params['note_id'].value;
  var note = req.swagger.params['Note'].value;
  Projects.private_project_note_update(project_id,note_id,note)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_notes_create = function private_project_notes_create (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var note = req.swagger.params['Note'].value;
  Projects.private_project_notes_create(project_id,note)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_notes_list = function private_project_notes_list (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  Projects.private_project_notes_list(project_id,page,page_size,limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_publish = function private_project_publish (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  Projects.private_project_publish(project_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_project_update = function private_project_update (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var project = req.swagger.params['Project'].value;
  Projects.private_project_update(project_id,project)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_projects_list = function private_projects_list (req, res, next) {
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  var order = req.swagger.params['order'].value;
  var order_direction = req.swagger.params['order_direction'].value;
  var storage = req.swagger.params['storage'].value;
  var roles = req.swagger.params['roles'].value;
  Projects.private_projects_list(page,page_size,limit,offset,order,order_direction,storage,roles)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_projects_search = function private_projects_search (req, res, next) {
  var search = req.swagger.params['search'].value;
  Projects.private_projects_search(search)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.project_articles = function project_articles (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  Projects.project_articles(project_id,page,page_size,limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.project_details = function project_details (req, res, next) {
  var project_id = req.swagger.params['project_id'].value;
  Projects.project_details(project_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.projects_list = function projects_list (req, res, next) {
  var xCursor = req.swagger.params['X-Cursor'].value;
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  var order = req.swagger.params['order'].value;
  var order_direction = req.swagger.params['order_direction'].value;
  var institution = req.swagger.params['institution'].value;
  var published_since = req.swagger.params['published_since'].value;
  var group = req.swagger.params['group'].value;
  Projects.projects_list(xCursor,page,page_size,limit,offset,order,order_direction,institution,published_since,group)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.projects_search = function projects_search (req, res, next) {
  var xCursor = req.swagger.params['X-Cursor'].value;
  var search = req.swagger.params['search'].value;
  Projects.projects_search(xCursor,search)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
