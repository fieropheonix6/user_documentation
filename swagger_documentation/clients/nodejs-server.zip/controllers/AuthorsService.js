'use strict';

exports.private_author_details = function(args, res, next) {
  /**
   * Author details
   * View author details
   *
   * author_id Long Author unique identifier
   * returns AuthorComplete
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_authors_search = function(args, res, next) {
  /**
   * Search Authors
   * Search for authors
   *
   * search PrivateAuthorsSearch Search Parameters (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "orcid_id" : "1234-5678-9123-1234",
  "url_name" : "John_Doe",
  "full_name" : "John Doe",
  "is_active" : false,
  "id" : 97657
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

