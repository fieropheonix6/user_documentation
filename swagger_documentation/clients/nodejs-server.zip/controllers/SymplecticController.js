/**
 * The SymplecticController file is a very simple one, which does not need to be changed manually,
 * unless there's a case where business logic routes the request to an entity which is not
 * the service.
 * The heavy lifting of the Controller item is done in Request.js - that is where request
 * parameters are extracted and sent to the service, and where response is handled.
 */

const Controller = require('./Controller');
const service = require('../services/SymplecticService');
const symplectic_account_articles = async (request, response) => {
  await Controller.handleRequest(request, response, service.symplectic_account_articles);
};

const symplectic_accounts_ids = async (request, response) => {
  await Controller.handleRequest(request, response, service.symplectic_accounts_ids);
};

const symplectic_article = async (request, response) => {
  await Controller.handleRequest(request, response, service.symplectic_article);
};

const symplectic_changed_articles = async (request, response) => {
  await Controller.handleRequest(request, response, service.symplectic_changed_articles);
};

const symplectic_user_id = async (request, response) => {
  await Controller.handleRequest(request, response, service.symplectic_user_id);
};


module.exports = {
  symplectic_account_articles,
  symplectic_accounts_ids,
  symplectic_article,
  symplectic_changed_articles,
  symplectic_user_id,
};
