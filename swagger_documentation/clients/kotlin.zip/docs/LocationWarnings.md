
# LocationWarnings

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **entityId** | **kotlin.Int** | Figshare ID of the entity |  |
| **location** | **kotlin.String** | Url for entity |  |
| **warnings** | **kotlin.collections.List&lt;kotlin.String&gt;** | Issues encountered during the operation |  |



