
# Category

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **parentId** | **kotlin.Int** | Parent category |  |
| **id** | **kotlin.Int** | Category id |  |
| **title** | **kotlin.String** | Category title |  |
| **path** | **kotlin.String** | Path to all ancestor ids |  |
| **sourceId** | **kotlin.String** | ID in original standard taxonomy |  |
| **taxonomyId** | **kotlin.Int** | Internal id of taxonomy the category is part of |  |



