
# UploadFilePart

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **partNo** | **kotlin.Int** | File part id |  [optional] |
| **startOffset** | **kotlin.Int** | Indexes on byte range. zero-based and inclusive |  [optional] |
| **endOffset** | **kotlin.Int** | Indexes on byte range. zero-based and inclusive |  [optional] |
| **status** | [**inline**](#Status) | part status |  [optional] |
| **locked** | **kotlin.Boolean** | When a part is being uploaded it is being locked, by setting the locked flag to true. No changes/uploads can happen on this part from other requests. |  [optional] |


<a id="Status"></a>
## Enum: status
| Name | Value |
| ---- | ----- |
| status | PENDING, COMPLETE |



