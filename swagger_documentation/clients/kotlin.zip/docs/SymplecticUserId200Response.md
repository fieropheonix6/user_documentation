
# SymplecticUserId200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **institutionUserId** | **kotlin.String** |  |  [optional] |



