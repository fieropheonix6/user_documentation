
# Institution

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** | Institution id |  |
| **name** | **kotlin.String** | Institution name |  |



