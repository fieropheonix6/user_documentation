
# CreateProjectResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **entityId** | **kotlin.Int** | Figshare ID of the entity |  |
| **location** | **kotlin.String** | Url for entity |  |



