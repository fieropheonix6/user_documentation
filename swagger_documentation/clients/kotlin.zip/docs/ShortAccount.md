
# ShortAccount

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** | Account id |  |
| **firstName** | **kotlin.String** | First Name |  |
| **lastName** | **kotlin.String** | Last Name |  |
| **institutionId** | **kotlin.Int** | Account institution |  |
| **email** | **kotlin.String** | User email |  |
| **active** | **kotlin.Int** | Account activity status |  |
| **institutionUserId** | **kotlin.String** | Account institution user id |  |
| **quota** | **kotlin.Int** | Total storage available to account, in bytes |  |
| **usedQuota** | **kotlin.Int** | Storage used by the account, in bytes |  |
| **userId** | **kotlin.Int** | User id associated with account, useful for example for adding the account as an author to an item |  |
| **orcidId** | **kotlin.String** | ORCID iD associated to account |  |
| **symplecticUserId** | **kotlin.String** | Symplectic ID associated to account |  |



