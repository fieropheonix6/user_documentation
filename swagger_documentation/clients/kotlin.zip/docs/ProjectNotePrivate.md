
# ProjectNotePrivate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **text** | **kotlin.String** | Full text of note |  |
| **id** | **kotlin.Int** | Project note id |  |
| **userId** | **kotlin.Int** | User who wrote the note |  |
| **&#x60;abstract&#x60;** | **kotlin.String** | Note Abstract - short/truncated content |  |
| **userName** | **kotlin.String** | Username of the one who wrote the note |  |
| **createdDate** | **kotlin.String** | Date when note was created |  |
| **modifiedDate** | **kotlin.String** | Date when note was last modified |  |



