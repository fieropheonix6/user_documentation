
# AccountReport

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** | A unique ID for the AccountRecord |  |
| **accountId** | **kotlin.Int** | The ID of the account which generated this report. |  |
| **createdDate** | **kotlin.String** | Date when the AccountReport was requested |  |
| **status** | [**inline**](#Status) | Status of the report |  |
| **downloadUrl** | **kotlin.String** | The download link for the generated XLSX |  |
| **groupId** | **kotlin.Int** | The group ID that was used to filter the report, if any. |  |


<a id="Status"></a>
## Enum: status
| Name | Value |
| ---- | ----- |
| status | missing, pending, done |



