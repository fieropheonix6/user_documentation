
# ArticleEmbargo

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **isEmbargoed** | **kotlin.Boolean** | True if embargoed |  |
| **embargoTitle** | **kotlin.String** | Title for embargo |  |
| **embargoReason** | **kotlin.String** | Reason for embargo |  |
| **embargoOptions** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) | List of embargo permissions that are associated with the article. If the type is logged_in and the group_ids list is empty, then the whole institution can see the article; if there are multiple group_ids, then only users that are under those groups can see the article. |  |



