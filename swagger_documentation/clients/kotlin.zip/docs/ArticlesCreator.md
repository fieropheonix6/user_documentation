
# ArticlesCreator

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **articles** | **kotlin.collections.List&lt;kotlin.Int&gt;** | List of article ids |  |



