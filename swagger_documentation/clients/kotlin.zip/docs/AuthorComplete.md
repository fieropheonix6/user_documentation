
# AuthorComplete

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **institutionId** | **kotlin.Int** | Institution id |  |
| **groupId** | **kotlin.Int** | Group id |  |
| **firstName** | **kotlin.String** | First Name |  |
| **lastName** | **kotlin.String** | Last Name |  |
| **isPublic** | **kotlin.Int** | if 1 then the author has published items |  |
| **jobTitle** | **kotlin.String** | Job title |  |
| **id** | **kotlin.Int** | Author id |  |
| **fullName** | **kotlin.String** | Author full name |  |
| **isActive** | **kotlin.Boolean** | True if author has published items |  |
| **urlName** | **kotlin.String** | Author url name |  |
| **orcidId** | **kotlin.String** | Author Orcid |  |



