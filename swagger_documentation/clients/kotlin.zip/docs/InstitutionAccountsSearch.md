
# InstitutionAccountsSearch

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **searchFor** | **kotlin.String** | Search term |  [optional] |
| **isActive** | **kotlin.Int** | Filter by active status |  [optional] |
| **page** | **kotlin.Int** | Page number. Used for pagination with page_size |  [optional] |
| **pageSize** | **kotlin.Int** | The number of results included on a page. Used for pagination with page |  [optional] |
| **limit** | **kotlin.Int** | Number of results included on a page. Used for pagination with query |  [optional] |
| **offset** | **kotlin.Int** | Where to start the listing (the offset of the first result). Used for pagination with limit |  [optional] |
| **institutionUserId** | **kotlin.String** | filter by institution_user_id |  [optional] |
| **email** | **kotlin.String** | filter by email |  [optional] |



