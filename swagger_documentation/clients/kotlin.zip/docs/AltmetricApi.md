# AltmetricApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**altmetricInstitutionsList**](AltmetricApi.md#altmetricInstitutionsList) | **GET** /altmetric/institutions | List Altmetric Institutions |


<a id="altmetricInstitutionsList"></a>
# **altmetricInstitutionsList**
> kotlin.collections.List&lt;AltmetricInstitution&gt; altmetricInstitutionsList(offset)

List Altmetric Institutions

Returns a list of institutions available for Altmetric reporting

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = AltmetricApi()
val offset : kotlin.Int = 56 // kotlin.Int | Where to start the listing. The offset of the first item.
try {
    val result : kotlin.collections.List<AltmetricInstitution> = apiInstance.altmetricInstitutionsList(offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AltmetricApi#altmetricInstitutionsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AltmetricApi#altmetricInstitutionsList")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Int**| Where to start the listing. The offset of the first item. | [optional] [default to 0] |

### Return type

[**kotlin.collections.List&lt;AltmetricInstitution&gt;**](AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

