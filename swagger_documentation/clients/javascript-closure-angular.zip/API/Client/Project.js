goog.provide('API.Client.Project');

/**
 * @record
 */
API.Client.Project = function() {}

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.Project.prototype.url;

/**
 * Project id
 * @type {!number}
 * @export
 */
API.Client.Project.prototype.id;

/**
 * Project title
 * @type {!string}
 * @export
 */
API.Client.Project.prototype.title;

/**
 * Date when project was created
 * @type {!string}
 * @export
 */
API.Client.Project.prototype.createdDate;

/**
 * Date when project was last modified
 * @type {!string}
 * @export
 */
API.Client.Project.prototype.modifiedDate;

