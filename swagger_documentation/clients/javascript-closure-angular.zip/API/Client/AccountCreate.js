goog.provide('API.Client.AccountCreate');

/**
 * @record
 */
API.Client.AccountCreate = function() {}

/**
 * Email of account
 * @type {!string}
 * @export
 */
API.Client.AccountCreate.prototype.email;

/**
 * First Name
 * @type {!string}
 * @export
 */
API.Client.AccountCreate.prototype.firstName;

/**
 * Last Name
 * @type {!string}
 * @export
 */
API.Client.AccountCreate.prototype.lastName;

/**
 * Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
 * @type {!number}
 * @export
 */
API.Client.AccountCreate.prototype.groupId;

/**
 * Institution user id
 * @type {!string}
 * @export
 */
API.Client.AccountCreate.prototype.institutionUserId;

/**
 * Symplectic user id
 * @type {!string}
 * @export
 */
API.Client.AccountCreate.prototype.symplecticUserId;

/**
 * Account quota
 * @type {!number}
 * @export
 */
API.Client.AccountCreate.prototype.quota;

/**
 * Is account active
 * @type {!boolean}
 * @export
 */
API.Client.AccountCreate.prototype.isActive;

