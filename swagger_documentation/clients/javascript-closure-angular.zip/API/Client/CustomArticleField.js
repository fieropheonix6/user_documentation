goog.provide('API.Client.CustomArticleField');

/**
 * @record
 */
API.Client.CustomArticleField = function() {}

/**
 * Custom  metadata name
 * @type {!string}
 * @export
 */
API.Client.CustomArticleField.prototype.name;

/**
 * Custom metadata value (can be either a string or an array of strings)
 * @type {!API.Client.Object}
 * @export
 */
API.Client.CustomArticleField.prototype.value;

