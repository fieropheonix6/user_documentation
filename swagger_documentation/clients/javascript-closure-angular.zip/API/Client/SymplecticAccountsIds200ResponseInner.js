goog.provide('API.Client.symplectic_accounts_ids_200_response_inner');

/**
 * @record
 */
API.Client.SymplecticAccountsIds200ResponseInner = function() {}

/**
 * @type {!string}
 * @export
 */
API.Client.SymplecticAccountsIds200ResponseInner.prototype.institutionUserId;

/**
 * @type {!Date}
 * @export
 */
API.Client.SymplecticAccountsIds200ResponseInner.prototype.modifiedDate;

