goog.provide('API.Client.CollectionVersions');

/**
 * @record
 */
API.Client.CollectionVersions = function() {}

/**
 * Version number
 * @type {!number}
 * @export
 */
API.Client.CollectionVersions.prototype.version;

/**
 * Api endpoint for the collection version
 * @type {!string}
 * @export
 */
API.Client.CollectionVersions.prototype.url;

/**
 * Full Collection funding information
 * @type {!Array<!API.Client.FundingInformation>}
 * @export
 */
API.Client.CollectionVersions.prototype.funding;

