goog.provide('API.Client.CollectionCompletePrivate');

/**
 * @record
 */
API.Client.CollectionCompletePrivate = function() {}

/**
 * Collection id
 * @type {!number}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.id;

/**
 * Collection title
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.title;

/**
 * Collection DOI
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.doi;

/**
 * Collection Handle
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.handle;

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.url;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.timeline;

/**
 * ID of the account owning the collection
 * @type {!number}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.accountId;

/**
 * Full Collection funding information
 * @type {!Array<!API.Client.FundingInformation>}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.funding;

/**
 * Collection resource id
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.resourceId;

/**
 * Collection resource doi
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.resourceDoi;

/**
 * Collection resource title
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.resourceTitle;

/**
 * Collection resource link
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.resourceLink;

/**
 * Collection resource version
 * @type {!number}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.resourceVersion;

/**
 * Collection version
 * @type {!number}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.version;

/**
 * Collection description
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.description;

/**
 * List of collection categories
 * @type {!Array<!API.Client.Category>}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.categories;

/**
 * List of collection references
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.references;

/**
 * List of collection tags
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.tags;

/**
 * List of collection authors
 * @type {!Array<!API.Client.Author>}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.authors;

/**
 * Collection institution
 * @type {!number}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.institutionId;

/**
 * Collection group
 * @type {!number}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.groupId;

/**
 * Number of articles in collection
 * @type {!number}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.articlesCount;

/**
 * True if collection is published
 * @type {!boolean}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype._public;

/**
 * Collection citation
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.citation;

/**
 * Collection custom fields
 * @type {!Array<!API.Client.CustomArticleField>}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.customFields;

/**
 * Date when collection was last modified
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.modifiedDate;

/**
 * Date when collection was created
 * @type {!string}
 * @export
 */
API.Client.CollectionCompletePrivate.prototype.createdDate;

