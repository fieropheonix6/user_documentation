goog.provide('API.Client.PublicFileWithFolder');

/**
 * @record
 */
API.Client.PublicFileWithFolder = function() {}

/**
 * List of files with folder information.
 * @type {!Array<!API.Client.PublicFile>}
 * @export
 */
API.Client.PublicFileWithFolder.prototype.files;

/**
 * Mapping of file ids to folder paths, if folders are used
 * @type {!API.Client.Object}
 * @export
 */
API.Client.PublicFileWithFolder.prototype.folderStructure;

