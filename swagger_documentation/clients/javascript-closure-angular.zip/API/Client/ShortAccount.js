goog.provide('API.Client.ShortAccount');

/**
 * @record
 */
API.Client.ShortAccount = function() {}

/**
 * Account id
 * @type {!number}
 * @export
 */
API.Client.ShortAccount.prototype.id;

/**
 * First Name
 * @type {!string}
 * @export
 */
API.Client.ShortAccount.prototype.firstName;

/**
 * Last Name
 * @type {!string}
 * @export
 */
API.Client.ShortAccount.prototype.lastName;

/**
 * Account institution
 * @type {!number}
 * @export
 */
API.Client.ShortAccount.prototype.institutionId;

/**
 * User email
 * @type {!string}
 * @export
 */
API.Client.ShortAccount.prototype.email;

/**
 * Account activity status
 * @type {!number}
 * @export
 */
API.Client.ShortAccount.prototype.active;

/**
 * Account institution user id
 * @type {!string}
 * @export
 */
API.Client.ShortAccount.prototype.institutionUserId;

/**
 * Total storage available to account, in bytes
 * @type {!number}
 * @export
 */
API.Client.ShortAccount.prototype.quota;

/**
 * Storage used by the account, in bytes
 * @type {!number}
 * @export
 */
API.Client.ShortAccount.prototype.usedQuota;

/**
 * User id associated with account, useful for example for adding the account as an author to an item
 * @type {!number}
 * @export
 */
API.Client.ShortAccount.prototype.userId;

/**
 * ORCID iD associated to account
 * @type {!string}
 * @export
 */
API.Client.ShortAccount.prototype.orcidId;

/**
 * Symplectic ID associated to account
 * @type {!string}
 * @export
 */
API.Client.ShortAccount.prototype.symplecticUserId;

