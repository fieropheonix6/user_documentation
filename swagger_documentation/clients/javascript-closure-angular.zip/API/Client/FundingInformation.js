goog.provide('API.Client.FundingInformation');

/**
 * @record
 */
API.Client.FundingInformation = function() {}

/**
 * Funding id
 * @type {!number}
 * @export
 */
API.Client.FundingInformation.prototype.id;

/**
 * The funding name
 * @type {!string}
 * @export
 */
API.Client.FundingInformation.prototype.title;

/**
 * The grant code
 * @type {!string}
 * @export
 */
API.Client.FundingInformation.prototype.grantCode;

/**
 * Funder's name
 * @type {!string}
 * @export
 */
API.Client.FundingInformation.prototype.funderName;

/**
 * Return 1 whether the grant has been introduced manually, 0 otherwise
 * @type {!number}
 * @export
 */
API.Client.FundingInformation.prototype.isUserDefined;

/**
 * The grant url
 * @type {!string}
 * @export
 */
API.Client.FundingInformation.prototype.url;

