goog.provide('API.Client.CollectionDOI');

/**
 * @record
 */
API.Client.CollectionDOI = function() {}

/**
 * Reserved DOI
 * @type {!string}
 * @export
 */
API.Client.CollectionDOI.prototype.doi;

