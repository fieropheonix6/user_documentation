goog.provide('API.Client.CurationComment');

/**
 * @record
 */
API.Client.CurationComment = function() {}

/**
 * The ID of the comment.
 * @type {!number}
 * @export
 */
API.Client.CurationComment.prototype.id;

/**
 * The ID of the account which generated this comment.
 * @type {!number}
 * @export
 */
API.Client.CurationComment.prototype.accountId;

/**
 * The ID of the account which generated this comment.
 * @type {!string}
 * @export
 */
API.Client.CurationComment.prototype.type;

/**
 * The value/content of the comment.
 * @type {!string}
 * @export
 */
API.Client.CurationComment.prototype.text;

/**
 * The creation date of the comment.
 * @type {!string}
 * @export
 */
API.Client.CurationComment.prototype.createdDate;

/**
 * The date the comment has been modified.
 * @type {!string}
 * @export
 */
API.Client.CurationComment.prototype.modifiedDate;

/** @enum {string} */
API.Client.CurationComment.TypeEnum = { 
  comment: 'comment',
  approved: 'approved',
  rejected: 'rejected',
  closed: 'closed',
}
