goog.provide('API.Client.ArticleCompletePrivate');

/**
 * @record
 */
API.Client.ArticleCompletePrivate = function() {}

/**
 * Article public url
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.figshareUrl;

/**
 * If true, downloading of files for this article is disabled
 * @type {!boolean}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.downloadDisabled;

/**
 * List of up to 10 article files.
 * @type {!Array<!API.Client.PublicFile>}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.files;

/**
 * List of article authors
 * @type {!Array<!API.Client.Author>}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.authors;

/**
 * List of custom fields values
 * @type {!Array<!API.Client.CustomArticleField>}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.customFields;

/**
 * List of embargo options
 * @type {!Array<!API.Client.GroupEmbargoOptions>}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.embargoOptions;

/**
 * Article citation
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.citation;

/**
 * Confidentiality reason
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.confidentialReason;

/**
 * Article Confidentiality
 * @type {!boolean}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.isConfidential;

/**
 * Article size
 * @type {!number}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.size;

/**
 * Article funding
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.funding;

/**
 * Full Article funding information
 * @type {!Array<!API.Client.FundingInformation>}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.fundingList;

/**
 * List of article tags. Keywords can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.tags;

/**
 * List of article keywords. Tags can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.keywords;

/**
 * Article version
 * @type {!number}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.version;

/**
 * True if article has no files
 * @type {!boolean}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.isMetadataRecord;

/**
 * Article metadata reason
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.metadataReason;

/**
 * Article status
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.status;

/**
 * Article description
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.description;

/**
 * True if article is embargoed
 * @type {!boolean}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.isEmbargoed;

/**
 * True if article is published
 * @type {!boolean}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.isPublic;

/**
 * Date when article was created
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.createdDate;

/**
 * True if any files are linked to the article
 * @type {!boolean}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.hasLinkedFile;

/**
 * List of categories selected for the article
 * @type {!Array<!API.Client.Category>}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.categories;

/**
 * Article selected license
 * @type {!API.Client.License}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.license;

/**
 * Title for embargo
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.embargoTitle;

/**
 * Reason for embargo
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.embargoReason;

/**
 * List of references
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.references;

/**
 * List of related materials; supersedes references and resource DOI/title.
 * @type {!Array<!API.Client.RelatedMaterial>}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.relatedMaterials;

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPrivateApi;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.timeline;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.thumb;

/**
 * Type of article identifier
 * @type {!number}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.definedType;

/**
 * Name of the article type identifier
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.definedTypeName;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.resourceDoi;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.resourceTitle;

/**
 * ID of the account owning the article
 * @type {!number}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.accountId;

