goog.provide('API.Client.PublicFile');

/**
 * @record
 */
API.Client.PublicFile = function() {}

/**
 * File id
 * @type {!number}
 * @export
 */
API.Client.PublicFile.prototype.id;

/**
 * File name
 * @type {!string}
 * @export
 */
API.Client.PublicFile.prototype.name;

/**
 * File size
 * @type {!number}
 * @export
 */
API.Client.PublicFile.prototype.size;

/**
 * True if file is hosted somewhere else
 * @type {!boolean}
 * @export
 */
API.Client.PublicFile.prototype.isLinkOnly;

/**
 * Url for file download
 * @type {!string}
 * @export
 */
API.Client.PublicFile.prototype.downloadUrl;

/**
 * File supplied md5
 * @type {!string}
 * @export
 */
API.Client.PublicFile.prototype.suppliedMd5;

/**
 * File computed md5
 * @type {!string}
 * @export
 */
API.Client.PublicFile.prototype.computedMd5;

/**
 * MIME Type of the file, it defaults to an empty string
 * @type {!string}
 * @export
 */
API.Client.PublicFile.prototype.mimetype;

