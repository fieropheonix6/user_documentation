goog.provide('API.Client.body');

/**
 * @record
 */
API.Client.Body = function() {}

/**
 * @type {!string}
 * @export
 */
API.Client.Body.prototype.clientId;

/**
 * @type {!string}
 * @export
 */
API.Client.Body.prototype.clientSecret;

/**
 * @type {!string}
 * @export
 */
API.Client.Body.prototype.grantType;

/**
 * Required if grant_type is 'authorization_code'
 * @type {!string}
 * @export
 */
API.Client.Body.prototype.code;

/**
 * Required if grant_type is 'refresh_token'
 * @type {!string}
 * @export
 */
API.Client.Body.prototype.refreshToken;

/**
 * Required if grant_type is 'password'
 * @type {!string}
 * @export
 */
API.Client.Body.prototype.username;

/**
 * Required if grant_type is 'password'
 * @type {!string}
 * @export
 */
API.Client.Body.prototype.password;

/** @enum {string} */
API.Client.Body.GrantTypeEnum = { 
  authorization_code: 'authorization_code',
  refresh_token: 'refresh_token',
  password: 'password',
  client_credentials: 'client_credentials',
}
