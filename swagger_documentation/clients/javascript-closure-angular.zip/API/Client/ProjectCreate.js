goog.provide('API.Client.ProjectCreate');

/**
 * @record
 */
API.Client.ProjectCreate = function() {}

/**
 * The title for this project - mandatory. 3 - 1000 characters.
 * @type {!string}
 * @export
 */
API.Client.ProjectCreate.prototype.title;

/**
 * Project description
 * @type {!string}
 * @export
 */
API.Client.ProjectCreate.prototype.description;

/**
 * Grant number or organization(s) that funded this project. Up to 2000 characters permitted.
 * @type {!string}
 * @export
 */
API.Client.ProjectCreate.prototype.funding;

/**
 * Funding creation / update items
 * @type {!Array<!API.Client.FundingCreate>}
 * @export
 */
API.Client.ProjectCreate.prototype.fundingList;

/**
 * Only if project type is group.
 * @type {!number}
 * @export
 */
API.Client.ProjectCreate.prototype.groupId;

/**
 * List of key, values pairs to be associated with the project
 * @type {!API.Client.Object}
 * @export
 */
API.Client.ProjectCreate.prototype.customFields;

/**
 * List of custom fields values, supersedes custom_fields parameter
 * @type {!Array<!API.Client.CustomArticleFieldAdd>}
 * @export
 */
API.Client.ProjectCreate.prototype.customFieldsList;

