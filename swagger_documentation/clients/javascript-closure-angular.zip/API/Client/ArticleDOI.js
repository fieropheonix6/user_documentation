goog.provide('API.Client.ArticleDOI');

/**
 * @record
 */
API.Client.ArticleDOI = function() {}

/**
 * Reserved DOI
 * @type {!string}
 * @export
 */
API.Client.ArticleDOI.prototype.doi;

