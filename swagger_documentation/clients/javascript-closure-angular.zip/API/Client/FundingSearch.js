goog.provide('API.Client.FundingSearch');

/**
 * @record
 */
API.Client.FundingSearch = function() {}

/**
 * Search term
 * @type {!string}
 * @export
 */
API.Client.FundingSearch.prototype.searchFor;

