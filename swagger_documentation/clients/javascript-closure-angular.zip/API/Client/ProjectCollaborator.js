goog.provide('API.Client.ProjectCollaborator');

/**
 * @record
 */
API.Client.ProjectCollaborator = function() {}

/**
 * Status of collaborator invitation
 * @type {!string}
 * @export
 */
API.Client.ProjectCollaborator.prototype.status;

/**
 * Collaborator role
 * @type {!string}
 * @export
 */
API.Client.ProjectCollaborator.prototype.roleName;

/**
 * Collaborator id
 * @type {!number}
 * @export
 */
API.Client.ProjectCollaborator.prototype.userId;

/**
 * Collaborator name
 * @type {!string}
 * @export
 */
API.Client.ProjectCollaborator.prototype.name;

