goog.provide('API.Client.CustomArticleFieldAdd');

/**
 * @record
 */
API.Client.CustomArticleFieldAdd = function() {}

/**
 * Custom  metadata name
 * @type {!string}
 * @export
 */
API.Client.CustomArticleFieldAdd.prototype.name;

/**
 * Custom metadata value (can be either a string or an array of strings)
 * @type {!API.Client.Object}
 * @export
 */
API.Client.CustomArticleFieldAdd.prototype.value;

