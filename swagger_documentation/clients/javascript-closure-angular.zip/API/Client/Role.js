goog.provide('API.Client.Role');

/**
 * @record
 */
API.Client.Role = function() {}

/**
 * Role id
 * @type {!number}
 * @export
 */
API.Client.Role.prototype.id;

/**
 * Role name
 * @type {!string}
 * @export
 */
API.Client.Role.prototype.name;

/**
 * Role category
 * @type {!string}
 * @export
 */
API.Client.Role.prototype.category;

/**
 * Role description
 * @type {!string}
 * @export
 */
API.Client.Role.prototype.description;

