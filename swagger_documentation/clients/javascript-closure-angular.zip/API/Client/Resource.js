goog.provide('API.Client.Resource');

/**
 * @record
 */
API.Client.Resource = function() {}

/**
 * ID of resource item
 * @type {!string}
 * @export
 */
API.Client.Resource.prototype.id;

/**
 * Title of resource item
 * @type {!string}
 * @export
 */
API.Client.Resource.prototype.title;

/**
 * DOI of resource item
 * @type {!string}
 * @export
 */
API.Client.Resource.prototype.doi;

/**
 * Link of resource item
 * @type {!string}
 * @export
 */
API.Client.Resource.prototype.link;

/**
 * Status of resource item
 * @type {!string}
 * @export
 */
API.Client.Resource.prototype.status;

/**
 * Version of resource item
 * @type {!number}
 * @export
 */
API.Client.Resource.prototype.version;

