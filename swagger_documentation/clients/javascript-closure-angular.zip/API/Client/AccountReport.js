goog.provide('API.Client.AccountReport');

/**
 * @record
 */
API.Client.AccountReport = function() {}

/**
 * A unique ID for the AccountRecord
 * @type {!number}
 * @export
 */
API.Client.AccountReport.prototype.id;

/**
 * The ID of the account which generated this report.
 * @type {!number}
 * @export
 */
API.Client.AccountReport.prototype.accountId;

/**
 * Date when the AccountReport was requested
 * @type {!string}
 * @export
 */
API.Client.AccountReport.prototype.createdDate;

/**
 * Status of the report
 * @type {!string}
 * @export
 */
API.Client.AccountReport.prototype.status;

/**
 * The download link for the generated XLSX
 * @type {!string}
 * @export
 */
API.Client.AccountReport.prototype.downloadUrl;

/**
 * The group ID that was used to filter the report, if any.
 * @type {!number}
 * @export
 */
API.Client.AccountReport.prototype.groupId;

/** @enum {string} */
API.Client.AccountReport.StatusEnum = { 
  missing: 'missing',
  pending: 'pending',
  done: 'done',
}
