goog.provide('API.Client.CurationDetail');

/**
 * @record
 */
API.Client.CurationDetail = function() {}

/**
 * The review id
 * @type {!number}
 * @export
 */
API.Client.CurationDetail.prototype.id;

/**
 * The group in which the article is present.
 * @type {!number}
 * @export
 */
API.Client.CurationDetail.prototype.groupId;

/**
 * The ID of the account of the owner of the article of this review.
 * @type {!number}
 * @export
 */
API.Client.CurationDetail.prototype.accountId;

/**
 * The ID of the account to which this review is assigned.
 * @type {!number}
 * @export
 */
API.Client.CurationDetail.prototype.assignedTo;

/**
 * The ID of the article of this review.
 * @type {!number}
 * @export
 */
API.Client.CurationDetail.prototype.articleId;

/**
 * The Version number of the article in review.
 * @type {!number}
 * @export
 */
API.Client.CurationDetail.prototype.version;

/**
 * The number of comments in the review.
 * @type {!number}
 * @export
 */
API.Client.CurationDetail.prototype.commentsCount;

/**
 * The status of the review.
 * @type {!string}
 * @export
 */
API.Client.CurationDetail.prototype.status;

/**
 * The creation date of the review.
 * @type {!string}
 * @export
 */
API.Client.CurationDetail.prototype.createdDate;

/**
 * The date the review has been modified.
 * @type {!string}
 * @export
 */
API.Client.CurationDetail.prototype.modifiedDate;

/**
 * Article details
 * @type {!API.Client.ArticleComplete}
 * @export
 */
API.Client.CurationDetail.prototype.item;

/** @enum {string} */
API.Client.CurationDetail.StatusEnum = { 
  pending: 'pending',
  approved: 'approved',
  rejected: 'rejected',
  closed: 'closed',
}
