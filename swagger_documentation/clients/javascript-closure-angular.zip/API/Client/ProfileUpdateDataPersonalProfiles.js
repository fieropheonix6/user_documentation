goog.provide('API.Client.ProfileUpdateData_personal_profiles');

/**
 * @record
 */
API.Client.ProfileUpdateDataPersonalProfiles = function() {}

/**
 * Label for the personal profile link
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateDataPersonalProfiles.prototype.label;

/**
 * URL for the personal profile link
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateDataPersonalProfiles.prototype.url;

