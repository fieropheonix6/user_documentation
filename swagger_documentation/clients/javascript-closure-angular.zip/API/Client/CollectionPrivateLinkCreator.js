goog.provide('API.Client.CollectionPrivateLinkCreator');

/**
 * @record
 */
API.Client.CollectionPrivateLinkCreator = function() {}

/**
 * Date when this private link should expire - optional. By default private links expire in 365 days.
 * @type {!string}
 * @export
 */
API.Client.CollectionPrivateLinkCreator.prototype.expiresDate;

