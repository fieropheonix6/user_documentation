goog.provide('API.Client.CategoryList');

/**
 * @record
 */
API.Client.CategoryList = function() {}

/**
 * Parent category
 * @type {!number}
 * @export
 */
API.Client.CategoryList.prototype.parentId;

/**
 * Category id
 * @type {!number}
 * @export
 */
API.Client.CategoryList.prototype.id;

/**
 * Category title
 * @type {!string}
 * @export
 */
API.Client.CategoryList.prototype.title;

/**
 * Path to all ancestor ids
 * @type {!string}
 * @export
 */
API.Client.CategoryList.prototype.path;

/**
 * ID in original standard taxonomy
 * @type {!string}
 * @export
 */
API.Client.CategoryList.prototype.sourceId;

/**
 * Internal id of taxonomy the category is part of
 * @type {!number}
 * @export
 */
API.Client.CategoryList.prototype.taxonomyId;

/**
 * The selectable status
 * @type {!boolean}
 * @export
 */
API.Client.CategoryList.prototype.isSelectable;

/**
 * True if category has children
 * @type {!boolean}
 * @export
 */
API.Client.CategoryList.prototype.hasChildren;

