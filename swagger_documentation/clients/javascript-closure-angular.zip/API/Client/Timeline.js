goog.provide('API.Client.Timeline');

/**
 * @record
 */
API.Client.Timeline = function() {}

/**
 * Online posted date
 * @type {!string}
 * @export
 */
API.Client.Timeline.prototype.firstOnline;

/**
 * Publish date
 * @type {!string}
 * @export
 */
API.Client.Timeline.prototype.publisherPublication;

/**
 * Date when the item was accepted for publication
 * @type {!string}
 * @export
 */
API.Client.Timeline.prototype.publisherAcceptance;

