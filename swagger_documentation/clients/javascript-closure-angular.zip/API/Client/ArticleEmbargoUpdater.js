goog.provide('API.Client.ArticleEmbargoUpdater');

/**
 * @record
 */
API.Client.ArticleEmbargoUpdater = function() {}

/**
 * Embargo status
 * @type {!boolean}
 * @export
 */
API.Client.ArticleEmbargoUpdater.prototype.isEmbargoed;

/**
 * Date when the embargo expires and the article gets published, '0' value will set up permanent embargo
 * @type {!string}
 * @export
 */
API.Client.ArticleEmbargoUpdater.prototype.embargoDate;

/**
 * Embargo can be enabled at the article or the file level. Possible values: article, file
 * @type {!string}
 * @export
 */
API.Client.ArticleEmbargoUpdater.prototype.embargoType;

/**
 * Title for embargo
 * @type {!string}
 * @export
 */
API.Client.ArticleEmbargoUpdater.prototype.embargoTitle;

/**
 * Reason for setting embargo
 * @type {!string}
 * @export
 */
API.Client.ArticleEmbargoUpdater.prototype.embargoReason;

/**
 * List of embargo permissions to be associated with the article. The list must contain `id` and can also contain `group_ids`(a field that only applies to 'logged_in' permissions). The new list replaces old options in the database, and an empty list removes all permissions for this article. Administration permission has to be set up alone but logged in and IP range permissions can be set up together.
 * @type {!Array<!API.Client.Object>}
 * @export
 */
API.Client.ArticleEmbargoUpdater.prototype.embargoOptions;

/** @enum {string} */
API.Client.ArticleEmbargoUpdater.EmbargoTypeEnum = { 
  article: 'article',
  file: 'file',
}
