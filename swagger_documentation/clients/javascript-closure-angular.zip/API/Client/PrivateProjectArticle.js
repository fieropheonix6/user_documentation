goog.provide('API.Client.PrivateProjectArticle');

/**
 * @record
 */
API.Client.PrivateProjectArticle = function() {}

/**
 * List of up to 10 article files.
 * @type {!Array<!API.Client.PublicFile>}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.files;

/**
 * List of embargo options
 * @type {!Array<!API.Client.GroupEmbargoOptions>}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.embargoOptions;

/**
 * List of custom fields values
 * @type {!Array<!API.Client.CustomArticleField>}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.customFields;

/**
 * ID of the account owning the article
 * @type {!number}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.accountId;

/**
 * If true, downloading of files for this article is disabled
 * @type {!boolean}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.downloadDisabled;

/**
 * List of authors
 * @type {!Array<!API.Client.Author>}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.authors;

/**
 * Article public url
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.figshareUrl;

/**
 * Curation status of the article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.curationStatus;

/**
 * Article citation
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.citation;

/**
 * Confidentiality reason
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.confidentialReason;

/**
 * Article Confidentiality
 * @type {!boolean}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.isConfidential;

/**
 * Article size
 * @type {!number}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.size;

/**
 * Article funding
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.funding;

/**
 * Full Article funding information
 * @type {!Array<!API.Client.FundingInformation>}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.fundingList;

/**
 * List of article tags. Keywords can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.tags;

/**
 * List of article keywords. Tags can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.keywords;

/**
 * Article version
 * @type {!number}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.version;

/**
 * True if article has no files
 * @type {!boolean}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.isMetadataRecord;

/**
 * Article metadata reason
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.metadataReason;

/**
 * Article status
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.status;

/**
 * Article description
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.description;

/**
 * True if article is embargoed
 * @type {!boolean}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.isEmbargoed;

/**
 * True if article is published
 * @type {!boolean}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.isPublic;

/**
 * Date when article was created
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.createdDate;

/**
 * True if any files are linked to the article
 * @type {!boolean}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.hasLinkedFile;

/**
 * List of categories selected for the article
 * @type {!Array<!API.Client.Category>}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.categories;

/**
 * @type {!API.Client.License}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.license;

/**
 * Title for embargo
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.embargoTitle;

/**
 * Reason for embargo
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.embargoReason;

/**
 * List of references
 * @type {!Array<!string>}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.references;

/**
 * List of related materials; supersedes references and resource DOI/title.
 * @type {!Array<!API.Client.RelatedMaterial>}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.relatedMaterials;

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.urlPrivateApi;

/**
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.timeline;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.thumb;

/**
 * Type of article identifier
 * @type {!number}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.definedType;

/**
 * Name of the article type identifier
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.definedTypeName;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.resourceDoi;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticle.prototype.resourceTitle;

