goog.provide('API.Client.ArticleComplete');

/**
 * @record
 */
API.Client.ArticleComplete = function() {}

/**
 * Article citation
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.citation;

/**
 * Confidentiality reason
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.confidentialReason;

/**
 * Article Confidentiality
 * @type {!boolean}
 * @export
 */
API.Client.ArticleComplete.prototype.isConfidential;

/**
 * Article size
 * @type {!number}
 * @export
 */
API.Client.ArticleComplete.prototype.size;

/**
 * Article funding
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.funding;

/**
 * Full Article funding information
 * @type {!Array<!API.Client.FundingInformation>}
 * @export
 */
API.Client.ArticleComplete.prototype.fundingList;

/**
 * List of article tags. Keywords can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleComplete.prototype.tags;

/**
 * List of article keywords. Tags can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleComplete.prototype.keywords;

/**
 * Article version
 * @type {!number}
 * @export
 */
API.Client.ArticleComplete.prototype.version;

/**
 * True if article has no files
 * @type {!boolean}
 * @export
 */
API.Client.ArticleComplete.prototype.isMetadataRecord;

/**
 * Article metadata reason
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.metadataReason;

/**
 * Article status
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.status;

/**
 * Article description
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.description;

/**
 * True if article is embargoed
 * @type {!boolean}
 * @export
 */
API.Client.ArticleComplete.prototype.isEmbargoed;

/**
 * True if article is published
 * @type {!boolean}
 * @export
 */
API.Client.ArticleComplete.prototype.isPublic;

/**
 * Date when article was created
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.createdDate;

/**
 * True if any files are linked to the article
 * @type {!boolean}
 * @export
 */
API.Client.ArticleComplete.prototype.hasLinkedFile;

/**
 * List of categories selected for the article
 * @type {!Array<!API.Client.Category>}
 * @export
 */
API.Client.ArticleComplete.prototype.categories;

/**
 * Article selected license
 * @type {!API.Client.License}
 * @export
 */
API.Client.ArticleComplete.prototype.license;

/**
 * Title for embargo
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.embargoTitle;

/**
 * Reason for embargo
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.embargoReason;

/**
 * List of references
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleComplete.prototype.references;

/**
 * List of related materials; supersedes references and resource DOI/title.
 * @type {!Array<!API.Client.RelatedMaterial>}
 * @export
 */
API.Client.ArticleComplete.prototype.relatedMaterials;

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ArticleComplete.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPrivateApi;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.ArticleComplete.prototype.timeline;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.thumb;

/**
 * Type of article identifier
 * @type {!number}
 * @export
 */
API.Client.ArticleComplete.prototype.definedType;

/**
 * Name of the article type identifier
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.definedTypeName;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.resourceDoi;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.resourceTitle;

/**
 * Article public url
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.figshareUrl;

/**
 * If true, downloading of files for this article is disabled
 * @type {!boolean}
 * @export
 */
API.Client.ArticleComplete.prototype.downloadDisabled;

/**
 * List of up to 10 article files.
 * @type {!Array<!API.Client.PublicFile>}
 * @export
 */
API.Client.ArticleComplete.prototype.files;

/**
 * List of article authors
 * @type {!Array<!API.Client.Author>}
 * @export
 */
API.Client.ArticleComplete.prototype.authors;

/**
 * List of custom fields values
 * @type {!Array<!API.Client.CustomArticleField>}
 * @export
 */
API.Client.ArticleComplete.prototype.customFields;

/**
 * List of embargo options
 * @type {!Array<!API.Client.GroupEmbargoOptions>}
 * @export
 */
API.Client.ArticleComplete.prototype.embargoOptions;

