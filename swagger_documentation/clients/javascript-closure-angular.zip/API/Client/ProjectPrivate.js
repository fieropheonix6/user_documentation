goog.provide('API.Client.ProjectPrivate');

/**
 * @record
 */
API.Client.ProjectPrivate = function() {}

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.url;

/**
 * Project id
 * @type {!number}
 * @export
 */
API.Client.ProjectPrivate.prototype.id;

/**
 * Project title
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.title;

/**
 * Role inside this project
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.role;

/**
 * Project storage type
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.storage;

/** @enum {string} */
API.Client.ProjectPrivate.RoleEnum = { 
  Owner: 'Owner',
  Collaborator: 'Collaborator',
  Viewer: 'Viewer',
}
/** @enum {string} */
API.Client.ProjectPrivate.StorageEnum = { 
  individual: 'individual',
  group: 'group',
}
