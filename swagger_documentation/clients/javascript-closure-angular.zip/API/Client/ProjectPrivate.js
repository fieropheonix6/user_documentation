goog.provide('API.Client.ProjectPrivate');

/**
 * @record
 */
API.Client.ProjectPrivate = function() {}

/**
 * Role inside this project
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.role;

/**
 * Project storage type
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.storage;

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.url;

/**
 * Project id
 * @type {!number}
 * @export
 */
API.Client.ProjectPrivate.prototype.id;

/**
 * Project title
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.title;

/**
 * Date when project was created
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.createdDate;

/**
 * Date when project was last modified
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.modifiedDate;

/** @enum {string} */
API.Client.ProjectPrivate.RoleEnum = { 
  Owner: 'Owner',
  Collaborator: 'Collaborator',
  Viewer: 'Viewer',
}
/** @enum {string} */
API.Client.ProjectPrivate.StorageEnum = { 
  individual: 'individual',
  group: 'group',
}
