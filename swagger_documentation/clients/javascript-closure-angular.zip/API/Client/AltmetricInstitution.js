goog.provide('API.Client.AltmetricInstitution');

/**
 * @record
 */
API.Client.AltmetricInstitution = function() {}

/**
 * Institution id
 * @type {!number}
 * @export
 */
API.Client.AltmetricInstitution.prototype.id;

/**
 * Institution name
 * @type {!string}
 * @export
 */
API.Client.AltmetricInstitution.prototype.name;

/**
 * Custom domain for the institution
 * @type {!string}
 * @export
 */
API.Client.AltmetricInstitution.prototype.customDomain;

