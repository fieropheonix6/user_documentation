goog.provide('API.Client.PrivateProjectArticles');

/**
 * @record
 */
API.Client.PrivateProjectArticles = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.urlPrivateApi;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.timeline;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.thumb;

/**
 * Type of article identifier
 * @type {!number}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.definedType;

/**
 * Name of the article type identifier
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.definedTypeName;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.resourceDoi;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.resourceTitle;

/**
 * Date when article was created
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.createdDate;

/**
 * List of up to 10 article files.
 * @type {!Array<!API.Client.PublicFile>}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.files;

/**
 * List of embargo options
 * @type {!Array<!API.Client.GroupEmbargoOptions>}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.embargoOptions;

/**
 * List of custom fields values
 * @type {!Array<!API.Client.CustomArticleField>}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.customFields;

/**
 * ID of the account owning the article
 * @type {!number}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.accountId;

/**
 * If true, downloading of files for this article is disabled
 * @type {!boolean}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.downloadDisabled;

/**
 * List of authors
 * @type {!Array<!API.Client.Author>}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.authors;

/**
 * Article public url
 * @type {!string}
 * @export
 */
API.Client.PrivateProjectArticles.prototype.figshareUrl;

