goog.provide('API.Client.Curation');

/**
 * @record
 */
API.Client.Curation = function() {}

/**
 * The review id
 * @type {!number}
 * @export
 */
API.Client.Curation.prototype.id;

/**
 * The group in which the article is present.
 * @type {!number}
 * @export
 */
API.Client.Curation.prototype.groupId;

/**
 * The ID of the account of the owner of the article of this review.
 * @type {!number}
 * @export
 */
API.Client.Curation.prototype.accountId;

/**
 * The ID of the account to which this review is assigned.
 * @type {!number}
 * @export
 */
API.Client.Curation.prototype.assignedTo;

/**
 * The ID of the article of this review.
 * @type {!number}
 * @export
 */
API.Client.Curation.prototype.articleId;

/**
 * The Version number of the article in review.
 * @type {!number}
 * @export
 */
API.Client.Curation.prototype.version;

/**
 * The number of comments in the review.
 * @type {!number}
 * @export
 */
API.Client.Curation.prototype.commentsCount;

/**
 * The status of the review.
 * @type {!string}
 * @export
 */
API.Client.Curation.prototype.status;

/**
 * The creation date of the review.
 * @type {!string}
 * @export
 */
API.Client.Curation.prototype.createdDate;

/**
 * The date the review has been modified.
 * @type {!string}
 * @export
 */
API.Client.Curation.prototype.modifiedDate;

/**
 * The request number of the review.
 * @type {!number}
 * @export
 */
API.Client.Curation.prototype.requestNumber;

/**
 * The resolution comment of the review.
 * @type {!string}
 * @export
 */
API.Client.Curation.prototype.resolutionComment;

/** @enum {string} */
API.Client.Curation.StatusEnum = { 
  pending: 'pending',
  approved: 'approved',
  rejected: 'rejected',
  closed: 'closed',
}
