goog.provide('API.Client.FileCreator');

/**
 * @record
 */
API.Client.FileCreator = function() {}

/**
 * Url for an existing file that will not be uploaded to Figshare
 * @type {!string}
 * @export
 */
API.Client.FileCreator.prototype.link;

/**
 * MD5 sum pre-computed on client side.
 * @type {!string}
 * @export
 */
API.Client.FileCreator.prototype.md5;

/**
 * File name including the extension; can be omitted only for linked files.
 * @type {!string}
 * @export
 */
API.Client.FileCreator.prototype.name;

/**
 * File size in bytes; can be omitted only for linked files.
 * @type {!number}
 * @export
 */
API.Client.FileCreator.prototype.size;

/**
 * Unix-style directory path of the file; only available if the file was uploaded within a folder structure
 * @type {!string}
 * @export
 */
API.Client.FileCreator.prototype.folderPath;

