goog.provide('API.Client.Article');

/**
 * @record
 */
API.Client.Article = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.Article.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPrivateApi;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.Article.prototype.timeline;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.thumb;

/**
 * Type of article identifier
 * @type {!number}
 * @export
 */
API.Client.Article.prototype.definedType;

/**
 * Name of the article type identifier
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.definedTypeName;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.resourceDoi;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.resourceTitle;

