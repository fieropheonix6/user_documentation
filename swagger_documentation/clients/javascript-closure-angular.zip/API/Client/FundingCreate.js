goog.provide('API.Client.FundingCreate');

/**
 * @record
 */
API.Client.FundingCreate = function() {}

/**
 * A funding ID as returned by the Funding Search endpoint
 * @type {!number}
 * @export
 */
API.Client.FundingCreate.prototype.id;

/**
 * The title of the new user created funding
 * @type {!string}
 * @export
 */
API.Client.FundingCreate.prototype.title;

