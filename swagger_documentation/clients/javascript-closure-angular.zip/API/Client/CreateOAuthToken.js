goog.provide('API.Client.CreateOAuthToken');

/**
 * @record
 */
API.Client.CreateOAuthToken = function() {}

/**
 * @type {!string}
 * @export
 */
API.Client.CreateOAuthToken.prototype.clientId;

/**
 * @type {!string}
 * @export
 */
API.Client.CreateOAuthToken.prototype.clientSecret;

/**
 * @type {!string}
 * @export
 */
API.Client.CreateOAuthToken.prototype.grantType;

/**
 * Required if grant_type is 'authorization_code'
 * @type {!string}
 * @export
 */
API.Client.CreateOAuthToken.prototype.code;

/**
 * Required if grant_type is 'refresh_token'
 * @type {!string}
 * @export
 */
API.Client.CreateOAuthToken.prototype.refreshToken;

/**
 * Required if grant_type is 'password'
 * @type {!string}
 * @export
 */
API.Client.CreateOAuthToken.prototype.username;

/**
 * Required if grant_type is 'password'
 * @type {!string}
 * @export
 */
API.Client.CreateOAuthToken.prototype.password;

/** @enum {string} */
API.Client.CreateOAuthToken.GrantTypeEnum = { 
  authorization_code: 'authorization_code',
  refresh_token: 'refresh_token',
  password: 'password',
  client_credentials: 'client_credentials',
}
