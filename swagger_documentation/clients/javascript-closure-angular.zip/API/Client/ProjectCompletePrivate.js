goog.provide('API.Client.ProjectCompletePrivate');

/**
 * @record
 */
API.Client.ProjectCompletePrivate = function() {}

/**
 * Role inside this project
 * @type {!string}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.role;

/**
 * Project storage type
 * @type {!string}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.storage;

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.url;

/**
 * Project id
 * @type {!number}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.id;

/**
 * Project title
 * @type {!string}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.title;

/**
 * Date when project was created
 * @type {!string}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.createdDate;

/**
 * Date when project was last modified
 * @type {!string}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.modifiedDate;

/**
 * Project funding
 * @type {!string}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.funding;

/**
 * Full Project funding information
 * @type {!Array<!API.Client.FundingInformation>}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.fundingList;

/**
 * Project description
 * @type {!string}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.description;

/**
 * List of project collaborators
 * @type {!Array<!API.Client.Collaborator>}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.collaborators;

/**
 * Project quota
 * @type {!number}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.quota;

/**
 * Project used quota
 * @type {!number}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.usedQuota;

/**
 * Project private quota used
 * @type {!number}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.usedQuotaPrivate;

/**
 * Project public quota used
 * @type {!number}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.usedQuotaPublic;

/**
 * Group of project if any
 * @type {!number}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.groupId;

/**
 * ID of the account owning the project
 * @type {!number}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.accountId;

/**
 * Collection custom fields
 * @type {!Array<!API.Client.CustomArticleField>}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.customFields;

/** @enum {string} */
API.Client.ProjectCompletePrivate.RoleEnum = { 
  Owner: 'Owner',
  Collaborator: 'Collaborator',
  Viewer: 'Viewer',
}
/** @enum {string} */
API.Client.ProjectCompletePrivate.StorageEnum = { 
  individual: 'individual',
  group: 'group',
}
