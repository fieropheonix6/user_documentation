goog.provide('API.Client.ProjectComplete');

/**
 * @record
 */
API.Client.ProjectComplete = function() {}

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.ProjectComplete.prototype.url;

/**
 * Project id
 * @type {!number}
 * @export
 */
API.Client.ProjectComplete.prototype.id;

/**
 * Project title
 * @type {!string}
 * @export
 */
API.Client.ProjectComplete.prototype.title;

/**
 * Date when project was created
 * @type {!string}
 * @export
 */
API.Client.ProjectComplete.prototype.createdDate;

/**
 * Date when project was last modified
 * @type {!string}
 * @export
 */
API.Client.ProjectComplete.prototype.modifiedDate;

/**
 * Project funding
 * @type {!string}
 * @export
 */
API.Client.ProjectComplete.prototype.funding;

/**
 * Full Project funding information
 * @type {!Array<!API.Client.FundingInformation>}
 * @export
 */
API.Client.ProjectComplete.prototype.fundingList;

/**
 * Project description
 * @type {!string}
 * @export
 */
API.Client.ProjectComplete.prototype.description;

/**
 * List of project collaborators
 * @type {!Array<!API.Client.Collaborator>}
 * @export
 */
API.Client.ProjectComplete.prototype.collaborators;

/**
 * Project custom fields
 * @type {!Array<!API.Client.CustomArticleField>}
 * @export
 */
API.Client.ProjectComplete.prototype.customFields;

