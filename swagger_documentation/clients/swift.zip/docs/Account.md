# Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int** | Account id | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**usedQuotaPrivate** | **Int** | Account used private quota | 
**modifiedDate** | **String** | Date of last account modification | 
**usedQuota** | **Int** | Account total used quota | 
**createdDate** | **String** | Date when account was created | 
**quota** | **Int** | Account quota | 
**groupId** | **Int** | Account group id | 
**institutionUserId** | **String** | Account institution user id | 
**institutionId** | **Int** | Account institution | 
**email** | **String** | User email | 
**usedQuotaPublic** | **Int** | Account public used quota | 
**pendingQuotaRequest** | **Bool** | True if a quota request is pending | 
**active** | **Int** | Account activity status | 
**maximumFileSize** | **Int** | Maximum upload size for account | 
**userId** | **Int** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcidId** | **String** | ORCID iD associated to account | 
**symplecticUserId** | **String** | Symplectic ID associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


