# ItemType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int** | The ID of the item type. | 
**name** | **String** | The name of the item type | 
**stringId** | **String** | The string identifier of the item type. | 
**icon** | **String** | The string identifying the icon of the item type. | 
**publicDescription** | **String** | The description of the item type. | 
**isSelectable** | **Bool** | The selectable status | 
**urlName** | **String** | The URL name of the item type. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


