# AuthorComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**institutionId** | **Int** | Institution id | 
**groupId** | **Int** | Group id | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**isPublic** | **Int** | if 1 then the author has published items | 
**jobTitle** | **String** | Job title | 
**id** | **Int** | Author id | 
**fullName** | **String** | Author full name | 
**isActive** | **Bool** | True if author has published items | 
**urlName** | **String** | Author url name | 
**orcidId** | **String** | Author Orcid | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


