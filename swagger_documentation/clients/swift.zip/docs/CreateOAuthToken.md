# CreateOAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientId** | **String** |  | 
**clientSecret** | **String** |  | 
**grantType** | **String** |  | 
**code** | **String** | Required if grant_type is &#39;authorization_code&#39; | [optional] 
**refreshToken** | **String** | Required if grant_type is &#39;refresh_token&#39; | [optional] 
**username** | **String** | Required if grant_type is &#39;password&#39; | [optional] 
**password** | **String** | Required if grant_type is &#39;password&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


