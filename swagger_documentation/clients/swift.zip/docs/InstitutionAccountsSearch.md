# InstitutionAccountsSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**searchFor** | **String** | Search term | [optional] 
**isActive** | **Int** | Filter by active status | [optional] 
**page** | **Int** | Page number. Used for pagination with page_size | [optional] 
**pageSize** | **Int** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **Int** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **Int** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**institutionUserId** | **String** | filter by institution_user_id | [optional] 
**email** | **String** | filter by email | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


