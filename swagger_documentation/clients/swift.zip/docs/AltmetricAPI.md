# AltmetricAPI

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**altmetricInstitutionsList**](AltmetricAPI.md#altmetricinstitutionslist) | **GET** /altmetric/institutions | List Altmetric Institutions


# **altmetricInstitutionsList**
```swift
    open class func altmetricInstitutionsList(offset: Int? = nil, completion: @escaping (_ data: [AltmetricInstitution]?, _ error: Error?) -> Void)
```

List Altmetric Institutions

Returns a list of institutions available for Altmetric reporting

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let offset = 987 // Int | Where to start the listing. The offset of the first item. (optional) (default to 0)

// List Altmetric Institutions
AltmetricAPI.altmetricInstitutionsList(offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Int** | Where to start the listing. The offset of the first item. | [optional] [default to 0]

### Return type

[**[AltmetricInstitution]**](AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

