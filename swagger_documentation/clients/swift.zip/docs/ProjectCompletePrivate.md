# ProjectCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **String** | Project funding | 
**fundingList** | [FundingInformation] | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [Collaborator] | List of project collaborators | 
**quota** | **Int** | Project quota | 
**usedQuota** | **Int** | Project used quota | 
**createdDate** | **String** | Date when project was created | 
**modifiedDate** | **String** | Date when project was last modified | 
**usedQuotaPrivate** | **Int** | Project private quota used | 
**usedQuotaPublic** | **Int** | Project public quota used | 
**groupId** | **Int** | Group of project if any | 
**accountId** | **Int** | ID of the account owning the project | 
**customFields** | [ShortCustomField] | Collection custom fields | 
**role** | **String** | Role inside this project | 
**storage** | **String** | Project storage type | 
**url** | **String** | Api endpoint | 
**id** | **Int** | Project id | 
**title** | **String** | Project title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


