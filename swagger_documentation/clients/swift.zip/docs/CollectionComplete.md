# CollectionComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | [FundingInformation] | Full Collection funding information | 
**resourceId** | **String** | Collection resource id | 
**resourceDoi** | **String** | Collection resource doi | 
**resourceTitle** | **String** | Collection resource title | 
**resourceLink** | **String** | Collection resource link | 
**resourceVersion** | **Int** | Collection resource version | 
**version** | **Int** | Collection version | 
**description** | **String** | Collection description | 
**categories** | [Category] | List of collection categories | 
**references** | **[String]** | List of collection references | 
**relatedMaterials** | [RelatedMaterial] | List of related materials; supersedes references and resource DOI/title. | 
**tags** | **[String]** | List of collection tags. Keywords can be used instead | 
**keywords** | **[String]** | List of collection keywords. Tags can be used instead | 
**authors** | [Author] | List of collection authors | 
**institutionId** | **Int** | Collection institution | 
**groupId** | **Int** | Collection group | 
**articlesCount** | **Int** | Number of articles in collection | 
**_public** | **Bool** | True if collection is published | 
**citation** | **String** | Collection citation | 
**customFields** | [CustomArticleField] | Collection custom fields | 
**modifiedDate** | **String** | Date when collection was last modified | 
**createdDate** | **String** | Date when collection was created | 
**timeline** | [**Timeline**](Timeline.md) |  | 
**id** | **Int** | Collection id | 
**title** | **String** | Collection title | 
**doi** | **String** | Collection DOI | 
**handle** | **String** | Collection Handle | 
**url** | **String** | Api endpoint | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


