# UploadInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** | token received after initializing a file upload | [optional] 
**md5** | **String** | md5 provided on upload initialization | [optional] 
**size** | **Int** | size of file in bytes | [optional] 
**name** | **String** | name of file on upload server | [optional] 
**status** | **String** | Upload status | [optional] 
**parts** | [UploadFilePart] | Uploads parts | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


