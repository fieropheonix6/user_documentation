# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentId** | **Int** | Parent category | 
**id** | **Int** | Category id | 
**title** | **String** | Category title | 
**path** | **String** | Path to all ancestor ids | 
**sourceId** | **String** | ID in original standard taxonomy | 
**taxonomyId** | **Int** | Internal id of taxonomy the category is part of | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


